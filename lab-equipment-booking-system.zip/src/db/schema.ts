import { boolean, integer, jsonb, pgTable, text, timestamp } from "drizzle-orm/pg-core";

/**
 * LABBOOK persistence schema (Drizzle ORM / PostgreSQL).
 *
 * The front-end demo runs from localStorage, and every mutation is mirrored into
 * these tables through /api/* so the same UI can be switched to a pure server data
 * source (or ported to MySQL / MongoDB / Firebase with the same shapes).
 */

export const departments = pgTable("labbook_departments", {
  key: text("key").primaryKey(),
  name: text("name").notNull(),
  short: text("short").notNull(),
  tagline: text("tagline"),
  description: text("description"),
  hod: text("hod"),
  building: text("building"),
  floor: text("floor"),
  contact: text("contact"),
  hue: integer("hue").default(212),
  icon: text("icon"),
});

export const subjects = pgTable("labbook_subjects", {
  slug: text("slug").notNull(),
  dept: text("dept").notNull(),
  name: text("name").notNull(),
  code: text("code"),
  semester: text("semester"),
  room: text("room"),
  description: text("description"),
  labHours: text("lab_hours"),
  supervisor: text("supervisor"),
  safety: text("safety"),
  outcomes: jsonb("outcomes").$type<string[]>().default([]),
});

export const equipment = pgTable("labbook_equipment", {
  id: text("id").primaryKey(),
  name: text("name").notNull(),
  dept: text("dept").notNull(),
  subject: text("subject").notNull(),
  category: text("category"),
  manufacturer: text("manufacturer"),
  model: text("model"),
  photo: text("photo"),
  gallery: jsonb("gallery").$type<string[]>().default([]),
  shortDesc: text("short_desc"),
  purpose: text("purpose"),
  size: jsonb("size").$type<Record<string, string>>().default({}),
  quantity: integer("quantity").default(1),
  maintenance: boolean("maintenance").default(false),
  specs: jsonb("specs").$type<[string, string][]>().default([]),
  uses: jsonb("uses").$type<string[]>().default([]),
  instructions: jsonb("instructions").$type<string[]>().default([]),
  safety: text("safety"),
  location: text("location"),
  calibrationDue: text("calibration_due"),
  addedOn: text("added_on"),
});

export const bookings = pgTable("labbook_bookings", {
  bookingId: text("booking_id").primaryKey(),
  createdAt: timestamp("created_at", { withTimezone: true }).defaultNow(),
  userName: text("user_name").notNull(),
  uid: text("uid").notNull(),
  role: text("role").notNull(),
  dept: text("dept").notNull(),
  subject: text("subject").notNull(),
  equipmentId: text("equipment_id").notNull(),
  equipmentName: text("equipment_name").notNull(),
  quantity: integer("quantity").notNull().default(1),
  date: text("date").notNull(),
  startTime: text("start_time").notNull(),
  endTime: text("end_time").notNull(),
  purpose: text("purpose"),
  returnDate: text("return_date"),
  returnTime: text("return_time"),
  phone: text("phone"),
  email: text("email"),
  notes: text("notes"),
  status: text("status").notNull().default("Pending"),
  adminNote: text("admin_note"),
});
