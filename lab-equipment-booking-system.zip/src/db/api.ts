import { and, asc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { bookings, departments, equipment, subjects } from "@/db/schema";
import { SEED_EQUIPMENT, DEPARTMENTS, SUBJECTS, type Booking, type Equipment } from "@/lib/data";
import type { PhotoKey } from "@/lib/images";

/** Row ↔ object mapping shared by every LABBOOK API route. */

type EquipmentRow = typeof equipment.$inferSelect;

export function rowToEquipment(r: EquipmentRow): Equipment {
  return {
    id: r.id,
    name: r.name,
    dept: r.dept as Equipment["dept"],
    subject: r.subject,
    category: (r.category ?? "Test & Measurement") as Equipment["category"],
    manufacturer: r.manufacturer ?? "—",
    model: r.model ?? "—",
    photo: (r.photo ?? "labInstruments") as PhotoKey,
    gallery: (r.gallery ?? []) as PhotoKey[],
    short: r.shortDesc ?? "",
    purpose: r.purpose ?? "",
    size: (r.size ?? { footprint: "—", weight: "—" }) as Equipment["size"],
    quantity: r.quantity ?? 1,
    maintenance: r.maintenance ?? false,
    specs: (r.specs ?? []) as [string, string][],
    uses: (r.uses ?? []) as string[],
    instructions: (r.instructions ?? []) as string[],
    safety: r.safety ?? undefined,
    location: r.location ?? undefined,
    calibrationDue: r.calibrationDue ?? undefined,
    addedOn: r.addedOn ?? new Date().toISOString().slice(0, 10),
  };
}

export function equipmentToRow(e: Equipment) {
  return {
    id: e.id,
    name: e.name,
    dept: e.dept,
    subject: e.subject,
    category: e.category,
    manufacturer: e.manufacturer,
    model: e.model,
    photo: e.photo,
    gallery: e.gallery ?? [],
    shortDesc: e.short,
    purpose: e.purpose,
    size: e.size as unknown as Record<string, string>,
    quantity: e.quantity,
    maintenance: !!e.maintenance,
    specs: e.specs,
    uses: e.uses,
    instructions: e.instructions,
    safety: e.safety ?? null,
    location: e.location ?? null,
    calibrationDue: e.calibrationDue ?? null,
    addedOn: e.addedOn,
  };
}

type BookingRow = typeof bookings.$inferSelect;

export function rowToBooking(r: BookingRow): Booking {
  return {
    bookingId: r.bookingId,
    createdAt: (r.createdAt instanceof Date ? r.createdAt : new Date()).toISOString(),
    userName: r.userName,
    uid: r.uid,
    role: r.role as Booking["role"],
    dept: r.dept as Booking["dept"],
    subject: r.subject,
    equipmentId: r.equipmentId,
    equipmentName: r.equipmentName,
    quantity: r.quantity,
    date: r.date,
    startTime: r.startTime,
    endTime: r.endTime,
    purpose: r.purpose ?? "",
    returnDate: r.returnDate ?? r.date,
    returnTime: r.returnTime ?? r.endTime,
    phone: r.phone ?? "",
    email: r.email ?? "",
    notes: r.notes ?? undefined,
    status: r.status as Booking["status"],
    adminNote: r.adminNote ?? undefined,
  };
}

export function bookingToRow(b: Booking) {
  return {
    bookingId: b.bookingId,
    userName: b.userName,
    uid: b.uid,
    role: b.role,
    dept: b.dept,
    subject: b.subject,
    equipmentId: b.equipmentId,
    equipmentName: b.equipmentName,
    quantity: b.quantity,
    date: b.date,
    startTime: b.startTime,
    endTime: b.endTime,
    purpose: b.purpose,
    returnDate: b.returnDate,
    returnTime: b.returnTime,
    phone: b.phone,
    email: b.email,
    notes: b.notes ?? null,
    status: b.status,
    adminNote: b.adminNote ?? null,
  };
}

/** Inserts the seed catalogue if the tables are empty; safe to call repeatedly. */
export async function ensureSeeded() {
  const [{ count }] = await db.select({ count: sql<number>`count(*)::int` }).from(equipment);
  if (Number(count) > 0) return { seeded: false as const, count: Number(count) };

  await db
    .insert(departments)
    .values(
      DEPARTMENTS.map((d) => ({
        key: d.key,
        name: d.name,
        short: d.short,
        tagline: d.tagline,
        description: d.description,
        hod: d.hod,
        building: d.building,
        floor: d.floor,
        contact: d.contact,
        hue: d.hue,
        icon: d.icon,
      })),
    )
    .onConflictDoNothing();

  await db
    .insert(subjects)
    .values(
      SUBJECTS.map((s) => ({
        slug: s.slug,
        dept: s.dept,
        name: s.name,
        code: s.code,
        semester: s.semester,
        room: s.room,
        description: s.description ?? null,
        labHours: s.labHours,
        supervisor: s.supervisor,
        safety: s.safety,
        outcomes: s.outcomes,
      })),
    )
    .onConflictDoNothing();

  await db.insert(equipment).values(SEED_EQUIPMENT.map(equipmentToRow)).onConflictDoNothing();
  const [{ count: after }] = await db.select({ count: sql<number>`count(*)::int` }).from(equipment);
  return { seeded: true as const, count: Number(after) };
}

export async function listEquipment(): Promise<Equipment[]> {
  const rows = await db.select().from(equipment).orderBy(asc(equipment.name));
  return rows.map(rowToEquipment);
}

export async function listBookings(): Promise<Booking[]> {
  const rows = await db.select().from(bookings).orderBy(sql`${bookings.createdAt} desc nulls last`);
  return rows.map(rowToBooking);
}

export async function upsertEquipment(row: Equipment) {
  await db.insert(equipment).values(equipmentToRow(row)).onConflictDoUpdate({ target: equipment.id, set: equipmentToRow(row) });
}

export async function updateEquipmentById(id: string, patch: Partial<Equipment>) {
  const data: Record<string, unknown> = {};
  if (patch.name !== undefined) data.name = patch.name;
  if (patch.quantity !== undefined) data.quantity = patch.quantity;
  if (patch.maintenance !== undefined) data.maintenance = patch.maintenance;
  if (patch.manufacturer !== undefined) data.manufacturer = patch.manufacturer;
  if (patch.model !== undefined) data.model = patch.model;
  if (patch.photo !== undefined) data.photo = patch.photo;
  if (patch.short !== undefined) data.shortDesc = patch.short;
  if (patch.category !== undefined) data.category = patch.category;
  if (Object.keys(data).length === 0) return 0;
  const res = await db.update(equipment).set(data).where(eq(equipment.id, id));
  return (res as unknown as { rowCount?: number }).rowCount ?? 0;
}

export async function deleteEquipmentById(id: string) {
  const res = await db.delete(equipment).where(eq(equipment.id, id));
  return (res as unknown as { rowCount?: number }).rowCount ?? 0;
}

export async function insertBooking(b: Booking) {
  await db.insert(bookings).values(bookingToRow(b)).onConflictDoNothing();
  return true;
}

export async function patchBooking(id: string, patch: { status?: string; adminNote?: string }) {
  const data: Record<string, unknown> = {};
  if (patch.status) data.status = patch.status;
  if (patch.adminNote !== undefined) data.adminNote = patch.adminNote;
  if (Object.keys(data).length === 0) return null;
  const res = await db.update(bookings).set(data).where(eq(bookings.bookingId, id)).returning();
  return res[0] ? rowToBooking(res[0]) : null;
}

export async function addSubjectSubject(lab: { dept: string; slug: string; name: string; code?: string }) {
  await db
    .insert(subjects)
    .values({ slug: lab.slug, dept: lab.dept, name: lab.name, code: lab.code ?? "LAB-NEW", outcomes: [] })
    .onConflictDoNothing();
}

export async function addDepartmentRow(dept: { key: string; name: string }) {
  await db
    .insert(departments)
    .values({ key: dept.key, name: dept.name, short: dept.key.slice(0, 4).toUpperCase(), hue: 200 })
    .onConflictDoUpdate({ target: departments.key, set: { name: dept.name } });
}

export const dbHealthy = async () => {
  try {
    await db.execute(sql`select 1`);
    return true;
  } catch {
    return false;
  }
};

export { departments, subjects, equipment, bookings };
export { and, eq };
