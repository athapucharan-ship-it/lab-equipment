"use client";

import Link from "next/link";
import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { AVAILABILITY_META, type Availability } from "@/lib/data";

/* ---------------------------------- styles --------------------------------- */

export const CARD =
  "rounded-2xl border border-slate-200/80 bg-white shadow-[var(--shadow-card)] dark:border-navy-700/60 dark:bg-navy-900/80";
export const CARD_SOFT =
  "rounded-xl border border-slate-200 bg-slate-50/70 dark:border-navy-700/50 dark:bg-navy-950/40";
export const INPUT =
  "w-full rounded-xl border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-navy-900 outline-none transition placeholder:text-slate-400 focus:border-navy-500 focus:ring-4 focus:ring-navy-500/12 disabled:opacity-60 dark:border-navy-700 dark:bg-navy-950/60 dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:border-navy-400";
export const LABEL =
  "mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500 dark:text-slate-400";

export const btn = (variant: "primary" | "gold" | "ghost" | "outline" | "danger" | "subtle" = "primary", size: "sm" | "md" | "lg" = "md") =>
  [
    "inline-flex items-center justify-center gap-2 rounded-xl font-semibold transition-all duration-200 lb-ring-focus active:translate-y-px disabled:cursor-not-allowed disabled:opacity-50",
    size === "sm" ? "px-3 py-1.5 text-xs" : size === "lg" ? "px-6 py-3.5 text-[15px]" : "px-4 py-2.5 text-sm",
    variant === "primary" &&
      "bg-navy-800 text-white shadow-[0_10px_24px_-14px_rgb(11,31,58,0.9)] hover:bg-navy-700 dark:bg-navy-600 dark:hover:bg-navy-500",
    variant === "gold" && "bg-gold-400 text-navy-950 hover:bg-gold-300 shadow-[0_10px_24px_-14px_rgb(245,189,74,0.9)]",
    variant === "outline" &&
      "border border-slate-300 bg-white/70 text-navy-800 hover:border-navy-400 hover:bg-white dark:border-navy-600 dark:bg-transparent dark:text-slate-100 dark:hover:bg-navy-800",
    variant === "ghost" && "text-navy-700 hover:bg-navy-50 dark:text-slate-200 dark:hover:bg-navy-800/70",
    variant === "subtle" && "bg-navy-50 text-navy-800 hover:bg-navy-100 dark:bg-navy-800 dark:text-slate-100 dark:hover:bg-navy-700",
    variant === "danger" && "bg-rose-600 text-white hover:bg-rose-500",
  ]
    .filter(Boolean)
    .join(" ");

/* ----------------------------------- icon ----------------------------------- */

const ICONS: Record<string, string> = {
  search: "M11 4a7 7 0 1 0 0 14 7 7 0 0 0 0-14Zm10 17-4.35-4.35",
  calendar: "M8 2v4m8-4v4M3 9h18M5 6h14a2 2 0 0 1 2 2v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2Z",
  clock: "M12 7v5l3 2m6-2a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z",
  check: "M20 6 9 17l-5-5",
  close: "M18 6 6 18M6 6l12 12",
  chevronRight: "m9 6 6 6-6 6",
  chevronLeft: "m15 6-6 6 6 6",
  arrowRight: "M5 12h14m-6-6 6 6-6 6",
  back: "M19 12H5m7 7-7-7 7-7",
  building: "M4 21V7l8-4 8 4v14M9 21v-6h6v6",
  box: "M21 8 12 3 3 8l9 5 9-5ZM3 8v8l9 5 9-5V8M12 13v8",
  layers: "m12 2 9 5-9 5-9-5 9-5Zm9 12-9 5-9-5m18 5-9 5-9-5",
  wrench: "M14.7 6.3a4 4 0 1 0-5.4 5.4L4 17v3h3l5.3-5.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4 2.5-2.5Z",
  heart: "M12 20s-7.5-4.6-9.3-9A5.2 5.2 0 0 1 12 6.4 5.2 5.2 0 0 1 21.3 11c-1.8 4.4-9.3 9-9.3 9Z",
  compare: "M9 3v18M3 7h6M3 12h6m6-9v18M15 7h6m-6 5h6",
  user: "M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8Zm8 9a8 8 0 1 0-16 0",
  logout: "M15 12H3m4-4-4 4 4 4m6-10h6a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-6",
  login: "M10 12H2m4-4-4 4 4 4m6-10h4a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-4",
  print: "M7 8V3h10v5M7 18H5a2 2 0 0 1-2-2v-4a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v4a2 2 0 0 1-2 2h-2m-10 0v3h10v-3",
  plus: "M12 5v14M5 12h14",
  minus: "M5 12h14",
  trash: "M4 7h16m-14 0 1 13h8l1-13M9 7V4h6v3",
  edit: "M4 20h4L20 8l-4-4L4 16v4Z",
  sun: "M12 17a5 5 0 1 0 0-10 5 5 0 0 0 0 10Zm0-14v2m0 18v-2M3 12h2m14 0h2M5.6 5.6 7 7m10 10 1.4 1.4M18.4 5.6 17 7M7 17l-1.4 1.4",
  moon: "M21 12.8A9 9 0 1 1 11.2 3a7 7 0 0 0 9.8 9.8Z",
  menu: "M4 7h16M4 12h16M4 17h16",
  bell: "M18 9a6 6 0 1 0-12 0c0 5-2 6-2 6h16s-2-1-2-6ZM13.7 20a2 2 0 0 1-3.4 0",
  info: "M12 8h.01M11 12h1v5h1M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18Z",
  alert: "M12 9v4m0 4h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z",
  qr: "M4 4h6v6H4V4Zm10 0h6v6h-6V4ZM4 14h6v6H4v-6Zm12 2h2v2h-2v-2Zm2 2h2v2h-2m-4-2h2v6h-4v-2h2v-2Z",
  filter: "M4 5h16l-6 7v6l-4 2v-8L4 5Z",
  download: "M12 4v10m0 0 4-4m-4 4-4-4M5 19h14",
  eye: "M2 12s3.6-6 10-6 10 6 10 6-3.6 6-10 6-10-6-10-6Zm10 2.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z",
  mail: "M4 6h16a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1Zm0 1 8 6 8-6",
  phone: "M6 3h3l2 5-2 1a12 12 0 0 0 6 6l1-2 5 2v3a2 2 0 0 1-2 2A17 17 0 0 1 4 5a2 2 0 0 1 2-2Z",
  pin: "M12 21s7-6.3 7-11a7 7 0 1 0-14 0c0 4.7 7 11 7 11Zm0-8.5a2.5 2.5 0 1 0 0-5 2.5 2.5 0 0 0 0 5Z",
  sparkle: "m12 3 1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3Z",
  book: "M4 5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2V5Z",
  grid: "M4 4h7v7H4V4Zm9 0h7v7h-7V4ZM4 13h7v7H4v-7Zm9 0h7v7h-7v-7Z",
  shield: "M12 3l8 3v6c0 5-3.4 8.2-8 9-4.6-.8-8-4-8-9V6l8-3Z",
  ruler: "M3.5 13.5 13.5 3.5l7 7-10 10-7-7Zm3-1 2 2m1-5 2 2m1-5 2 2m1-5 2 2",
};

export function Icon({ name, className = "h-4 w-4", strokeWidth = 1.8 }: { name: keyof typeof ICONS | string; className?: string; strokeWidth?: number }) {
  const d = ICONS[name] ?? ICONS.info;
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={strokeWidth} strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden="true">
      <path d={d} />
    </svg>
  );
}

/* --------------------------------- buttons --------------------------------- */

export function Button({
  children,
  variant = "primary",
  size = "md",
  className = "",
  ...rest
}: {
  children: ReactNode;
  variant?: "primary" | "gold" | "ghost" | "outline" | "danger" | "subtle";
  size?: "sm" | "md" | "lg";
} & React.ButtonHTMLAttributes<HTMLButtonElement>) {
  return (
    <button {...rest} className={`${btn(variant, size)} ${className}`}>
      {children}
    </button>
  );
}

export function LinkButton({
  href,
  children,
  variant = "primary",
  size = "md",
  className = "",
  ...rest
}: {
  href: string;
  children: ReactNode;
  variant?: "primary" | "gold" | "ghost" | "outline" | "danger" | "subtle";
  size?: "sm" | "md" | "lg";
} & Omit<React.ComponentProps<typeof Link>, "href" | "children">) {
  return (
    <Link href={href} {...rest} className={`${btn(variant, size)} ${className}`}>
      {children}
    </Link>
  );
}

/* --------------------------------- badges ---------------------------------- */

export function StatusBadge({ status, size = "md" }: { status: Availability; size?: "sm" | "md" }) {
  const meta = AVAILABILITY_META[status];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full ring-1 ${meta.chip} ${meta.text} ${
        size === "sm" ? "px-2 py-0.5 text-[11px]" : "px-2.5 py-1 text-xs"
      } font-semibold`}
    >
      <span className={`h-1.5 w-1.5 rounded-full ${meta.dot}`} />
      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.2} strokeLinecap="round" className="h-3 w-3">
        <path d={meta.icon} />
      </svg>
      {meta.label}
    </span>
  );
}

export const BOOKING_STATUS_STYLE: Record<string, string> = {
  Pending: "bg-amber-50 text-amber-700 ring-amber-200 dark:bg-amber-500/10 dark:text-amber-300 dark:ring-amber-500/30",
  Approved: "bg-navy-50 text-navy-700 ring-navy-200 dark:bg-navy-500/10 dark:text-navy-200 dark:ring-navy-500/30",
  Active: "bg-emerald-50 text-emerald-700 ring-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-300 dark:ring-emerald-500/30",
  Completed: "bg-slate-100 text-slate-600 ring-slate-300 dark:bg-slate-500/10 dark:text-slate-300 dark:ring-slate-500/30",
  Cancelled: "bg-rose-50 text-rose-700 ring-rose-200 dark:bg-rose-500/10 dark:text-rose-300 dark:ring-rose-500/30",
  Rejected: "bg-rose-50 text-rose-700 ring-rose-200 dark:bg-rose-500/10 dark:text-rose-300 dark:ring-rose-500/30",
};

export function BookingBadge({ status }: { status: string }) {
  return (
    <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-semibold ring-1 ${BOOKING_STATUS_STYLE[status] ?? BOOKING_STATUS_STYLE.Completed}`}>
      <Icon name={status === "Active" ? "clock" : status === "Pending" ? "alert" : status === "Approved" ? "check" : status.startsWith("C") || status === "Rejected" ? "close" : "book"} className="h-3.5 w-3.5" />
      {status}
    </span>
  );
}

export function Chip({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <span className={`inline-flex items-center gap-1.5 rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-medium text-slate-600 ring-1 ring-slate-200 dark:bg-navy-800 dark:text-slate-300 dark:ring-navy-700 ${className}`}>{children}</span>;
}

/* -------------------------------- layout bits ------------------------------- */

export function SectionTitle({ eyebrow, title, sub, right }: { eyebrow?: string; title: string; sub?: string; right?: ReactNode }) {
  return (
    <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
      <div>
        {eyebrow && <div className="mb-1.5 text-[11px] font-bold uppercase tracking-[0.2em] text-navy-500 dark:text-gold-400">{eyebrow}</div>}
        <h2 className="font-display text-2xl font-bold tracking-tight text-navy-900 sm:text-[28px] dark:text-white">{title}</h2>
        {sub && <p className="mt-2 max-w-2xl text-sm leading-relaxed text-slate-600 dark:text-slate-400">{sub}</p>}
      </div>
      {right}
    </div>
  );
}

export function Breadcrumbs({ trail }: { trail: { label: string; href?: string }[] }) {
  return (
    <nav aria-label="Breadcrumb" className="mb-5 flex flex-wrap items-center gap-1.5 text-[13px]">
      {trail.map((t, i) => (
        <span key={`${t.label}-${i}`} className="flex items-center gap-1.5">
          {i > 0 && <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />}
          {t.href ? (
            <Link href={t.href} className="rounded px-1 font-medium text-navy-600 transition hover:text-navy-900 hover:underline dark:text-navy-200 dark:hover:text-white">
              {t.label}
            </Link>
          ) : (
            <span className="px-1 font-semibold text-slate-500 dark:text-slate-400" aria-current="page">
              {t.label}
            </span>
          )}
        </span>
      ))}
    </nav>
  );
}

export function Skeleton({ className = "" }: { className?: string }) {
  return <div className={`skeleton rounded-xl ${className}`} />;
}

export function LoadingBlock({ label = "Loading laboratory data…" }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 py-16 text-slate-500 dark:text-slate-400">
      <Spinner />
      <p className="text-sm font-medium">{label}</p>
    </div>
  );
}

export function Spinner({ className = "" }: { className?: string }) {
  return (
    <span className={`lb-spin inline-block h-6 w-6 rounded-full border-2 border-navy-200 border-t-navy-700 dark:border-navy-700 dark:border-t-gold-400 ${className}`} aria-hidden />
  );
}

export function EmptyState({ title, body, action }: { title: string; body: string; action?: ReactNode }) {
  return (
    <div className={`${CARD} flex flex-col items-center gap-3 px-6 py-14 text-center`}>
      <span className="grid h-12 w-12 place-items-center rounded-2xl bg-navy-50 text-navy-500 dark:bg-navy-800 dark:text-navy-200">
        <Icon name="box" className="h-6 w-6" />
      </span>
      <h3 className="font-display text-lg font-bold text-navy-900 dark:text-white">{title}</h3>
      <p className="max-w-md text-sm text-slate-600 dark:text-slate-400">{body}</p>
      {action}
    </div>
  );
}

export function StatCard({ label, value, hint, icon, tone = "navy" }: { label: string; value: ReactNode; hint?: string; icon: string; tone?: "navy" | "gold" | "emerald" | "rose" | "sky" | "violet" }) {
  const tones: Record<string, string> = {
    navy: "from-navy-800 to-navy-600 text-white",
    gold: "from-gold-500 to-gold-400 text-navy-950",
    emerald: "from-emerald-600 to-emerald-500 text-white",
    rose: "from-rose-600 to-rose-500 text-white",
    sky: "from-sky-600 to-sky-500 text-white",
    violet: "from-violet-600 to-violet-500 text-white",
  };
  return (
    <div className={`${CARD} group relative overflow-hidden p-4 transition-all duration-300 hover:-translate-y-0.5 hover:shadow-[var(--shadow-lift)]`}>
      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-500 dark:text-slate-400">{label}</div>
          <div className="mt-1.5 font-display text-3xl font-extrabold leading-none text-navy-900 dark:text-white">{value}</div>
          {hint && <div className="mt-2 text-xs text-slate-500 dark:text-slate-400">{hint}</div>}
        </div>
        <span className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-gradient-to-br ${tones[tone]} shadow-inner`}>
          <Icon name={icon} className="h-5 w-5" strokeWidth={2} />
        </span>
      </div>
    </div>
  );
}

/* --------------------------------- toasts ---------------------------------- */

type Toast = { id: number; tone: "success" | "error" | "info" | "warn"; title: string; body?: string };
const ToastCtx = createContext<{ push: (t: Omit<Toast, "id">) => void } | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [toasts, setToasts] = useState<Toast[]>([]);
  const push = useCallback((t: Omit<Toast, "id">) => {
    const id = Date.now() + Math.random();
    setToasts((prev) => [...prev.slice(-3), { ...t, id }]);
    setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 4800);
  }, []);
  const value = useMemo(() => ({ push }), [push]);
  const toneStyle: Record<Toast["tone"], { ring: string; icon: string; name: string }> = {
    success: { ring: "ring-emerald-300 dark:ring-emerald-500/40", icon: "bg-emerald-500 text-white", name: "check" },
    error: { ring: "ring-rose-300 dark:ring-rose-500/40", icon: "bg-rose-500 text-white", name: "alert" },
    info: { ring: "ring-navy-300 dark:ring-navy-500/40", icon: "bg-navy-700 text-white", name: "info" },
    warn: { ring: "ring-amber-300 dark:ring-amber-500/40", icon: "bg-amber-500 text-navy-950", name: "bell" },
  };
  return (
    <ToastCtx.Provider value={value}>
      {children}
      <div className="print-full pointer-events-none fixed inset-x-0 bottom-0 z-[70] flex flex-col items-center gap-2 p-4 sm:items-end sm:p-6 no-print">
        {toasts.map((t) => (
          <div key={t.id} className={`lb-toast pointer-events-auto w-full max-w-sm rounded-2xl ${CARD} p-3.5 ring-1 ${toneStyle[t.tone].ring}`}>
            <div className="flex gap-3">
              <span className={`mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-lg ${toneStyle[t.tone].icon}`}>
                <Icon name={toneStyle[t.tone].name} className="h-4 w-4" strokeWidth={2.2} />
              </span>
              <div className="min-w-0 flex-1">
                <p className="text-sm font-bold text-navy-900 dark:text-white">{t.title}</p>
                {t.body && <p className="mt-0.5 text-[13px] leading-snug text-slate-600 dark:text-slate-300">{t.body}</p>}
              </div>
              <button onClick={() => setToasts((p) => p.filter((x) => x.id !== t.id))} className="shrink-0 rounded-lg p-1 text-slate-400 transition hover:bg-slate-100 hover:text-slate-700 dark:hover:bg-navy-800" aria-label="Dismiss notification">
                <Icon name="close" className="h-4 w-4" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

export function useToast() {
  const ctx = useContext(ToastCtx);
  return ctx ?? { push: () => undefined };
}

/* -------------------------------- theme ---------------------------------- */

export function useThemeMode() {
  const [dark, setDark] = useState(false);
  useEffect(() => {
    setDark(document.documentElement.classList.contains("dark"));
  }, []);
  const toggle = useCallback(() => {
    const next = !document.documentElement.classList.contains("dark");
    localStorage.setItem("labbook.theme", next ? "dark" : "light");
    document.documentElement.classList.toggle("dark", next);
    window.dispatchEvent(new Event("labbook:theme"));
    setDark(next);
  }, []);
  return { dark, toggle };
}

export function ThemeToggle() {
  const { dark, toggle } = useThemeMode();
  return (
    <button
      onClick={toggle}
      title={dark ? "Switch to light mode" : "Switch to dark mode"}
      aria-label="Toggle dark mode"
      className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200 bg-white text-navy-700 transition hover:border-navy-300 hover:text-navy-900 dark:border-navy-700 dark:bg-navy-900 dark:text-slate-200 dark:hover:border-gold-400/50"
    >
      <Icon name={dark ? "sun" : "moon"} className="h-4 w-4" />
    </button>
  );
}

/* ------------------------------- misc helpers ------------------------------ */

export function KeyValue({ k, v }: { k: string; v: ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-4 border-b border-dashed border-slate-200 py-2 text-sm last:border-0 dark:border-navy-700/60">
      <span className="shrink-0 font-medium text-slate-500 dark:text-slate-400">{k}</span>
      <span className="text-right font-semibold text-navy-900 dark:text-slate-100">{v}</span>
    </div>
  );
}

export function Field({ label, hint, error, children }: { label: string; hint?: string; error?: string; children: ReactNode }) {
  return (
    <label className="block">
      <span className={LABEL}>{label}</span>
      {children}
      {error ? (
        <span className="mt-1 flex items-center gap-1 text-[12px] font-medium text-rose-600 dark:text-rose-400">
          <Icon name="alert" className="h-3.5 w-3.5" /> {error}
        </span>
      ) : (
        hint && <span className="mt-1 block text-[12px] text-slate-500 dark:text-slate-400">{hint}</span>
      )}
    </label>
  );
}
