"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useEffect, useState, type ReactNode } from "react";
import { DEPARTMENTS, COLLEGE_NAME, COLLEGE_SHORT } from "@/lib/data";
import { useLabbook } from "@/lib/store";
import { Icon, ThemeToggle, btn } from "./ui";

const NAV = [
  { href: "/", label: "Home" },
  { href: "/departments", label: "Departments" },
  { href: "/equipment", label: "Equipment" },
  { href: "/my-bookings", label: "My Bookings" },
  { href: "/about", label: "About" },
  { href: "/contact", label: "Contact" },
];

export function Logo({ compact = false }: { compact?: boolean }) {
  return (
    <Link href="/" className="group flex items-center gap-3" aria-label="LABBOOK home">
      <span className="relative grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-navy-800 via-navy-700 to-navy-500 text-white shadow-[0_10px_24px_-14px_rgb(11,31,58,0.9)]">
        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.9} strokeLinecap="round" strokeLinejoin="round">
          <path d="M9 3h6M10 3v6L5 19a2 2 0 0 0 1.8 3h10.4A2 2 0 0 0 19 19l-5-10V3" />
          <path d="M7.5 15h9" className="opacity-70" />
        </svg>
        <span className="absolute -bottom-1 -right-1 grid h-4 w-4 place-items-center rounded-md bg-gold-400 text-[9px] font-black text-navy-950">B</span>
      </span>
      {!compact && (
        <span className="leading-tight">
          <span className="block font-display text-[17px] font-extrabold tracking-tight text-navy-900 dark:text-white">
            LAB<span className="text-gold-500 dark:text-gold-400">BOOK</span>
          </span>
          <span className="block text-[10.5px] font-semibold uppercase tracking-[0.14em] text-slate-500 dark:text-slate-400">{COLLEGE_SHORT} · Lab Equipment Booking</span>
        </span>
      )}
    </Link>
  );
}

export function Header() {
  const pathname = usePathname();
  const router = useRouter();
  const { session, items } = useLabbook();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const [deptOpen, setDeptOpen] = useState(false);

  useEffect(() => setOpen(false), [pathname]);

  const go = () => {
    const term = q.trim();
    router.push(term ? `/equipment?q=${encodeURIComponent(term)}` : "/equipment");
  };

  const isActive = (href: string) => (href === "/" ? pathname === "/" : pathname.startsWith(href));

  return (
    <header className="no-print sticky top-0 z-50 border-b border-slate-200/80 bg-white/85 backdrop-blur-xl dark:border-navy-800 dark:bg-navy-950/85">
      <div className="mx-auto flex h-[68px] max-w-[1240px] items-center gap-3 px-4 sm:px-6">
        <Logo />

        <nav className="ml-4 hidden items-center gap-0.5 xl:flex">
          {NAV.map((n) => (
            <Link
              key={n.href}
              href={n.href}
              className={`relative rounded-lg px-3 py-2 text-[13.5px] font-semibold transition ${
                isActive(n.href)
                  ? "text-navy-900 dark:text-white"
                  : "text-slate-600 hover:bg-slate-100 hover:text-navy-900 dark:text-slate-300 dark:hover:bg-navy-800/70 dark:hover:text-white"
              }`}
            >
              {n.label}
              {isActive(n.href) && <span className="absolute inset-x-2.5 -bottom-[1px] h-[2px] rounded-full bg-gold-400" />}
            </Link>
          ))}
        </nav>

        <div className="ml-auto hidden items-center gap-2 lg:flex">
          <div className="relative">
            <Icon name="search" className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && go()}
              placeholder="Search equipment, ID, lab…"
              aria-label="Search equipment"
              className="w-56 rounded-xl border border-slate-200 bg-slate-50/80 py-2 pl-8 pr-3 text-[13px] outline-none transition focus:w-72 focus:border-navy-400 focus:bg-white dark:border-navy-700 dark:bg-navy-900 dark:text-slate-100"
            />
          </div>

          <div className="relative">
            <button onClick={() => setDeptOpen((v) => !v)} onBlur={() => setTimeout(() => setDeptOpen(false), 160)} className={btn("outline", "sm")} aria-expanded={deptOpen}>
              <Icon name="layers" className="h-4 w-4" /> Departments <Icon name="chevronRight" className="h-3.5 w-3.5 rotate-90" />
            </button>
            {deptOpen && (
              <div className="absolute right-0 top-[calc(100%+8px)] z-50 w-72 rounded-2xl border border-slate-200 bg-white p-2 shadow-[var(--shadow-lift)] dark:border-navy-700 dark:bg-navy-900">
                {DEPARTMENTS.map((d) => (
                  <Link key={d.key} href={`/departments/${d.key}`} className="flex items-center gap-2.5 rounded-xl px-2.5 py-2 text-[13px] font-semibold text-slate-700 transition hover:bg-slate-100 dark:text-slate-200 dark:hover:bg-navy-800">
                    <span className="grid h-7 w-7 place-items-center rounded-lg text-white" style={{ background: `hsl(${d.hue} 55% 38%)` }}>
                      <span className="text-[10px] font-black">{d.short.slice(0, 4)}</span>
                    </span>
                    <span className="flex-1 truncate">{d.name}</span>
                    <span className="text-[11px] text-slate-400">{items.filter((i) => i.dept === d.key).length}</span>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {session ? (
            <Link href={session.role === "admin" ? "/admin" : "/my-bookings"} className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-2.5 py-1.5 text-[13px] font-semibold text-navy-800 transition hover:border-navy-300 dark:border-navy-700 dark:bg-navy-900 dark:text-slate-100">
              <span className="grid h-6 w-6 place-items-center rounded-lg bg-navy-700 text-[10px] font-black text-white">{session.name.slice(0, 1)}</span>
              <span className="max-w-[90px] truncate">{session.name.split(" ")[0]}</span>
              <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[10px] uppercase tracking-wide text-slate-500 dark:bg-navy-800 dark:text-slate-400">{session.role}</span>
            </Link>
          ) : (
            <Link href="/login" className={btn("primary", "sm")}>
              <Icon name="login" className="h-4 w-4" /> Login
            </Link>
          )}
          <ThemeToggle />
        </div>

        <div className="ml-auto flex items-center gap-2 lg:hidden">
          <ThemeToggle />
          <button onClick={() => setOpen((v) => !v)} className="grid h-9 w-9 place-items-center rounded-xl border border-slate-200 text-navy-800 dark:border-navy-700 dark:text-slate-100" aria-label="Toggle navigation menu" aria-expanded={open}>
            <Icon name={open ? "close" : "menu"} className="h-5 w-5" />
          </button>
        </div>
      </div>

      {open && (
        <div className="border-t border-slate-200 bg-white px-4 pb-4 pt-3 lg:hidden dark:border-navy-800 dark:bg-navy-950">
          <div className="mb-3 flex gap-2">
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && go()}
              placeholder="Search equipment, ID, lab…"
              aria-label="Search equipment"
              className="flex-1 rounded-xl border border-slate-200 bg-slate-50 px-3 py-2 text-sm outline-none dark:border-navy-700 dark:bg-navy-900 dark:text-slate-100"
            />
            <button onClick={go} className={btn("primary", "sm")}>Go</button>
          </div>
          <div className="grid gap-1">
            {NAV.map((n) => (
              <Link key={n.href} href={n.href} className={`rounded-xl px-3 py-2.5 text-sm font-semibold ${isActive(n.href) ? "bg-navy-50 text-navy-900 dark:bg-navy-800 dark:text-white" : "text-slate-600 dark:text-slate-300"}`}>
                {n.label}
              </Link>
            ))}
            <Link href="/favorites" className="rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-600 dark:text-slate-300">Favourites</Link>
            <Link href="/compare" className="rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-600 dark:text-slate-300">Compare equipment</Link>
            <Link href="/admin" className="rounded-xl px-3 py-2.5 text-sm font-semibold text-slate-600 dark:text-slate-300">Admin dashboard</Link>
            <Link href={session ? "/my-bookings" : "/login"} className={`${btn(session ? "outline" : "primary", "sm")} mt-2`}>
              <Icon name={session ? "logout" : "login"} className="h-4 w-4" /> {session ? `Signed in as ${session.name}` : "Login / Register"}
            </Link>
          </div>
          <div className="mt-3 grid grid-cols-2 gap-1">
            {DEPARTMENTS.map((d) => (
              <Link key={d.key} href={`/departments/${d.key}`} className="rounded-lg bg-slate-50 px-2.5 py-2 text-[12px] font-semibold text-slate-600 dark:bg-navy-900 dark:text-slate-300">
                {d.short}
              </Link>
            ))}
          </div>
        </div>
      )}
    </header>
  );
}

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="no-print mt-16 border-t border-navy-800 bg-navy-950 text-slate-300">
      <div className="mx-auto grid max-w-[1240px] gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.4fr_1fr_1fr_1.2fr]">
        <div>
          <div className="flex items-center gap-3">
            <span className="grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-gold-400 to-gold-600 text-navy-950">
              <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <path d="M9 3h6M10 3v6L5 19a2 2 0 0 0 1.8 3h10.4A2 2 0 0 0 19 19l-5-10V3" />
              </svg>
            </span>
            <div>
              <div className="font-display text-lg font-extrabold tracking-tight text-white">
                LAB<span className="text-gold-400">BOOK</span>
              </div>
              <div className="text-[11px] uppercase tracking-[0.16em] text-slate-400">Laboratory Management System</div>
            </div>
          </div>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-slate-400">
            {COLLEGE_NAME} — department-wise laboratory equipment catalogue, live availability and booking for students, faculty and laboratory staff.
          </p>
          <p className="mt-4 text-xs text-slate-500">
            Equipment photographs are licensed under the Pexels License. Credits are shown on every equipment detail page.
          </p>
        </div>

        <div>
          <h4 className="mb-3 text-[11px] font-bold uppercase tracking-[0.18em] text-white">Quick links</h4>
          <ul className="space-y-2 text-sm">
            {[...NAV, { href: "/faq", label: "FAQ" }, { href: "/booking", label: "New booking" }, { href: "/admin", label: "Admin dashboard" }, { href: "/favorites", label: "Favourites" }].map((l) => (
              <li key={l.href + l.label}>
                <Link href={l.href} className="text-slate-400 transition hover:text-gold-300">
                  {l.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="mb-3 text-[11px] font-bold uppercase tracking-[0.18em] text-white">Departments</h4>
          <ul className="space-y-2 text-sm">
            {DEPARTMENTS.map((d) => (
              <li key={d.key}>
                <Link href={`/departments/${d.key}`} className="text-slate-400 transition hover:text-gold-300">
                  {d.short} — {d.name.split("(")[0].replace(/^[^&]*& /, "").slice(0, 22)}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        <div>
          <h4 className="mb-3 text-[11px] font-bold uppercase tracking-[0.18em] text-white">Contact</h4>
          <ul className="space-y-3 text-sm text-slate-400">
            <li className="flex gap-2.5">
              <Icon name="pin" className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
              <span>Tech Park Main Road, Tirumalagiri, Hyderabad 500079, Telangana</span>
            </li>
            <li className="flex gap-2.5">
              <Icon name="mail" className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
              <a href="mailto:lab.booking@svcoet.edu.in" className="transition hover:text-gold-300">lab.booking@svcoet.edu.in</a>
            </li>
            <li className="flex gap-2.5">
              <Icon name="phone" className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
              <a href="tel:+914023001234" className="transition hover:text-gold-300">+91 40 2300 1234 (Lab store · Ext. 110)</a>
            </li>
            <li className="flex gap-2.5">
              <Icon name="clock" className="mt-0.5 h-4 w-4 shrink-0 text-gold-400" />
              <span>Issue counter: Mon–Sat · 08:40 – 17:00</span>
            </li>
          </ul>
        </div>
      </div>

      <div className="border-t border-navy-800/80">
        <div className="mx-auto flex max-w-[1240px] flex-col gap-2 px-4 py-5 text-xs text-slate-500 sm:flex-row sm:items-center sm:justify-between sm:px-6">
          <p>© {year} {COLLEGE_NAME}. LABBOOK — College Laboratory Equipment Booking System. Demonstration build (data stored in your browser).</p>
          <p className="flex flex-wrap gap-4">
            <Link href="/faq" className="hover:text-gold-300">Help & FAQ</Link>
            <Link href="/contact" className="hover:text-gold-300">Report an issue</Link>
            <span>Built with HTML5 · CSS3 · JavaScript</span>
          </p>
        </div>
      </div>
    </footer>
  );
}

/** Floating compare tray (max 4 items) — appears when the user adds equipment to compare. */
function CompareTray() {
  const { compare, items, toggleCompare } = useLabbook();
  const pathname = usePathname();
  if (!compare.length || pathname.startsWith("/compare")) return null;
  const names = compare.map((id) => items.find((i) => i.id === id)?.name ?? id);
  return (
    <div className="no-print fixed bottom-4 left-1/2 z-40 w-[min(92vw,640px)] -translate-x-1/2 rounded-2xl border border-slate-200 bg-white/95 p-3 shadow-[var(--shadow-lift)] backdrop-blur dark:border-navy-700 dark:bg-navy-900/95">
      <div className="flex flex-wrap items-center gap-3">
        <span className="flex items-center gap-2 text-[13px] font-bold text-navy-900 dark:text-white">
          <Icon name="compare" className="h-4 w-4 text-gold-500" /> Compare ({compare.length}/4)
        </span>
        <span className="min-w-0 flex-1 truncate text-[12.5px] text-slate-600 dark:text-slate-300">{names.join(" · ")}</span>
        <Link href="/compare" className={btn("primary", "sm")}>Compare now</Link>
        <button onClick={() => compare.forEach((id) => toggleCompare(id))} className={btn("ghost", "sm")}>Clear</button>
      </div>
    </div>
  );
}

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen flex-col bg-slate-50 text-navy-900 dark:bg-navy-950 dark:text-slate-100">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:left-2 focus:top-2 focus:z-[80] focus:rounded-lg focus:bg-navy-800 focus:px-3 focus:py-2 focus:text-white">
        Skip to main content
      </a>
      <Header />
      <main id="main" className="flex-1">
        {children}
      </main>
      <Footer />
      <CompareTray />
    </div>
  );
}

export function BackLink({ href, label }: { href: string; label: string }) {
  const router = useRouter();
  return (
    <div className="mb-4 flex flex-wrap items-center gap-2">
      <button onClick={() => router.back()} className={btn("outline", "sm")} title="Go back to the previous page">
        <Icon name="back" className="h-4 w-4" /> Back
      </button>
      <Link href={href} className={btn("ghost", "sm")}>
        <Icon name="chevronLeft" className="h-4 w-4" /> {label}
      </Link>
    </div>
  );
}

export function Page({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`mx-auto w-full max-w-[1240px] px-4 py-8 sm:px-6 lg:py-10 ${className}`}>{children}</div>;
}
