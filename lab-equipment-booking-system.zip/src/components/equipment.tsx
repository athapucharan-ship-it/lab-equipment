"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { photoSrc, photoCredit, type PhotoKey } from "@/lib/images";
import type { Derived } from "@/lib/data";
import { useLabbook } from "@/lib/store";
import { CARD, Chip, Icon, LinkButton, Skeleton, StatusBadge, btn } from "./ui";

/** Clearly-marked placeholder used when a remote photograph cannot be loaded. */
export function placeholderDataUri(label: string) {
  const text = (label || "Equipment photograph").slice(0, 30);
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="800" height="560" viewBox="0 0 800 560">
<rect width="800" height="560" fill="#0b1f3a"/>
<rect x="24" y="24" width="752" height="512" fill="none" stroke="#255694" stroke-width="3" stroke-dasharray="14 10" rx="20"/>
<circle cx="400" cy="238" r="66" fill="none" stroke="#f5bd4a" stroke-width="4"/>
<path d="M368 238h64M400 206v64" stroke="#f5bd4a" stroke-width="4" stroke-linecap="round"/>
<text x="400" y="358" font-family="Segoe UI,Arial,sans-serif" font-size="30" font-weight="700" fill="#ffffff" text-anchor="middle">${text.replace(/[<>&]/g, "")}</text>
<text x="400" y="396" font-family="Segoe UI,Arial,sans-serif" font-size="19" fill="#93b6e0" text-anchor="middle">PLACEHOLDER IMAGE — replace src in src/lib/images.ts</text>
</svg>`;
  return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
}

export function PhotoImage({
  photo,
  label,
  className = "",
  width = 1200,
  height = 800,
  sizes,
}: {
  photo: PhotoKey;
  label: string;
  className?: string;
  width?: number;
  height?: number;
  sizes?: string;
}) {
  const [failed, setFailed] = useState(false);
  const [loaded, setLoaded] = useState(false);
  const src = failed ? placeholderDataUri(label) : photoSrc(photo, width, height);
  return (
    <span className={`relative block overflow-hidden ${className}`}>
      {!loaded && <span className="skeleton absolute inset-0 block" />}
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img
        src={src}
        alt={failed ? `${label} — placeholder image` : photoCredit(photo).alt}
        loading="lazy"
        onLoad={() => setLoaded(true)}
        onError={() => {
          setFailed(true);
          setLoaded(true);
        }}
        sizes={sizes}
        className={`h-full w-full object-cover transition-opacity duration-500 ${loaded ? "opacity-100" : "opacity-0"}`}
      />
    </span>
  );
}

export function EquipmentCard({ item, compact = false }: { item: Derived; compact?: boolean }) {
  const { toggleFavorite, favorites, toggleCompare, compare } = useLabbook();
  const fav = favorites.includes(item.id);
  const cmp = compare.includes(item.id);
  const detailHref = `/equipment/${encodeURIComponent(item.id)}`;
  return (
    <article className={`${CARD} group flex flex-col overflow-hidden transition-all duration-300 hover:-translate-y-1 hover:shadow-[var(--shadow-lift)]`}>
      {/* clicking the photograph opens the equipment details */}
      <Link href={detailHref} className="relative block aspect-[4/3] overflow-hidden bg-navy-900" title={`Open details for ${item.name}`} aria-label={`View details of ${item.name}`}>
        <PhotoImage photo={item.photo} label={item.name} className="h-full w-full" sizes="(max-width:640px) 100vw, (max-width:1024px) 50vw, 31vw" />
        <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-navy-950/75 via-navy-950/5 to-transparent" />
        <span className="absolute left-3 top-3">
          <StatusBadge status={item.availability} size="sm" />
        </span>
        <span className="absolute bottom-3 left-3 right-3 flex items-end justify-between gap-2">
          <span className="rounded-lg bg-white/92 px-2 py-1 font-mono text-[11px] font-bold tracking-tight text-navy-800 shadow-sm dark:bg-navy-900/90 dark:text-gold-300">{item.id}</span>
          <span className="flex items-center gap-1 rounded-lg bg-navy-950/70 px-2 py-1 text-[11px] font-semibold text-white opacity-0 backdrop-blur transition group-hover:opacity-100">
            <Icon name="eye" className="h-3.5 w-3.5" /> View details
          </span>
        </span>
      </Link>

      <div className="flex flex-1 flex-col p-4">
        <div className="mb-2 flex flex-wrap items-center gap-1.5">
          <Chip className="!bg-transparent !text-navy-700 ring-navy-200 dark:!text-navy-200 dark:ring-navy-600">{item.deptShort}</Chip>
          <Chip>{item.subjectName.replace(" Lab", "")}</Chip>
        </div>
        <h3 className="font-display text-[16.5px] font-bold leading-snug text-navy-900 dark:text-white">
          <Link href={detailHref} className="transition hover:text-navy-600 dark:hover:text-gold-300">{item.name}</Link>
        </h3>
        <p className={`mt-1.5 text-[13px] leading-relaxed text-slate-600 dark:text-slate-400 ${compact ? "line-clamp-2" : "line-clamp-3"}`}>{item.short}</p>

        <dl className="mt-3 grid grid-cols-3 gap-2 rounded-xl bg-slate-50 p-2.5 text-center dark:bg-navy-950/60">
          <div>
            <dt className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Total</dt>
            <dd className="font-display text-base font-extrabold text-navy-900 dark:text-white">{item.total}</dd>
          </div>
          <div className="border-x border-slate-200 dark:border-navy-700">
            <dt className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Free</dt>
            <dd className="font-display text-base font-extrabold text-emerald-600 dark:text-emerald-400">{item.available}</dd>
          </div>
          <div>
            <dt className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Booked</dt>
            <dd className="font-display text-base font-extrabold text-amber-600 dark:text-amber-400">{item.reserved}</dd>
          </div>
        </dl>

        <div className="mt-3.5 flex items-center gap-1.5">
          <LinkButton href={detailHref} variant="outline" size="sm" className="flex-1">
            <Icon name="eye" className="h-3.5 w-3.5" /> View Details
          </LinkButton>
          <LinkButton
            href={`/booking/${encodeURIComponent(item.id)}`}
            variant={item.availability === "maintenance" || item.available === 0 ? "subtle" : "gold"}
            size="sm"
            className="flex-1"
            aria-disabled={item.availability === "maintenance"}
          >
            <Icon name="calendar" className="h-3.5 w-3.5" /> Book
          </LinkButton>
          <button onClick={() => toggleFavorite(item.id)} title={fav ? "Remove from favourites" : "Add to favourites"} aria-label={`Favourite ${item.name}`} className={`grid h-8 w-8 place-items-center rounded-lg border transition ${fav ? "border-rose-300 bg-rose-50 text-rose-600 dark:border-rose-500/40 dark:bg-rose-500/10" : "border-slate-200 text-slate-400 hover:text-rose-500 dark:border-navy-700"}`}>
            <Icon name="heart" className="h-4 w-4" strokeWidth={fav ? 2.4 : 1.8} />
          </button>
          <button onClick={() => toggleCompare(item.id)} title={cmp ? "Remove from comparison" : "Add to comparison"} aria-label={`Compare ${item.name}`} className={`grid h-8 w-8 place-items-center rounded-lg border transition ${cmp ? "border-navy-400 bg-navy-50 text-navy-700 dark:border-navy-500 dark:bg-navy-800 dark:text-white" : "border-slate-200 text-slate-400 hover:text-navy-600 dark:border-navy-700"}`}>
            <Icon name="compare" className="h-4 w-4" />
          </button>
        </div>
      </div>
    </article>
  );
}

export function EquipmentGrid({ items, loading = false, skeletonCount = 6 }: { items: Derived[]; loading?: boolean; skeletonCount?: number }) {
  if (loading) {
    return (
      <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
        {Array.from({ length: skeletonCount }).map((_, i) => (
          <div key={i} className={`${CARD} overflow-hidden p-0`}>
            <Skeleton className="aspect-[4/3] w-full rounded-none" />
            <div className="space-y-2.5 p-4">
              <Skeleton className="h-3 w-24" />
              <Skeleton className="h-4 w-3/4" />
              <Skeleton className="h-3 w-full" />
              <Skeleton className="h-12 w-full" />
              <div className="flex gap-2">
                <Skeleton className="h-8 flex-1" />
                <Skeleton className="h-8 flex-1" />
              </div>
            </div>
          </div>
        ))}
      </div>
    );
  }
  return (
    <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
      {items.map((item, i) => (
        <div key={item.id} className="lb-fade-up" style={{ animationDelay: `${Math.min(i, 8) * 45}ms` }}>
          <EquipmentCard item={item} />
        </div>
      ))}
    </div>
  );
}

/** Recently viewed strip used on the home page and equipment detail page. */
export function RecentlyViewed() {
  const { recent, items } = useLabbook();
  const [show, setShow] = useState(false);
  useEffect(() => setShow(true), []);
  const list = recent.map((id) => items.find((i) => i.id === id)).filter(Boolean).slice(0, 6) as Derived[];
  if (!show || !list.length) return null;
  return (
    <section className={`${CARD} p-5`}>
      <div className="mb-3 flex items-center justify-between">
        <h2 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white">
          <Icon name="clock" className="h-4 w-4 text-navy-500 dark:text-gold-400" /> Recently viewed equipment
        </h2>
        <span className="text-[11px] uppercase tracking-wider text-slate-500 dark:text-slate-400">stored on this device</span>
      </div>
      <div className="lb-scroll-x flex gap-3 overflow-x-auto pb-1">
        {list.map((e) => (
          <Link key={e.id} href={`/equipment/${e.id}`} className="group flex w-[230px] shrink-0 items-center gap-3 rounded-xl border border-slate-200 p-2 transition hover:border-navy-300 hover:bg-slate-50 dark:border-navy-700 dark:hover:bg-navy-800/60">
            <PhotoImage photo={e.photo} label={e.name} className="h-12 w-16 shrink-0 rounded-lg" width={200} height={150} />
            <span className="min-w-0">
              <span className="block truncate text-[13px] font-bold text-navy-900 group-hover:underline dark:text-white">{e.name}</span>
              <span className="block truncate text-[11px] text-slate-500 dark:text-slate-400">{e.id} · {e.subjectName}</span>
            </span>
          </Link>
        ))}
      </div>
    </section>
  );
}

export function MaintenanceNotice({ ids }: { ids: string[] }) {
  const { items } = useLabbook();
  const list = items.filter((i) => ids.includes(i.id) && i.availability === "maintenance");
  if (!list.length) return null;
  return (
    <div className={`${CARD} mb-6 border-amber-300/70 bg-amber-50/80 p-4 dark:border-amber-500/30 dark:bg-amber-500/10`}>
      <div className="flex gap-3">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-amber-500 text-white">
          <Icon name="wrench" className="h-4.5 w-4.5" />
        </span>
        <div>
          <h3 className="text-sm font-bold text-navy-900 dark:text-white">Maintenance notification</h3>
          <p className="mt-1 text-[13px] text-slate-700 dark:text-slate-300">
            {list.map((l) => l.name).join(", ")} {list.length === 1 ? "is" : "are"} currently under maintenance and cannot be booked. Expected restoration is recorded in the admin log — contact the lab attendant for urgent requirements.
          </p>
        </div>
      </div>
    </div>
  );
}
