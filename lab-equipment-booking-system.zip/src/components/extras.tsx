"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { AVAILABILITY_META, formatDate, type Availability, type Booking, type Derived } from "@/lib/data";
import { CARD, Icon, StatusBadge } from "./ui";

/* -------------------------------- legend ---------------------------------- */

export function StatusLegend({ className = "" }: { className?: string }) {
  const order: Availability[] = ["available", "partial", "booked", "maintenance"];
  return (
    <div className={`flex flex-wrap items-center gap-2 ${className}`}>
      {order.map((k) => (
        <span key={k} className="inline-flex items-center gap-1.5 text-[11.5px] font-medium text-slate-500 dark:text-slate-400">
          <span className={`h-2 w-2 rounded-full ${AVAILABILITY_META[k].dot}`} />
          {AVAILABILITY_META[k].label}
        </span>
      ))}
    </div>
  );
}

/* ------------------------------- calendar ---------------------------------- */

const DOW = ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"];

export function BookingCalendar({ bookings, items, onPickDay }: { bookings: Booking[]; items: Derived[]; onPickDay?: (iso: string) => void }) {
  const [cursor, setCursor] = useState(() => {
    const d = new Date();
    return { y: d.getFullYear(), m: d.getMonth() };
  });
  const totalUnits = items.reduce((s, e) => s + e.total, 0);

  const cells = useMemo(() => {
    const first = new Date(cursor.y, cursor.m, 1);
    const days = new Date(cursor.y, cursor.m + 1, 0).getDate();
    const lead = first.getDay();
    const out: ({ iso: string; day: number; bookings: Booking[]; requested: number } | null)[] = [];
    for (let i = 0; i < lead; i++) out.push(null);
    for (let d = 1; d <= days; d++) {
      const iso = `${cursor.y}-${String(cursor.m + 1).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
      const dayBookings = bookings.filter((b) => b.date === iso && b.status !== "Cancelled" && b.status !== "Rejected");
      out.push({ iso, day: d, bookings: dayBookings, requested: dayBookings.reduce((s, b) => s + b.quantity, 0) });
    }
    return out;
  }, [cursor, bookings]);

  const monthLabel = new Date(cursor.y, cursor.m, 1).toLocaleDateString("en-IN", { month: "long", year: "numeric" });
  const today = new Date().toISOString().slice(0, 10);

  return (
    <div className={`${CARD} p-5`}>
      <div className="mb-4 flex items-center justify-between gap-3">
        <div>
          <h3 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white">
            <Icon name="calendar" className="h-4 w-4 text-navy-500 dark:text-gold-400" /> Booking calendar — {monthLabel}
          </h3>
          <p className="mt-1 text-[12px] text-slate-500 dark:text-slate-400">
            {totalUnits} units in the catalogue · busy days are shaded gold
          </p>
        </div>
        <div className="flex items-center gap-1">
          <button onClick={() => setCursor((c) => ({ y: c.m === 0 ? c.y - 1 : c.y, m: c.m === 0 ? 11 : c.m - 1 }))} className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:bg-slate-50 dark:border-navy-700 dark:hover:bg-navy-800" aria-label="Previous month">
            <Icon name="chevronLeft" className="h-4 w-4" />
          </button>
          <button onClick={() => setCursor((c) => ({ y: c.m === 11 ? c.y + 1 : c.y, m: c.m === 11 ? 0 : c.m + 1 }))} className="grid h-8 w-8 place-items-center rounded-lg border border-slate-200 text-slate-500 transition hover:bg-slate-50 dark:border-navy-700 dark:hover:bg-navy-800" aria-label="Next month">
            <Icon name="chevronRight" className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-7 gap-1 text-center text-[11px] font-bold uppercase tracking-wider text-slate-400">
        {DOW.map((d) => (
          <span key={d}>{d}</span>
        ))}
      </div>
      <div className="mt-1 grid grid-cols-7 gap-1">
        {cells.map((c, i) =>
          c === null ? (
            <span key={`e${i}`} />
          ) : (
            <button
              key={c.iso}
              onClick={() => onPickDay?.(c.iso)}
              title={c.bookings.length ? `${c.bookings.length} booking(s) · ${c.requested} unit(s) reserved` : "No bookings"}
              className={`relative aspect-square rounded-lg border text-[12.5px] font-semibold transition hover:-translate-y-0.5 ${
                c.iso === today
                  ? "border-navy-500 bg-navy-50 text-navy-900 dark:border-navy-400 dark:bg-navy-800 dark:text-white"
                  : c.bookings.length
                    ? "border-gold-400/70 bg-gold-400/15 text-navy-800 dark:text-gold-200"
                    : "border-slate-200 bg-white text-slate-600 dark:border-navy-800 dark:bg-navy-900 dark:text-slate-300"
              }`}
            >
              <span className="absolute left-1.5 top-1">{c.day}</span>
              {!!c.bookings.length && (
                <span className="absolute bottom-1.5 left-1/2 flex -translate-x-1/2 gap-0.5">
                  {c.bookings.slice(0, 3).map((b, k) => (
                    <span key={k} className={`h-1.5 w-1.5 rounded-full ${b.status === "Active" ? "bg-emerald-500" : b.status === "Pending" ? "bg-amber-500" : "bg-navy-500"}`} />
                  ))}
                </span>
              )}
            </button>
          ),
        )}
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-3 border-t border-slate-100 pt-3 text-[11.5px] text-slate-500 dark:border-navy-800 dark:text-slate-400">
        <span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-gold-400" /> reserved day</span>
        <span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-emerald-500" /> active</span>
        <span className="inline-flex items-center gap-1.5"><span className="h-2 w-2 rounded-full bg-amber-500" /> pending approval</span>
        {onPickDay && <span className="ml-auto font-medium">Click a date to see its bookings</span>}
      </div>

      <ul className="mt-4 space-y-2">
        {bookings
          .filter((b) => b.date?.startsWith(`${cursor.y}-${String(cursor.m + 1).padStart(2, "0")}`))
          .slice(0, 4)
          .map((b) => (
            <li key={b.bookingId} className="flex items-center gap-2 rounded-xl bg-slate-50 px-3 py-2 text-[12.5px] dark:bg-navy-950/60">
              <span className="font-mono text-[11px] font-bold text-navy-700 dark:text-gold-300">{b.date.slice(8)}</span>
              <span className="min-w-0 flex-1 truncate font-semibold text-navy-900 dark:text-white">{b.equipmentName}</span>
              <span className="hidden text-slate-500 sm:inline dark:text-slate-400">{b.startTime}–{b.endTime}</span>
              <span className={`rounded px-1.5 py-0.5 text-[10.5px] font-bold ${b.status === "Active" ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300" : "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300"}`}>{b.status}</span>
            </li>
          ))}
      </ul>
    </div>
  );
}

/* ---------------------------------- FAQ ----------------------------------- */

export const FAQS: { q: string; a: string; tag: string }[] = [
  { tag: "Booking", q: "How do I book laboratory equipment?", a: "Open your Department, choose the subject laboratory, and click Book Equipment on the required instrument card. Fill the booking form (name, college ID, date, time window, quantity and purpose). Availability is validated for that exact date, so you can only reserve units that are free when you need them." },
  { tag: "Booking", q: "Can I book equipment for a personal project outside lab hours?", a: "Faculty-sponsored project bookings are allowed beyond the scheduled lab hours. Mention the guide's name in the Purpose field; the lab in-charge approves after-hours use and prints a gate pass along with the receipt." },
  { tag: "Availability", q: "What do the availability badges mean?", a: "Available means every unit of the asset is free. Partially Available means some units are already reserved. Fully Booked means zero units are free for the selected date. Under Maintenance means the instrument is with the technical staff and cannot be booked at all." },
  { tag: "Availability", q: "Why does the available count change when I pick a date?", a: "Because reservations are date-wise. A machine free today may be fully committed tomorrow; LABBOOK recomputes available quantity = total quantity − units booked for that date." },
  { tag: "Approval", q: "How long does approval take?", a: "Ordinary teaching-lab instruments are auto-approved by the lab engineer within one working day. High-value items (spectrum analyser, UTM, total station, CNC cell) require the departmental sign-off, typically within two working days." },
  { tag: "Approval", q: "Can I cancel or reschedule a booking?", a: "Yes. Go to My Bookings and use Cancel Booking before the start time. Rescheduling is a cancel + new booking so the availability maths always stays correct. No-shows for two consecutive slots are reported to the HOD." },
  { tag: "Rules", q: "What happens if I return equipment damaged or late?", a: "The lab engineer marks the booking Completed with a remark. Repeat late returns or damage lead to a 7-day booking suspension and an undertaking from the student and the faculty advisor." },
  { tag: "Rules", q: "Do I need PPE or induction before using machines?", a: "Yes for workshop and high-power equipment. Mechanical Workshop, CNC cell, welding bay and machine bays require the safety induction card; the booking is rejected without it, and PPE (safety shoes, goggles) is mandatory at the bench." },
  { tag: "Account", q: "Which ID do I log in with?", a: "Your college ID / roll number (e.g. B22CSE018 for students, FAC-1042 for faculty). In this demonstration build authentication is local to your browser — the login module is structured so a real LDAP/SSO or Firebase Auth provider can be dropped in." },
  { tag: "Account", q: "Is my booking data stored on a server?", a: "The demo stores bookings in your browser's localStorage so they persist after a refresh. The same store also pushes to the REST endpoints (/api/bookings) backed by PostgreSQL through Drizzle ORM, so switching to a server-only mode is a data-source change, not a rewrite." },
];

export function FaqList({ limit, showTags = true }: { limit?: number; showTags?: boolean }) {
  const [open, setOpen] = useState<number | null>(0);
  const list = limit ? FAQS.slice(0, limit) : FAQS;
  return (
    <div className="space-y-2.5">
      {list.map((f, i) => {
        const isOpen = open === i;
        return (
          <div key={f.q} className={`${CARD} overflow-hidden transition-shadow ${isOpen ? "shadow-[var(--shadow-lift)]" : ""}`}>
            <button onClick={() => setOpen(isOpen ? null : i)} aria-expanded={isOpen} className="flex w-full items-center gap-3 px-4 py-3.5 text-left">
              {showTags && <span className="hidden shrink-0 rounded-md bg-navy-50 px-2 py-1 text-[10.5px] font-bold uppercase tracking-wider text-navy-600 sm:inline dark:bg-navy-800 dark:text-navy-200">{f.tag}</span>}
              <span className="flex-1 text-[14.5px] font-bold text-navy-900 dark:text-white">{f.q}</span>
              <Icon name="chevronRight" className={`h-4 w-4 shrink-0 text-slate-400 transition-transform ${isOpen ? "rotate-90" : ""}`} />
            </button>
            {isOpen && (
              <div className="border-t border-slate-100 px-4 py-3.5 text-[13.5px] leading-relaxed text-slate-600 dark:border-navy-800 dark:text-slate-300">
                {f.a}
                {i === 9 && (
                  <Link href="/admin" className="ml-1 font-semibold text-navy-600 underline decoration-gold-400 dark:text-gold-300">
                    open the admin dashboard
                  </Link>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

/* --------------------------- availability mini table -------------------------- */

export function LabAvailabilityRow({ dept, slug, name, code, room, free, total }: { dept: string; slug: string; name: string; code?: string; room?: string; free: number; total: number }) {
  return (
    <div className="flex items-center justify-between gap-4 border-b border-slate-100 py-2.5 last:border-0 dark:border-navy-800">
      <span className="min-w-0">
        <Link href={`/departments/${dept}/${slug}`} className="block truncate text-[14px] font-bold text-navy-900 hover:text-navy-600 dark:text-white dark:hover:text-gold-300">
          {name}
        </Link>
        <span className="text-[11.5px] text-slate-500 dark:text-slate-400">
          {code} {room ? `· ${room}` : ""}
        </span>
      </span>
      <span className="flex shrink-0 items-center gap-2">
        <span className={`text-[12.5px] font-bold ${free === 0 ? "text-rose-600 dark:text-rose-400" : "text-emerald-600 dark:text-emerald-400"}`}>
          {free}/{total} free
        </span>
        <Icon name="chevronRight" className="h-4 w-4 text-slate-400" />
      </span>
    </div>
  );
}

export function AvailabilityPill({ item }: { item: Derived }) {
  return (
    <span className="inline-flex items-center gap-2 rounded-full bg-slate-100 px-2.5 py-1 text-[11.5px] font-semibold text-slate-600 dark:bg-navy-800 dark:text-slate-300">
      <StatusBadge status={item.availability} size="sm" />
      {item.available}/{item.total} units
    </span>
  );
}

export function DaySummary({ bookings, iso }: { bookings: Booking[]; iso: string }) {
  const list = bookings.filter((b) => b.date === iso);
  return (
    <div className="text-[12.5px] text-slate-600 dark:text-slate-400">
      {list.length ? `${list.length} booking(s) on ${formatDate(iso)}` : `No bookings on ${formatDate(iso)}`}
    </div>
  );
}
