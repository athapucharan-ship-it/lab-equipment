"use client";

import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { ReceiptActions, ReceiptSheet } from "./receipt";
import { PhotoImage } from "./equipment";
import { CARD, Field, Icon, INPUT, LABEL, LoadingBlock, Spinner, StatusBadge, btn } from "./ui";
import { DEPARTMENTS, SUBJECTS, formatDate, isHolding, todayISO, type Booking } from "@/lib/data";
import { useLabbook } from "@/lib/store";
import { useToast } from "./ui";

type Mode = "form" | "confirm";

const blank = {
  userName: "",
  uid: "",
  role: "student" as "student" | "faculty",
  dept: "",
  subject: "",
  equipmentId: "",
  quantity: "1",
  date: todayISO(),
  startTime: "09:00",
  endTime: "11:00",
  purpose: "",
  returnDate: todayISO(),
  returnTime: "17:00",
  phone: "",
  email: "",
  notes: "",
};

type Form = typeof blank;

export function BookingForm({ presetEquipmentId, presetDept, presetSubject }: { presetEquipmentId?: string; presetDept?: string; presetSubject?: string }) {
  const { items, ready, book, session, bookings, photoFor } = useLabbook();
  const toast = useToast();
  const router = useRouter();
  const [form, setForm] = useState<Form>(blank);
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [busy, setBusy] = useState(false);
  const [mode, setMode] = useState<Mode>("form");
  const [placed, setPlaced] = useState<Booking | null>(null);
  const submitted = useRef(false);

  const set = (k: keyof Form, v: string) => {
    setForm((f) => ({ ...f, [k]: v }));
    setErrors((e) => ({ ...e, [k]: "" }));
  };

  /* prefill from the route + the signed-in user */
  useEffect(() => {
    if (!ready) return;
    setForm((f) => ({
      ...f,
      dept: presetDept ?? f.dept,
      subject: presetSubject ?? f.subject,
      equipmentId: presetEquipmentId ?? f.equipmentId,
      userName: session?.name ?? f.userName,
      uid: session?.uid ?? f.uid,
      role: session?.role === "faculty" ? "faculty" : session?.role === "student" ? "student" : f.role,
      email: session?.email ?? f.email,
      phone: session?.phone ?? f.phone,
    }));
  }, [ready, presetEquipmentId, presetDept, presetSubject, session]);

  const selected = items.find((e) => e.id === form.equipmentId);
  const labsForDept = useMemo(() => SUBJECTS.filter((s) => !form.dept || s.dept === form.dept), [form.dept]);
  const equipmentForLab = useMemo(
    () => items.filter((e) => (!form.dept || e.dept === form.dept) && (!form.subject || e.subject === form.subject)),
    [items, form.dept, form.subject],
  );

  /* availability for the chosen date */
  const dayBookings = useMemo(
    () => (selected ? bookings.filter((b) => b.equipmentId === selected.id && b.date === form.date && isHolding(b)) : []),
    [bookings, selected, form.date],
  );
  const reserved = dayBookings.reduce((s, b) => s + b.quantity, 0);
  const free = selected ? Math.max(0, selected.total - reserved) : 0;

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (form.userName.trim().length < 3) e.userName = "Enter your full name (min. 3 characters).";
    if (!/^[A-Za-z0-9-]{4,16}$/.test(form.uid.trim())) e.uid = "College ID / roll number is required (4–16 letters, digits or dashes).";
    if (!form.dept) e.dept = "Select the department.";
    if (!form.subject) e.subject = "Select the subject / laboratory.";
    if (!form.equipmentId) e.equipmentId = "Select the equipment to book.";
    const qty = Number(form.quantity);
    if (!Number.isInteger(qty) || qty < 1) e.quantity = "Quantity must be a whole number of 1 or more.";
    if (!form.date) e.date = "Choose a booking date.";
    else if (form.date < todayISO()) e.date = "The booking date cannot be in the past.";
    if (!form.startTime) e.startTime = "Start time is required.";
    if (!form.endTime) e.endTime = "End time is required.";
    if (form.startTime && form.endTime && form.endTime <= form.startTime) e.endTime = "End time must be after the start time.";
    if (form.startTime && (form.startTime < "08:00" || form.startTime > "20:00")) e.startTime = "Lab counter hours are 08:00 – 20:00.";
    if (form.purpose.trim().length < 12) e.purpose = "State the purpose in at least 12 characters (experiment, project or course).";
    if (!form.returnDate) e.returnDate = "Expected return date is required.";
    else if (form.returnDate < form.date) e.returnDate = "Return date cannot be before the booking date.";
    if (form.returnDate === form.date && form.returnTime <= form.endTime) e.returnTime = "Return time must be after the end of use.";
    if (!/^[0-9+\s-]{10,15}$/.test(form.phone.trim())) e.phone = "Enter a reachable contact number.";
    if (!/^[^@\s]+@[^@\s.]+\.[a-z]{2,}$/i.test(form.email.trim())) e.email = "Enter a valid college e-mail address.";
    if (selected?.maintenance) e.equipmentId = "This equipment is under maintenance and cannot be booked.";
    if (selected && qty > free) e.quantity = `Only ${free} of ${selected.total} unit(s) are free on ${formatDate(form.date)}.`;
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const submit = (ev: React.FormEvent) => {
    ev.preventDefault();
    if (!validate()) {
      toast.push({ tone: "error", title: "Please correct the form", body: "Some required fields are missing or invalid." });
      const first = document.querySelector<HTMLElement>("[data-invalid='true']");
      first?.scrollIntoView({ behavior: "smooth", block: "center" });
      return;
    }
    setBusy(true);
    // short delay = visible processing state (stock check + ID generation)
    setTimeout(() => {
      const res = book({
        userName: form.userName.trim(),
        uid: form.uid.trim().toUpperCase(),
        role: form.role,
        dept: form.dept as Booking["dept"],
        subject: form.subject,
        equipmentId: form.equipmentId,
        equipmentName: selected?.name ?? form.equipmentId,
        quantity: Number(form.quantity),
        date: form.date,
        startTime: form.startTime,
        endTime: form.endTime,
        purpose: form.purpose.trim(),
        returnDate: form.returnDate,
        returnTime: form.returnTime,
        phone: form.phone.trim(),
        email: form.email.trim(),
        notes: form.notes.trim() || undefined,
      });
      setBusy(false);
      if (!res.ok || !res.booking) {
        toast.push({ tone: "error", title: "Booking not created", body: res.message });
        return;
      }
      setPlaced(res.booking);
      setMode("confirm");
      submitted.current = true;
      toast.push({ tone: "success", title: `Booking ${res.booking.bookingId} confirmed`, body: "Availability updated — see My Bookings for status." });
      window.scrollTo({ top: 0, behavior: "smooth" });
    }, 620);
  };

  if (!ready) return <LoadingBlock label="Checking live availability…" />;

  if (mode === "confirm" && placed) {
    return (
      <div className="space-y-5">
        <div className={`${CARD} overflow-hidden`}>
          <div className="bg-gradient-to-br from-emerald-600 to-emerald-500 px-6 py-7 text-white">
            <div className="flex flex-wrap items-center gap-4">
              <span className="grid h-12 w-12 place-items-center rounded-2xl bg-white/20 ring-1 ring-white/30">
                <Icon name="check" className="h-7 w-7" strokeWidth={2.6} />
              </span>
              <div className="min-w-0 flex-1">
                <h2 className="font-display text-2xl font-extrabold tracking-tight">Booking confirmed</h2>
                <p className="mt-1 text-[13.5px] text-emerald-50">
                  Booking ID <span className="font-mono font-bold text-white">{placed.bookingId}</span> · status <strong>{placed.status}</strong> · collect from {placed.subject ? SUBJECTS.find((s) => s.slug === placed.subject)?.room : "the lab store"}
                </p>
              </div>
              <div className="no-print flex flex-wrap gap-2">
                <Link href="/my-bookings" className={btn("outline", "sm")}>View My Bookings</Link>
                <button onClick={() => { setMode("form"); setPlaced(null); submitted.current = false; }} className={btn("subtle", "sm")}>
                  <Icon name="plus" className="h-4 w-4" /> Book another
                </button>
              </div>
            </div>
          </div>

          <div className="grid gap-5 p-6 lg:grid-cols-[1.1fr_1fr]">
            <div>
              <h3 className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-500 dark:text-slate-400">What happens next</h3>
              <ol className="mt-3 space-y-2.5 text-[13.5px] text-slate-600 dark:text-slate-300">
                {[
                  "The laboratory in-charge reviews and approves the request (usually within one working day).",
                  "Collect the instrument at the start of your slot — show the QR receipt at the store counter.",
                  "The serial number is checked against the receipt at issue and at return.",
                  "Return on the same bench before the expected return time; the supervisor marks the booking Completed.",
                ].map((t, i) => (
                  <li key={t} className="flex gap-3">
                    <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-navy-800 font-mono text-[11px] font-bold text-white dark:bg-navy-700">{i + 1}</span>
                    {t}
                  </li>
                ))}
              </ol>
              <div className="mt-4 rounded-xl bg-slate-50 p-3.5 text-[12.5px] text-slate-600 dark:bg-navy-950/60 dark:text-slate-300">
                <strong className="font-bold text-navy-900 dark:text-white">Availability updated:</strong> {selected ? `${selected.available} of ${selected.total} unit(s) of ${selected.name} now show as free for ${formatDate(placed.date)}.` : ""}
              </div>
            </div>

            <dl className="grid gap-x-6 gap-y-2 sm:grid-cols-2">
              {([
                ["Equipment", placed.equipmentName],
                ["Equipment ID", placed.equipmentId],
                ["Department", DEPARTMENTS.find((d) => d.key === placed.dept)?.name ?? placed.dept],
                ["Laboratory", SUBJECTS.find((s) => s.slug === placed.subject)?.name ?? placed.subject],
                ["Quantity", `${placed.quantity} unit(s)`],
                ["Date & time", `${formatDate(placed.date)} · ${placed.startTime}–${placed.endTime}`],
                ["Expected return", `${formatDate(placed.returnDate)} · ${placed.returnTime}`],
                ["Booked by", `${placed.userName} (${placed.uid})`],
              ] as [string, string][]).map(([k, v]) => (
                <div key={k} className="border-b border-dashed border-slate-200 pb-1.5 dark:border-navy-700">
                  <dt className="text-[10.5px] font-bold uppercase tracking-[0.12em] text-slate-500 dark:text-slate-400">{k}</dt>
                  <dd className="mt-0.5 text-[13.5px] font-bold text-navy-900 dark:text-white">{v}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>

        <div className="no-print flex flex-wrap items-center justify-between gap-3">
          <ReceiptActions booking={placed} />
          <p className="text-[12px] text-slate-500 dark:text-slate-400">Printed receipt is valid for gate entry and lab store issue.</p>
        </div>
        <ReceiptSheet booking={placed} />
      </div>
    );
  }

  return (
    <form onSubmit={submit} noValidate className="space-y-5">
      {/* step 1 — where */}
      <section className={`${CARD} p-5`}>
        <h2 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white">
          <span className="grid h-6 w-6 place-items-center rounded-lg bg-navy-800 font-mono text-[11px] font-bold text-white">1</span> Department, laboratory &amp; equipment
        </h2>
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          <Field label="Department" error={errors.dept}>
            <select data-invalid={!!errors.dept} value={form.dept} onChange={(e) => { set("dept", e.target.value); set("subject", ""); }} className={INPUT}>
              <option value="">Select department…</option>
              {DEPARTMENTS.map((d) => <option key={d.key} value={d.key}>{d.short} — {d.name}</option>)}
            </select>
          </Field>
          <Field label="Subject / Laboratory" error={errors.subject}>
            <select data-invalid={!!errors.subject} value={form.subject} onChange={(e) => set("subject", e.target.value)} className={INPUT}>
              <option value="">{form.dept ? "All laboratories in this department" : "Select department first…"}</option>
              {labsForDept.map((s) => <option key={s.slug} value={s.slug}>{s.name}</option>)}
            </select>
          </Field>
          <Field label="Equipment" error={errors.equipmentId} hint={form.dept ? `${equipmentForLab.length} instrument(s) available in this selection` : undefined}>
            <select data-invalid={!!errors.equipmentId} value={form.equipmentId} onChange={(e) => {
              set("equipmentId", e.target.value);
              const eq = items.find((i) => i.id === e.target.value);
              if (eq) { setForm((f) => ({ ...f, equipmentId: e.target.value, dept: eq.dept, subject: eq.subject })); setErrors((x) => ({ ...x, dept: "", subject: "" })); }
            }} className={INPUT}>
              <option value="">Select equipment…</option>
              {equipmentForLab.map((e) => (
                <option key={e.id} value={e.id}>
                  {e.name} · {e.id} ({e.total - e.reserved} free)
                </option>
              ))}
            </select>
          </Field>
        </div>

        {selected && (
          <div className="mt-4 flex flex-wrap items-center gap-4 rounded-2xl bg-slate-50 p-3.5 dark:bg-navy-950/60">
            <PhotoImage photo={selected.photo} label={selected.name} className="h-16 w-24 shrink-0 rounded-xl" width={240} height={160} />
            <div className="min-w-[180px] flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <span className="text-[14px] font-bold text-navy-900 dark:text-white">{selected.name}</span>
                <StatusBadge status={selected.availability} size="sm" />
              </div>
              <p className="mt-1 text-[12.5px] text-slate-600 dark:text-slate-400">
                {selected.id} · {photoFor(selected.photo).alt}
              </p>
            </div>
            <div className="flex flex-wrap gap-2 text-center">
              {[["Total", selected.total], ["Booked today", reserved], ["Free for this date", free]].map(([k, v]) => (
                <div key={String(k)} className="min-w-[84px] rounded-xl bg-white px-3 py-2 shadow-sm dark:bg-navy-900">
                  <div className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">{k as string}</div>
                  <div className={`font-display text-lg font-extrabold ${k === "Free for this date" ? (free === 0 ? "text-rose-600 dark:text-rose-400" : "text-emerald-600 dark:text-emerald-400") : "text-navy-900 dark:text-white"}`}>{v as number}</div>
                </div>
              ))}
            </div>
            <Link href={`/equipment/${selected.id}`} className={`${btn("outline", "sm")} ml-auto`}>
              <Icon name="eye" className="h-4 w-4" /> Full details
            </Link>
          </div>
        )}

        {dayBookings.length > 0 && (
          <ul className="mt-3 space-y-1.5">
            {dayBookings.map((b) => (
              <li key={b.bookingId} className="flex flex-wrap items-center gap-2 rounded-xl border border-slate-200 px-3 py-2 text-[12px] dark:border-navy-700">
                <span className="font-mono font-bold text-navy-700 dark:text-gold-300">{b.bookingId}</span>
                <span className="text-slate-500 dark:text-slate-400">{b.startTime}–{b.endTime}</span>
                <span className="font-semibold text-navy-900 dark:text-white">{b.quantity} unit(s)</span>
                <span className="ml-auto text-slate-500 dark:text-slate-400">held by {b.uid}</span>
              </li>
            ))}
          </ul>
        )}
      </section>

      {/* step 2 — who */}
      <section className={`${CARD} p-5`}>
        <h2 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white">
          <span className="grid h-6 w-6 place-items-center rounded-lg bg-navy-800 font-mono text-[11px] font-bold text-white">2</span> Requester details
        </h2>
        {session && (
          <p className="mt-3 flex items-center gap-2 rounded-xl bg-emerald-50 px-3 py-2 text-[12.5px] font-medium text-emerald-800 dark:bg-emerald-500/10 dark:text-emerald-300">
            <Icon name="check" className="h-4 w-4" /> Prefilled from your {session.role} session ({session.uid}). <button type="button" onClick={() => router.push("/login")} className="underline">switch user</button>
          </p>
        )}
        <div className="mt-4 grid gap-4 md:grid-cols-3">
          <Field label="Student / Faculty name" error={errors.userName}>
            <input data-invalid={!!errors.userName} value={form.userName} onChange={(e) => set("userName", e.target.value)} placeholder="e.g. Arjun Prakash" className={INPUT} />
          </Field>
          <Field label="College ID / Roll number" error={errors.uid}>
            <input data-invalid={!!errors.uid} value={form.uid} onChange={(e) => set("uid", e.target.value)} placeholder="e.g. B22CSE018 / FAC-1042" className={INPUT} />
          </Field>
          <Field label="Requester type">
            <div className="flex gap-2">
              {(["student", "faculty"] as const).map((r) => (
                <button type="button" key={r} onClick={() => set("role", r)} className={`${btn(form.role === r ? "primary" : "outline", "sm")} flex-1 capitalize`}>
                  <Icon name="user" className="h-3.5 w-3.5" /> {r}
                </button>
              ))}
            </div>
          </Field>
          <Field label="Contact phone" error={errors.phone}>
            <input data-invalid={!!errors.phone} value={form.phone} onChange={(e) => set("phone", e.target.value)} placeholder="+91 98490 11223" className={INPUT} inputMode="tel" />
          </Field>
          <Field label="College e-mail" error={errors.email}>
            <input data-invalid={!!errors.email} value={form.email} onChange={(e) => set("email", e.target.value)} placeholder="name@labbook.edu.in" className={INPUT} inputMode="email" />
          </Field>
          <Field label="Quantity to book" error={errors.quantity} hint={selected ? `Maximum ${free} unit(s) free on this date` : "Number of identical units"}>
            <div className="flex items-center gap-2">
              <button type="button" onClick={() => set("quantity", String(Math.max(1, Number(form.quantity) - 1)))} className={btn("outline", "sm")} aria-label="Decrease quantity"><Icon name="minus" className="h-4 w-4" /></button>
              <input data-invalid={!!errors.quantity} type="number" min={1} max={selected?.total} value={form.quantity} onChange={(e) => set("quantity", e.target.value)} className={INPUT} />
              <button type="button" onClick={() => set("quantity", String(Math.min(selected?.total ?? 1, Number(form.quantity) + 1)))} className={btn("outline", "sm")} aria-label="Increase quantity"><Icon name="plus" className="h-4 w-4" /></button>
            </div>
          </Field>
        </div>
      </section>

      {/* step 3 — when */}
      <section className={`${CARD} p-5`}>
        <h2 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white">
          <span className="grid h-6 w-6 place-items-center rounded-lg bg-navy-800 font-mono text-[11px] font-bold text-white">3</span> Slot, purpose &amp; return
        </h2>
        <div className="mt-4 grid gap-4 md:grid-cols-4">
          <Field label="Booking date" error={errors.date}>
            <input data-invalid={!!errors.date} type="date" min={todayISO()} value={form.date} onChange={(e) => { set("date", e.target.value); if (e.target.value > form.returnDate) set("returnDate", e.target.value); }} className={INPUT} />
          </Field>
          <Field label="Start time" error={errors.startTime}>
            <input data-invalid={!!errors.startTime} type="time" step={900} value={form.startTime} onChange={(e) => set("startTime", e.target.value)} className={INPUT} />
          </Field>
          <Field label="End time" error={errors.endTime}>
            <input data-invalid={!!errors.endTime} type="time" step={900} value={form.endTime} onChange={(e) => set("endTime", e.target.value)} className={INPUT} />
          </Field>
          <Field label="Duration">
            <div className={`${INPUT} flex items-center justify-between bg-slate-50 font-semibold dark:bg-navy-950/40`}>
              <span>{Math.max(0, Number(form.endTime.slice(0, 2)) * 60 + Number(form.endTime.slice(3)) - Number(form.startTime.slice(0, 2)) * 60 - Number(form.startTime.slice(3)))} min</span>
              <span className="text-[11px] text-slate-400">auto</span>
            </div>
          </Field>
        </div>

        <div className="mt-4 grid gap-4 md:grid-cols-[2fr_1fr_1fr]">
          <Field label="Purpose of booking" error={errors.purpose} hint="Course + experiment / project title. Mention your faculty guide for after-hours use.">
            <textarea data-invalid={!!errors.purpose} value={form.purpose} onChange={(e) => set("purpose", e.target.value)} rows={3} placeholder="e.g. Sem-5 ECE Digital Electronics — full adder propagation delay measurement and waveform capture" className={`${INPUT} resize-y`} />
          </Field>
          <Field label="Expected return date" error={errors.returnDate}>
            <input data-invalid={!!errors.returnDate} type="date" min={form.date} value={form.returnDate} onChange={(e) => set("returnDate", e.target.value)} className={INPUT} />
          </Field>
          <Field label="Expected return time" error={errors.returnTime}>
            <input data-invalid={!!errors.returnTime} type="time" step={900} value={form.returnTime} onChange={(e) => set("returnTime", e.target.value)} className={INPUT} />
          </Field>
        </div>

        <Field label="Additional notes (optional)" hint="Instrument serial preference, PPE card number, group members, or access requirements.">
          <input value={form.notes} onChange={(e) => set("notes", e.target.value)} placeholder="e.g. Group of 3 · safety induction card ME-IND-229 · need the 4-jaw chuck key" className={INPUT} />
        </Field>
      </section>

      <div className={`${CARD} flex flex-wrap items-center gap-4 p-5`}>
        <div className="min-w-[220px] flex-1">
          <h3 className="text-[13.5px] font-bold text-navy-900 dark:text-white">Confirm the request</h3>
          <p className="mt-1 text-[12.5px] text-slate-600 dark:text-slate-400">
            {selected
              ? free === 0
                ? `All ${selected.total} unit(s) of ${selected.name} are committed on ${formatDate(form.date)} — choose another date or time.`
                : `${free} unit(s) of ${selected.name} will be held for ${formatDate(form.date)} ${form.startTime}–${form.endTime}.`
              : "Select a department, laboratory and equipment to continue."}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {busy && <span className="flex items-center gap-2 text-[12.5px] font-semibold text-navy-600 dark:text-navy-200"><Spinner className="h-4 w-4" /> Validating availability…</span>}
          <button type="submit" disabled={busy} className={btn(free === 0 && selected ? "subtle" : "gold", "lg")}>
            {busy ? <Spinner className="h-4 w-4" /> : <Icon name="calendar" className="h-4.5 w-4.5" />} Book Equipment
          </button>
          <Link href="/my-bookings" className={btn("ghost", "sm")}>My bookings</Link>
        </div>
      </div>

      <p className="text-[11.5px] leading-relaxed text-slate-500 dark:text-slate-400">
        By submitting you accept the laboratory rules: return on time, report damage immediately, and no re-lending of college assets. Requests are validated against live availability and duplicate time-window bookings are rejected automatically.
      </p>
    </form>
  );
}
