"use client";

import { useEffect, useState } from "react";
import QRCode from "qrcode";
import { COLLEGE_NAME, deptBy, formatDate, subjectBy, type Booking } from "@/lib/data";
import { BOOKING_STATUS_STYLE, Button, Icon, Spinner } from "./ui";

interface ReceiptProps {
  booking: Booking;
  onDownload?: (name: string, html: string) => void;
}

export function ReceiptSheet({ booking }: ReceiptProps) {
  const [qr, setQr] = useState<string | null>(null);
  const [qrError, setQrError] = useState(false);

  useEffect(() => {
    let alive = true;
    QRCode.toDataURL(
      `LABBOOK|${booking.bookingId}|${booking.equipmentId}|${booking.equipmentName}|${booking.date} ${booking.startTime}-${booking.endTime}|qty:${booking.quantity}|${booking.uid}`,
      { margin: 1, width: 260, color: { dark: "#0b1f3a", light: "#ffffff" } },
    )
      .then((url) => alive && setQr(url))
      .catch(() => setQrError(true));
    return () => {
      alive = false;
    };
  }, [booking.bookingId]);

  const dept = deptBy(booking.dept);
  const subject = subjectBy(booking.dept, booking.subject);

  const rows: [string, string][] = [
    ["Equipment", `${booking.equipmentName}`],
    ["Equipment ID", booking.equipmentId],
    ["Department", dept?.name ?? booking.dept],
    ["Laboratory / Subject", subject?.name ?? booking.subject],
    ["Quantity booked", `${booking.quantity} unit(s)`],
    ["Booking date", formatDate(booking.date)],
    ["Time window", `${booking.startTime} – ${booking.endTime}`],
    ["Expected return", `${formatDate(booking.returnDate)} · ${booking.returnTime}`],
    ["Purpose", booking.purpose],
    ["Contact", `${booking.phone} · ${booking.email}`],
  ];

  return (
    <div id="labbook-receipt" className="print-sheet rounded-2xl border border-slate-200 bg-white p-6 text-navy-900 shadow-[var(--shadow-card)] dark:border-navy-700 dark:bg-navy-900 dark:text-slate-100">
      <div className="flex items-start justify-between gap-4 border-b border-slate-200 pb-4 dark:border-navy-700">
        <div className="flex items-center gap-3">
          <span className="grid h-11 w-11 place-items-center rounded-xl bg-navy-900 text-gold-400">
            <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
              <path d="M9 3h6M10 3v6L5 19a2 2 0 0 0 1.8 3h10.4A2 2 0 0 0 19 19l-5-10V3" />
            </svg>
          </span>
          <div>
            <div className="font-display text-[15px] font-extrabold tracking-tight">LABBOOK · Booking Receipt</div>
            <div className="text-[11.5px] text-slate-500 dark:text-slate-400">{COLLEGE_NAME}</div>
            <div className="text-[11px] text-slate-400">Central Laboratory Store · Ref: {booking.bookingId}</div>
          </div>
        </div>
        <div className="text-right">
          <span className={`inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-[11px] font-bold ring-1 ${BOOKING_STATUS_STYLE[booking.status]}`}>{booking.status}</span>
          <div className="mt-1.5 text-[11px] text-slate-500 dark:text-slate-400">Issued {formatDate(booking.createdAt.slice(0, 10))}</div>
        </div>
      </div>

      <div className="mt-5 grid gap-6 sm:grid-cols-[1fr_auto]">
        <dl className="grid gap-x-6 gap-y-2 sm:grid-cols-2">
          {rows.map(([k, v]) => (
            <div key={k} className="border-b border-dashed border-slate-200 pb-1.5 dark:border-navy-700">
              <dt className="text-[10.5px] font-bold uppercase tracking-[0.12em] text-slate-500 dark:text-slate-400">{k}</dt>
              <dd className="mt-0.5 text-[13.5px] font-semibold leading-snug">{v}</dd>
            </div>
          ))}
        </dl>

        <div className="flex flex-col items-center gap-2 border-t border-slate-200 pt-4 sm:border-l sm:border-t-0 sm:pl-6 sm:pt-0 dark:border-navy-700">
          <div className="text-[10.5px] font-bold uppercase tracking-[0.14em] text-slate-500 dark:text-slate-400">Booking QR</div>
          {qr ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={qr} alt={`QR code containing booking ID ${booking.bookingId}`} className="h-[132px] w-[132px] rounded-xl bg-white p-1 ring-1 ring-slate-200" />
          ) : qrError ? (
            <div className="grid h-[132px] w-[132px] place-items-center rounded-xl bg-slate-50 text-center text-[11px] text-slate-500">QR unavailable</div>
          ) : (
            <div className="grid h-[132px] w-[132px] place-items-center rounded-xl bg-slate-50 dark:bg-navy-950">
              <Spinner />
            </div>
          )}
          <div className="font-mono text-[11px] font-bold tracking-tight text-navy-800 dark:text-gold-300">{booking.bookingId}</div>
          <p className="max-w-[150px] text-center text-[10.5px] leading-snug text-slate-400">Show this QR at the lab store counter for issue &amp; return.</p>
        </div>
      </div>

      <div className="mt-5 rounded-xl bg-slate-50 p-3.5 text-[12px] leading-relaxed text-slate-600 dark:bg-navy-950/60 dark:text-slate-300">
        <strong className="font-bold text-navy-900 dark:text-white">Terms at issue:</strong> collect the instrument within 15 minutes of the start time; check the serial number against this receipt; report any damage before use; switch off and return to the same bench; the supervisor signs the return column. Booking ID must be quoted in all correspondence.
      </div>

      <div className="mt-5 flex flex-wrap items-end justify-between gap-6 border-t border-slate-200 pt-4 text-[11.5px] dark:border-navy-700">
        <div>
          <div className="h-8 w-40 border-b border-slate-300 dark:border-navy-600" />
          <div className="mt-1 text-slate-500 dark:text-slate-400">Student / Faculty signature</div>
        </div>
        <div className="text-right">
          <div className="h-8 w-40 border-b border-slate-300 dark:border-navy-600" />
          <div className="mt-1 text-slate-500 dark:text-slate-400">Laboratory in-charge ({subject?.supervisor?.split(",")[0] ?? "Lab Engineer"})</div>
        </div>
      </div>
    </div>
  );
}

export function ReceiptActions({ booking }: { booking: Booking }) {
  const html = () => `<!doctype html><html><head><meta charset="utf-8"><title>LABBOOK receipt ${booking.bookingId}</title>
<style>body{font-family:Segoe UI,Arial,sans-serif;color:#0b1f3a;padding:28px}h1{font-size:18px;margin:0 0 4px}table{border-collapse:collapse;width:100%;margin-top:14px}td{border-bottom:1px dashed #cbd5e1;padding:7px 4px;font-size:13px;vertical-align:top}td:first-child{width:34%;color:#64748b;font-size:11px;text-transform:uppercase;letter-spacing:.08em;font-weight:700}.tag{display:inline-block;font-size:11px;font-weight:700;border:1px solid #cbd5e1;border-radius:999px;padding:3px 9px}</style>
</head><body><h1>LABBOOK — Booking Receipt</h1><div style="font-size:12px;color:#475569">${COLLEGE_NAME} · Central Laboratory Store</div>
<p style="margin-top:14px"><span class="tag">Booking ID ${booking.bookingId}</span> <span class="tag">Status ${booking.status}</span></p>
<table><tbody>${[
      ["Equipment", booking.equipmentName],
      ["Equipment ID", booking.equipmentId],
      ["Department", deptBy(booking.dept)?.name ?? booking.dept],
      ["Laboratory", subjectBy(booking.dept, booking.subject)?.name ?? booking.subject],
      ["Booked by", `${booking.userName} (${booking.uid}) · ${booking.role}`],
      ["Quantity", `${booking.quantity} unit(s)`],
      ["Date", `${formatDate(booking.date)} · ${booking.startTime}–${booking.endTime}`],
      ["Expected return", `${formatDate(booking.returnDate)} · ${booking.returnTime}`],
      ["Purpose", booking.purpose],
      ["Contact", `${booking.phone} · ${booking.email}`],
    ]
      .map(([k, v]) => `<tr><td>${k}</td><td><strong>${String(v).replace(/</g, "&lt;")}</strong></td></tr>`)
      .join("")}</tbody></table>
<p style="margin-top:20px;font-size:11px;color:#64748b">Generated by LABBOOK on ${new Date().toLocaleString("en-IN")}. Quote the booking ID for any change or damage report.</p>
</body></html>`;

  const download = () => {
    const blob = new Blob([html()], { type: "text/html;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `LABBOOK-receipt-${booking.bookingId}.html`;
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1500);
  };

  return (
    <div className="flex flex-wrap gap-2">
      <Button variant="primary" size="sm" onClick={() => window.print()}>
        <Icon name="print" className="h-4 w-4" /> Print receipt
      </Button>
      <Button variant="outline" size="sm" onClick={download}>
        <Icon name="download" className="h-4 w-4" /> Download receipt
      </Button>
    </div>
  );
}
