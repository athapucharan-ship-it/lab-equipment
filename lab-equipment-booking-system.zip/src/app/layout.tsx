import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { AppShell } from "@/components/chrome";
import { ToastProvider } from "@/components/ui";
import { LabbookProvider } from "@/lib/store";
import { COLLEGE_NAME, LAB_NAME } from "@/lib/data";

export const metadata: Metadata = {
  title: {
    default: `${LAB_NAME} — ${COLLEGE_NAME} Laboratory Equipment Booking System`,
    template: `%s · ${LAB_NAME}`,
  },
  description:
    "LABBOOK lets students and faculty browse laboratory equipment department-wise and subject-wise, check live availability, and book instruments for experiments, projects and academic use.",
  keywords: [
    "LABBOOK",
    "college lab equipment booking",
    "laboratory equipment reservation",
    "CSE ECE EEE ME CE Chemistry Physics lab booking",
  ],
  applicationName: LAB_NAME,
};

export const viewport: Viewport = { themeColor: "#0b1f3a" };

const themeInit = `try{var t=localStorage.getItem('labbook.theme');var d=t?t==='dark':window.matchMedia('(prefers-color-scheme: dark)').matches;document.documentElement.classList.toggle('dark',d);}catch(e){}`;

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link
          href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=Sora:wght@600;700;800&display=swap"
          rel="stylesheet"
        />
        <link
          rel="icon"
          href={`data:image/svg+xml,${encodeURIComponent(
            `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32"><rect width="32" height="32" rx="8" fill="#0b1f3a"/><path d="M12 6h8M13.5 6v7L8.5 24a2 2 0 0 0 1.8 3h11.4a2 2 0 0 0 1.8-3L18.5 13V6" fill="none" stroke="#f5bd4a" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
          )}`}
        />
        <script dangerouslySetInnerHTML={{ __html: themeInit }} />
      </head>
      <body className="font-sans antialiased">
        <LabbookProvider>
          <ToastProvider>
            <AppShell>{children}</AppShell>
          </ToastProvider>
        </LabbookProvider>
      </body>
    </html>
  );
}
