"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { Page } from "@/components/chrome";
import { EquipmentGrid, PhotoImage, RecentlyViewed } from "@/components/equipment";
import { BookingCalendar, FaqList, StatusLegend } from "@/components/extras";
import { CARD, Icon, LinkButton, LoadingBlock, SectionTitle, StatCard, btn } from "@/components/ui";
import { COLLEGE_NAME, DEPARTMENTS, LAB_NAME, SEED_EQUIPMENT, SUBJECTS, equipmentCounts, labStats, statsFor, type Derived } from "@/lib/data";
import { useLabbook } from "@/lib/store";

export default function HomePage() {
  const { items, ready, bookings, session } = useLabbook();
  const router = useRouter();
  const [q, setQ] = useState("");

  const stats = useMemo(() => statsFor(items), [items]);
  const featured: Derived[] = useMemo(
    () => [...items].filter((e) => e.availability === "available").slice(0, 6),
    [items],
  );
  const maintenanceList = useMemo(() => items.filter((e) => e.availability === "maintenance"), [items]);
  const myBookings = useMemo(
    () => (session ? bookings.filter((b) => b.uid === session.uid) : bookings.slice(0, 3)),
    [bookings, session],
  );

  if (!ready) return <Page><LoadingBlock label="Loading LABBOOK dashboard…" /></Page>;

  const submit = () => router.push(q.trim() ? `/equipment?q=${encodeURIComponent(q.trim())}` : "/equipment");

  return (
    <>
      {/* ------------------------------- hero ------------------------------- */}
      <section className="relative overflow-hidden bg-navy-950 text-white">
        <div className="lb-grid-bg absolute inset-0 opacity-60" />
        <div className="absolute -left-24 top-8 h-72 w-72 rounded-full bg-navy-600/35 blur-3xl" />
        <div className="absolute -right-16 bottom-0 h-80 w-80 rounded-full bg-gold-500/20 blur-3xl" />
        <div className="relative mx-auto grid max-w-[1240px] items-center gap-10 px-4 py-14 sm:px-6 lg:grid-cols-[1.15fr_1fr] lg:py-20">
          <div className="lb-fade-up">
            <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-[11.5px] font-bold uppercase tracking-[0.16em] text-gold-200 ring-1 ring-white/15">
              <span className="h-1.5 w-1.5 animate-pulse rounded-full bg-gold-400" /> {LAB_NAME} · {COLLEGE_NAME.split(" ")[1] ?? "College"} Laboratory Store
            </span>
            <h1 className="mt-5 font-display text-[34px] font-extrabold leading-[1.08] tracking-tight sm:text-[46px] lg:text-[54px]">
              College Laboratory <span className="bg-gradient-to-r from-gold-300 to-gold-500 bg-clip-text text-transparent">Equipment Booking</span> System
            </h1>
            <p className="mt-5 max-w-xl text-[15.5px] leading-relaxed text-navy-100">
              Find, check availability, and reserve laboratory equipment with ease — organised department-wise and subject-wise, so every lab in the college is exactly two clicks away.
            </p>

            <div className="mt-7 flex flex-wrap gap-3">
              <Link href="/departments" className={btn("gold", "lg")}>
                <Icon name="layers" className="h-4.5 w-4.5" /> Explore Departments
              </Link>
              <Link href="/equipment" className={`${btn("outline", "lg")} !border-white/25 !bg-white/5 !text-white hover:!bg-white/12`}>
                <Icon name="box" className="h-4.5 w-4.5" /> Browse Equipment
              </Link>
              <Link href="/my-bookings" className={`${btn("ghost", "lg")} !text-navy-100 hover:!bg-white/10`}>
                <Icon name="calendar" className="h-4.5 w-4.5" /> My Bookings
              </Link>
            </div>

            <div className="mt-8 max-w-lg rounded-2xl bg-white/8 p-2 ring-1 ring-white/15 backdrop-blur">
              <div className="flex items-center gap-2">
                <Icon name="search" className="ml-2 h-4.5 w-4.5 shrink-0 text-navy-200" />
                <input
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && submit()}
                  placeholder="Search “oscilloscope”, “total station”, ECE-DE-001, Rigol…"
                  aria-label="Search equipment by name, ID, department, laboratory or manufacturer"
                  className="w-full bg-transparent py-2.5 text-[14px] text-white outline-none placeholder:text-navy-200"
                />
                <button onClick={submit} className={btn("primary", "sm")}>Search</button>
              </div>
              <p className="px-2 pb-1 pt-2 text-[11.5px] text-navy-200">Searches name · ID · department · subject · laboratory · manufacturer</p>
            </div>
          </div>

          <div className="relative lb-fade-up" style={{ animationDelay: "120ms" }}>
            <div className="overflow-hidden rounded-[26px] ring-1 ring-white/20">
              <PhotoImage photo="dso" label="Laboratory instruments on a college bench" className="aspect-[5/4] w-full" />
            </div>
            <div className="absolute -bottom-6 -left-3 w-[248px] rounded-2xl bg-white p-4 text-navy-900 shadow-[var(--shadow-lift)] sm:left-6 dark:bg-navy-900 dark:text-slate-100">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-bold uppercase tracking-widest text-slate-500 dark:text-slate-400">Live availability</span>
                <Icon name="sparkle" className="h-4 w-4 text-gold-500" />
              </div>
              <div className="mt-2 font-display text-3xl font-extrabold leading-none">
                {stats.availableUnits}
                <span className="text-base font-bold text-slate-400"> / {stats.units} units</span>
              </div>
              <div className="mt-3 h-1.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-navy-700">
                <div className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-emerald-400" style={{ width: `${Math.round((stats.availableUnits / Math.max(1, stats.units)) * 100)}%` }} />
              </div>
              <p className="mt-2 text-[11.5px] text-slate-500 dark:text-slate-400">{stats.available} of {stats.equipment} assets fully free right now</p>
            </div>
            <div className="absolute -right-2 top-4 hidden rounded-2xl bg-navy-900/90 p-3 text-white ring-1 ring-white/15 backdrop-blur sm:block">
              <div className="text-[10.5px] uppercase tracking-widest text-navy-200">Departments</div>
              <div className="font-display text-2xl font-extrabold">{DEPARTMENTS.length}</div>
              <div className="mt-1 text-[10.5px] uppercase tracking-widest text-navy-200">Labs</div>
              <div className="font-display text-2xl font-extrabold">{SUBJECTS.length}</div>
            </div>
          </div>
        </div>
        <div className="relative border-t border-white/10 bg-navy-950/60">
          <div className="mx-auto flex max-w-[1240px] flex-wrap items-center justify-between gap-3 px-4 py-3 text-[12px] text-navy-100 sm:px-6">
            <StatusLegend />
            <span className="inline-flex items-center gap-1.5 font-semibold text-gold-300">
              <Icon name="shield" className="h-4 w-4" /> Booking is validated against live availability for your date
            </span>
          </div>
        </div>
      </section>

      {/* ------------------------------ dashboard ----------------------------- */}
      <Page className="!pt-10">
        <SectionTitle
          eyebrow="Dashboard"
          title="College laboratory at a glance"
          sub="Counts are computed live from the equipment catalogue and the bookings currently stored for this browser session."
          right={
            <Link href="/equipment" className={btn("outline", "sm")}>
              Open full catalogue <Icon name="arrowRight" className="h-4 w-4" />
            </Link>
          }
        />
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
          <StatCard label="Total Departments" value={stats.departments} hint="incl. Other Departments & central facilities" icon="layers" tone="navy" />
          <StatCard label="Total Laboratories" value={stats.labs} hint="subject-wise teaching & research labs" icon="building" tone="violet" />
          <StatCard label="Total Equipment" value={stats.equipment} hint={`${stats.units} units of hardware`} icon="box" tone="sky" />
          <StatCard label="Available Equipment" value={stats.available} hint={`${stats.availableUnits} units free right now`} icon="check" tone="emerald" />
          <StatCard label="Active Bookings" value={bookings.filter((b) => b.status === "Active").length} hint={`${bookings.filter((b) => b.status === "Pending").length} pending approval`} icon="calendar" tone="gold" />
        </div>

        <div className="mt-4 grid gap-4 lg:grid-cols-3">
          <div className={`${CARD} p-5 lg:col-span-2`}>
            <div className="flex items-center justify-between gap-3">
              <h3 className="font-display text-base font-bold text-navy-900 dark:text-white">Availability by status</h3>
              <span className="text-[11.5px] text-slate-500 dark:text-slate-400">{stats.equipment} assets · {stats.units} units</span>
            </div>
            <div className="mt-4 space-y-3">
              {[
                { label: "Available", value: stats.available, cls: "bg-emerald-500" },
                { label: "Partially available", value: stats.partial, cls: "bg-amber-500" },
                { label: "Fully booked", value: stats.booked, cls: "bg-rose-500" },
                { label: "Under maintenance", value: stats.maintenance, cls: "bg-sky-500" },
              ].map((row) => (
                <div key={row.label}>
                  <div className="mb-1 flex items-center justify-between text-[12.5px] font-semibold text-slate-600 dark:text-slate-300">
                    <span>{row.label}</span>
                    <span>{row.value} assets</span>
                  </div>
                  <div className="h-2 w-full overflow-hidden rounded-full bg-slate-100 dark:bg-navy-800">
                    <div className={`h-full rounded-full ${row.cls}`} style={{ width: `${Math.max(2, Math.round((row.value / Math.max(1, stats.equipment)) * 100))}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className={`${CARD} p-5`}>
            <h3 className="flex items-center justify-between font-display text-base font-bold text-navy-900 dark:text-white">
              {session ? `Your next bookings` : "Latest activity"}
              <Link href="/my-bookings" className="text-[11.5px] font-semibold text-navy-600 hover:underline dark:text-gold-300">View all</Link>
            </h3>
            <ul className="mt-3 space-y-2.5">
              {myBookings.length === 0 && <li className="rounded-xl bg-slate-50 p-3 text-[13px] text-slate-500 dark:bg-navy-950/60 dark:text-slate-400">No bookings yet — start from a department page.</li>}
              {myBookings.slice(0, 4).map((b) => (
                <li key={b.bookingId} className="rounded-xl border border-slate-200 p-3 dark:border-navy-700">
                  <div className="flex items-center justify-between gap-2">
                    <span className="truncate text-[13.5px] font-bold text-navy-900 dark:text-white">{b.equipmentName}</span>
                    <span className={`rounded-full px-2 py-0.5 text-[10.5px] font-bold ${b.status === "Active" ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300" : "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300"}`}>{b.status}</span>
                  </div>
                  <div className="mt-1 font-mono text-[11px] text-slate-500 dark:text-slate-400">{b.bookingId}</div>
                  <div className="mt-1 text-[11.5px] text-slate-500 dark:text-slate-400">{b.date} · {b.startTime}–{b.endTime} · {b.quantity} unit(s)</div>
                </li>
              ))}
            </ul>
            <Link href="/booking" className={`${btn("subtle", "sm")} mt-3 w-full`}>
              <Icon name="plus" className="h-4 w-4" /> New booking
            </Link>
          </div>
        </div>

        <div className="mt-4">
          <MaintenanceBand ids={maintenanceList.map((m) => m.id)} />
        </div>
      </Page>

      {/* ----------------------------- departments ---------------------------- */}
      <Page>
        <SectionTitle
          eyebrow="Departments"
          title="Start from a department, then pick the subject laboratory"
          sub="LABBOOK never dumps every instrument on one page. Each department owns its laboratories, and each laboratory owns its equipment."
          right={<Link href="/departments" className={btn("outline", "sm")}>All departments <Icon name="arrowRight" className="h-4 w-4" /></Link>}
        />
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {DEPARTMENTS.map((d, i) => {
            const labs = SUBJECTS.filter((s) => s.dept === d.key);
            const scoped = items.filter((e) => e.dept === d.key);
            const free = scoped.filter((e) => e.availability === "available" || e.availability === "partial").length;
            return (
              <Link key={d.key} href={`/departments/${d.key}`} className="lb-fade-up group" style={{ animationDelay: `${i * 40}ms` }}>
                <div className={`${CARD} h-full overflow-hidden transition-all duration-300 group-hover:-translate-y-1 group-hover:shadow-[var(--shadow-lift)]`}>
                  <div className="h-1.5 w-full" style={{ background: `linear-gradient(90deg, hsl(${d.hue} 60% 42%), hsl(${d.hue + 30} 70% 55%))` }} />
                  <div className="p-4">
                    <div className="flex items-start justify-between gap-3">
                      <span className="grid h-10 w-10 place-items-center rounded-xl text-white" style={{ background: `hsl(${d.hue} 55% 36%)` }}>
                        <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round"><path d={d.icon} /></svg>
                      </span>
                      <span className="rounded-lg bg-slate-100 px-2 py-1 text-[10.5px] font-bold uppercase tracking-wider text-slate-600 dark:bg-navy-800 dark:text-slate-300">{d.short}</span>
                    </div>
                    <h3 className="mt-3 font-display text-[15.5px] font-bold leading-snug text-navy-900 group-hover:text-navy-600 dark:text-white dark:group-hover:text-gold-300">{d.name}</h3>
                    <p className="mt-1.5 line-clamp-2 text-[12.5px] text-slate-500 dark:text-slate-400">{d.tagline}</p>
                    <dl className="mt-3.5 grid grid-cols-3 gap-1.5 text-center">
                      <div className="rounded-lg bg-slate-50 py-1.5 dark:bg-navy-950/60">
                        <dt className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Labs</dt>
                        <dd className="font-display text-[15px] font-extrabold text-navy-900 dark:text-white">{labs.length}</dd>
                      </div>
                      <div className="rounded-lg bg-slate-50 py-1.5 dark:bg-navy-950/60">
                        <dt className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Assets</dt>
                        <dd className="font-display text-[15px] font-extrabold text-navy-900 dark:text-white">{equipmentCounts(d.key)}</dd>
                      </div>
                      <div className="rounded-lg bg-emerald-50 py-1.5 dark:bg-emerald-500/10">
                        <dt className="text-[9.5px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-300">Free</dt>
                        <dd className="font-display text-[15px] font-extrabold text-emerald-700 dark:text-emerald-300">{free}</dd>
                      </div>
                    </dl>
                    <span className="mt-3 inline-flex items-center gap-1 text-[12.5px] font-bold text-navy-700 group-hover:underline dark:text-gold-300">
                      View department <Icon name="arrowRight" className="h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                    </span>
                  </div>
                </div>
              </Link>
            );
          })}
        </div>
      </Page>

      {/* ------------------------------ flow strip ----------------------------- */}
      <section className="border-y border-slate-200 bg-white py-10 dark:border-navy-800 dark:bg-navy-900/50">
        <Page className="!py-0">
          <SectionTitle eyebrow="Navigation flow" title="Department → Subject / Lab → Equipment → Details → Booking" />
          <ol className="grid gap-3 md:grid-cols-5">
            {[
              { t: "Pick a department", d: "Eight departments including a shared Other Departments / central facilities band.", i: "layers", href: "/departments" },
              { t: "Open the subject lab", d: "Only that laboratory's instruments are listed — never a giant flat table.", i: "building", href: "/departments/ece/digital-electronics-lab" },
              { t: "Read the details", d: "Click the equipment photograph to open size, quantity, specs, uses and SOP.", i: "eye", href: "/equipment/ECE-DE-001" },
              { t: "Check availability", d: "Free units are computed for your date and time window, not globally.", i: "check", href: "/equipment" },
              { t: "Book & collect", d: "Unique booking ID, QR receipt, status tracking, cancel or print anytime.", i: "calendar", href: "/booking" },
            ].map((s, i) => (
              <li key={s.t}>
                <Link href={s.href} className={`${CARD} group flex h-full flex-col p-4 transition hover:-translate-y-1 hover:shadow-[var(--shadow-lift)]`}>
                  <div className="flex items-center gap-2">
                    <span className="grid h-8 w-8 place-items-center rounded-xl bg-navy-800 text-white dark:bg-navy-700">
                      <Icon name={s.i} className="h-4 w-4" />
                    </span>
                    <span className="font-mono text-[11px] font-bold text-slate-400">STEP {i + 1}</span>
                  </div>
                  <h3 className="mt-3 text-[14.5px] font-bold text-navy-900 group-hover:underline dark:text-white">{s.t}</h3>
                  <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-500 dark:text-slate-400">{s.d}</p>
                </Link>
              </li>
            ))}
          </ol>
        </Page>
      </section>

      {/* ------------------------------- featured ------------------------------ */}
      <Page>
        <SectionTitle
          eyebrow="Equipment"
          title="Instruments you can reserve right now"
          sub="Every card carries the real photograph, equipment ID, department, laboratory, short description, total and available quantity with both actions."
          right={<Link href="/equipment" className={btn("outline", "sm")}>Search &amp; filter all equipment <Icon name="arrowRight" className="h-4 w-4" /></Link>}
        />
        <EquipmentGrid items={featured} />
        <div className="mt-8">
          <RecentlyViewed />
        </div>
      </Page>

      {/* ------------------------- calendar + rules + FAQ ------------------------ */}
      <Page>
        <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
          <BookingCalendar bookings={bookings} items={items} onPickDay={(iso) => router.push(`/equipment?date=${iso}`)} />

          <div className="space-y-6">
            <div className={`${CARD} p-5`}>
              <h3 className="font-display text-base font-bold text-navy-900 dark:text-white">Laboratory rules that bookings enforce</h3>
              <ul className="mt-3 grid gap-2.5 sm:grid-cols-2">
                {[
                  ["Return within the booked window", "late returns suspend the account"],
                  ["PPE in workshop & machine bays", "enforced by the induction card"],
                  ["One booking = one lab slot", "no double-booking of the same unit"],
                  ["Faculty sign-off for high-value kit", "spectrum analyser, UTM, total station"],
                ].map(([t, d]) => (
                  <li key={t} className="flex gap-2.5 rounded-xl bg-slate-50 p-3 dark:bg-navy-950/60">
                    <Icon name="shield" className="mt-0.5 h-4 w-4 shrink-0 text-navy-500 dark:text-gold-400" />
                    <span>
                      <span className="block text-[13px] font-bold text-navy-900 dark:text-white">{t}</span>
                      <span className="block text-[11.5px] text-slate-500 dark:text-slate-400">{d}</span>
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            <div>
              <SectionTitle eyebrow="Help" title="Frequently asked questions" />
              <FaqList limit={4} />
              <Link href="/faq" className={`${btn("outline", "sm")} mt-3`}>
                Read all FAQs <Icon name="arrowRight" className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </div>
      </Page>

      {/* ---------------------------------- CTA --------------------------------- */}
      <section className="relative overflow-hidden bg-gradient-to-br from-navy-900 via-navy-800 to-navy-950 py-14 text-white">
        <div className="lb-grid-bg absolute inset-0 opacity-40" />
        <Page className="relative !py-0">
          <div className="flex flex-wrap items-center justify-between gap-6">
            <div>
              <h2 className="font-display text-2xl font-extrabold tracking-tight sm:text-3xl">Need an instrument for tomorrow's experiment?</h2>
              <p className="mt-2 max-w-xl text-[14.5px] text-navy-100">Check the lab, reserve the exact unit, and print the QR receipt for the store counter.</p>
            </div>
            <div className="flex flex-wrap gap-3">
              <LinkButton href="/departments" variant="gold" size="lg"><Icon name="layers" className="h-4.5 w-4.5" /> Explore Departments</LinkButton>
              <LinkButton href="/equipment" size="lg" className="!border-white/25 !bg-white/10 !text-white hover:!bg-white/20"><Icon name="box" className="h-4.5 w-4.5" /> Browse Equipment</LinkButton>
            </div>
          </div>
        </Page>
      </section>
    </>
  );
}

function MaintenanceBand({ ids }: { ids: string[] }) {
  if (!ids.length) return null;
  return (
    <div className={`${CARD} border-amber-300/70 bg-amber-50/70 p-4 dark:border-amber-500/30 dark:bg-amber-500/10`}>
      <div className="flex flex-wrap items-center gap-3">
        <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-amber-500 text-white"><Icon name="wrench" className="h-4.5 w-4.5" /></span>
        <p className="flex-1 text-[13px] text-slate-700 dark:text-slate-200">
          <strong className="font-bold">Maintenance notice:</strong> {ids.length} asset(s) are marked under maintenance and are hidden from booking — {ids.slice(0, 4).join(", ")}{ids.length > 4 ? ` +${ids.length - 4} more` : ""}.
        </p>
        <Link href="/equipment?availability=maintenance" className={btn("outline", "sm")}>View affected labs</Link>
      </div>
    </div>
  );
}
