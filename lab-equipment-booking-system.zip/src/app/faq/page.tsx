"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { Page } from "@/components/chrome";
import { FaqList, FAQS } from "@/components/extras";
import { CARD, Icon, LinkButton, SectionTitle, btn } from "@/components/ui";

export default function FaqPage() {
  const tags = useMemo(() => ["All", ...Array.from(new Set(FAQS.map((f) => f.tag)))], []);
  const [tag, setTag] = useState("All");
  const filtered = tag === "All" ? FAQS : FAQS.filter((f) => f.tag === tag);

  return (
    <Page>
      <nav aria-label="Breadcrumb" className="mb-4 flex flex-wrap items-center gap-1.5 text-[13px]">
        <Link href="/" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Home</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <span className="font-semibold text-slate-500 dark:text-slate-400">FAQ &amp; policies</span>
      </nav>

      <header className="mb-8 flex flex-wrap items-end justify-between gap-4">
        <div className="max-w-2xl">
          <div className="mb-1.5 text-[11px] font-bold uppercase tracking-[0.2em] text-navy-500 dark:text-gold-400">Help centre</div>
          <h1 className="font-display text-[30px] font-extrabold leading-tight tracking-tight text-navy-900 sm:text-[38px] dark:text-white">Frequently asked questions</h1>
          <p className="mt-3 text-[14px] leading-relaxed text-slate-600 dark:text-slate-400">
            How booking, availability, approvals, maintenance and lab rules work on LABBOOK — written the way the laboratory store explains them at the counter.
          </p>
        </div>
        <LinkButton href="/contact" variant="primary" size="sm"><Icon name="mail" className="h-4 w-4" /> Still stuck? Contact the store</LinkButton>
      </header>

      <div className="mb-5 flex flex-wrap gap-1.5">
        {tags.map((t) => (
          <button key={t} onClick={() => setTag(t)} className={`rounded-xl px-3.5 py-2 text-[12.5px] font-bold transition ${tag === t ? "bg-navy-800 text-white dark:bg-navy-600" : "bg-white text-slate-600 ring-1 ring-slate-200 hover:bg-slate-50 dark:bg-navy-900 dark:text-slate-300 dark:ring-navy-700"}`}>
            {t}
            <span className="ml-1.5 opacity-60">{t === "All" ? FAQS.length : FAQS.filter((f) => f.tag === t).length}</span>
          </button>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <div>
          {tag === "All" ? (
            <FaqList />
          ) : (
            <div className="space-y-2.5">
              {filtered.map((f) => (
                <div key={f.q} className={`${CARD} p-5`}>
                  <div className="mb-1.5 inline-flex rounded-md bg-navy-50 px-2 py-0.5 text-[10.5px] font-bold uppercase tracking-wider text-navy-600 dark:bg-navy-800 dark:text-navy-200">{f.tag}</div>
                  <h3 className="font-display text-[15.5px] font-bold text-navy-900 dark:text-white">{f.q}</h3>
                  <p className="mt-2 text-[13.5px] leading-relaxed text-slate-600 dark:text-slate-400">{f.a}</p>
                </div>
              ))}
            </div>
          )}
        </div>

        <aside className="space-y-5">
          <section className={`${CARD} p-5`}>
            <h2 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white"><Icon name="book" className="h-4.5 w-4.5 text-navy-500 dark:text-gold-400" /> Booking policy summary</h2>
            <ul className="mt-3 space-y-2 text-[13px] leading-relaxed text-slate-600 dark:text-slate-400">
              {[
                "One booking holds one or more units of a single asset for one date and time window.",
                "Standard lab slots are 08:00–20:00; the store counter issues at 08:40 and receives until 17:00.",
                "High-value or hazardous equipment requires the supervisor's sign-off before use.",
                "Equipment must be returned to the same bench/kit number it was issued from.",
                "Two consecutive no-shows are reported to the HOD and suspend booking for 7 days.",
                "Damage must be reported at the time of return — the remark travels with the booking ID.",
              ].map((t) => (
                <li key={t} className="flex gap-2"><Icon name="check" className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" /> {t}</li>
              ))}
            </ul>
          </section>

          <section className={`${CARD} p-5`}>
            <h2 className="font-display text-base font-bold text-navy-900 dark:text-white">Where the data lives</h2>
            <p className="mt-2 text-[13px] leading-relaxed text-slate-600 dark:text-slate-400">
              Bookings, favourites, recently viewed equipment and admin edits are written to this browser's <code className="rounded bg-slate-100 px-1 font-mono text-[12px] dark:bg-navy-800">localStorage</code>, so a refresh never loses them. The same records are mirrored to the <code className="rounded bg-slate-100 px-1 font-mono text-[12px] dark:bg-navy-800">/api/bookings</code> and <code className="rounded bg-slate-100 px-1 font-mono text-[12px] dark:bg-navy-800">/api/equipment</code> endpoints (Drizzle + PostgreSQL) — see the admin “Data &amp; sync” tab.
            </p>
            <div className="mt-3 flex flex-wrap gap-2">
              <Link href="/admin" className={btn("outline", "sm")}><Icon name="shield" className="h-4 w-4" /> Admin dashboard</Link>
              <Link href="/my-bookings" className={btn("ghost", "sm")}>My bookings</Link>
            </div>
          </section>

          <section className={`${CARD} border-navy-200 bg-navy-50/70 p-5 dark:border-navy-700 dark:bg-navy-900/60`}>
            <h2 className="font-display text-base font-bold text-navy-900 dark:text-white">New to LABBOOK?</h2>
            <p className="mt-2 text-[13px] text-slate-600 dark:text-slate-400">Follow the navigation flow: department → subject laboratory → equipment card → details → check availability → book.</p>
            <Link href="/departments" className={`${btn("primary", "sm")} mt-3`}>Start with departments <Icon name="arrowRight" className="h-4 w-4" /></Link>
          </section>
        </aside>
      </div>

      <div className="mt-8">
        <SectionTitle title="Quick answers for the counter" sub="Print this and stick it beside the issue desk." />
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {[
            ["ID required", "College ID + booking ID at issue", "user"],
            ["QR scan", "Receipt QR holds the booking ID", "qr"],
            ["Late return", "10-minute grace, then remark", "clock"],
            ["Under maintenance", "Cannot be booked; check the notice", "wrench"],
          ].map(([t, d, i]) => (
            <div key={t} className={`${CARD} flex items-start gap-3 p-4`}>
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-navy-800 text-white dark:bg-navy-700"><Icon name={i} className="h-4.5 w-4.5" /></span>
              <span>
                <span className="block text-[13.5px] font-bold text-navy-900 dark:text-white">{t}</span>
                <span className="mt-0.5 block text-[12.5px] text-slate-600 dark:text-slate-400">{d}</span>
              </span>
            </div>
          ))}
        </div>
      </div>
    </Page>
  );
}
