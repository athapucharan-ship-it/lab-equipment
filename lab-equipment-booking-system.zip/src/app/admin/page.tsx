"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { Page } from "@/components/chrome";
import { PhotoImage } from "@/components/equipment";
import { ReceiptActions, ReceiptSheet } from "@/components/receipt";
import {
  BOOKING_STATUS_STYLE,
  Button,
  CARD,
  Chip,
  EmptyState,
  Field,
  Icon,
  INPUT,
  LinkButton,
  LoadingBlock,
  SectionTitle,
  StatCard,
  StatusBadge,
  btn,
  useToast,
} from "@/components/ui";
import { PhotoKeyList, type PhotoKey } from "@/lib/images";
import { DEPARTMENTS, SEED_EQUIPMENT, SUBJECTS, formatDate, statsFor, type Booking, type BookingStatus, type Category, type DeptKey, type Equipment } from "@/lib/data";
import { CATEGORIES } from "@/lib/data";
import { useLabbook } from "@/lib/store";

const TABS = [
  { key: "overview", label: "Overview", icon: "grid" },
  { key: "bookings", label: "Bookings", icon: "calendar" },
  { key: "equipment", label: "Equipment", icon: "box" },
  { key: "labs", label: "Departments & labs", icon: "building" },
  { key: "data", label: "Data & sync", icon: "download" },
] as const;

type TabKey = (typeof TABS)[number]["key"];

export default function AdminPage() {
  const store = useLabbook();
  const { ready, session, login } = store;

  if (!ready) return <Page><LoadingBlock label="Opening the admin console…" /></Page>;

  if (session?.role !== "admin") {
    return (
      <Page>
        <div className={`${CARD} mx-auto max-w-xl p-8 text-center`}>
          <span className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-navy-900 text-gold-400"><Icon name="shield" className="h-7 w-7" /></span>
          <h1 className="mt-4 font-display text-2xl font-extrabold tracking-tight text-navy-900 dark:text-white">Administrator sign-in required</h1>
          <p className="mt-2 text-[13.5px] leading-relaxed text-slate-600 dark:text-slate-400">
            The equipment, availability and approval controls are restricted to laboratory administrators. This demo authenticates locally in your browser — swap <code className="rounded bg-slate-100 px-1 font-mono text-[12px] dark:bg-navy-800">login()</code> in <code className="rounded bg-slate-100 px-1 font-mono text-[12px] dark:bg-navy-800">src/lib/store.tsx</code> for a real auth provider later.
          </p>
          <div className="mt-5 flex flex-wrap justify-center gap-2">
            <Button
              variant="gold"
              onClick={() => login({ name: "Lab Administrator", uid: "ADM-0001", role: "admin", dept: "all", email: "lab.admin@labbook.edu.in", phone: "+91 40 2300 1234" })}
            >
              <Icon name="login" className="h-4 w-4" /> Continue as demo administrator
            </Button>
            <LinkButton href="/login" variant="outline">Use the login page</LinkButton>
          </div>
        </div>
      </Page>
    );
  }

  return <AdminConsole />;
}

function AdminConsole() {
  const {
    items,
    bookings,
    equipment,
    overrides,
    deleted,
    patchEquipment,
    addEquipment,
    removeEquipment,
    setBookingStatus,
    resetDemo,
    pushToServer,
    pullFromServer,
    dbStatus,
    addLab,
    customLabs,
    session,
    logout,
  } = useLabbook();
  const toast = useToast();
  const [tab, setTab] = useState<TabKey>("overview");
  const [editing, setEditing] = useState<Equipment | null>(null);
  const [creating, setCreating] = useState(false);
  const [filter, setFilter] = useState<{ q: string; dept: string; status: string }>({ q: "", dept: "all", status: "all" });
  const [busy, setBusy] = useState(false);

  const stats = useMemo(() => statsFor(items), [items]);
  const scopedBookings = useMemo(() => {
    let out = [...bookings].sort((a, b) => (b.date + b.startTime).localeCompare(a.date + a.startTime));
    if (filter.dept !== "all") out = out.filter((b) => b.dept === filter.dept);
    if (filter.status !== "all") out = out.filter((b) => b.status === filter.status);
    const q = filter.q.trim().toLowerCase();
    if (q) out = out.filter((b) => [b.bookingId, b.userName, b.uid, b.equipmentName, b.equipmentId].join(" ").toLowerCase().includes(q));
    return out;
  }, [bookings, filter]);

  const activeBooking = useMemo(() => bookings.filter((b) => b.status === "Active").length, [bookings]);
  const pending = useMemo(() => bookings.filter((b) => b.status === "Pending"), [bookings]);

  return (
    <Page>
      <nav aria-label="Breadcrumb" className="mb-4 flex flex-wrap items-center gap-1.5 text-[13px]">
        <Link href="/" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Home</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <span className="font-semibold text-slate-500 dark:text-slate-400">Admin dashboard</span>
      </nav>

      <header className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="mb-1.5 text-[11px] font-bold uppercase tracking-[0.2em] text-navy-500 dark:text-gold-400">Laboratory administration</div>
          <h1 className="font-display text-[28px] font-extrabold leading-tight tracking-tight text-navy-900 sm:text-[34px] dark:text-white">Admin control panel</h1>
          <p className="mt-2 max-w-2xl text-[13.5px] text-slate-600 dark:text-slate-400">
            Signed in as <strong className="font-bold text-navy-900 dark:text-white">{session?.name}</strong> ({session?.uid}). Every change applies instantly to the public catalogue and persists in this browser; use <em>Data &amp; sync</em> to mirror it into PostgreSQL.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <span className={`inline-flex items-center gap-1.5 rounded-full px-3 py-1.5 text-[12px] font-bold ring-1 ${dbStatus === "online" ? "bg-emerald-50 text-emerald-700 ring-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-300" : "bg-slate-100 text-slate-600 ring-slate-200 dark:bg-navy-800 dark:text-slate-300"}`}>
            <span className={`h-2 w-2 rounded-full ${dbStatus === "online" ? "bg-emerald-500" : "bg-slate-400"}`} /> Database {dbStatus === "online" ? "reachable" : "not synced"}
          </span>
          <button onClick={logout} className={btn("outline", "sm")}><Icon name="logout" className="h-4 w-4" /> Sign out</button>
        </div>
      </header>

      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-7">
        <StatCard label="Total Equipment" value={stats.equipment} hint={`${stats.units} units`} icon="box" tone="navy" />
        <StatCard label="Available" value={stats.available} hint={`${stats.availableUnits} units free`} icon="check" tone="emerald" />
        <StatCard label="Reserved" value={stats.booked} hint={`${stats.reserved} unit(s) held`} icon="clock" tone="gold" />
        <StatCard label="Maintenance" value={stats.maintenance} hint="blocked from booking" icon="wrench" tone="sky" />
        <StatCard label="Pending Bookings" value={pending.length} hint="need approval" icon="alert" tone="rose" />
        <StatCard label="Active" value={activeBooking} hint="issued now" icon="calendar" tone="violet" />
        <StatCard label="Completed" value={bookings.filter((b) => b.status === "Completed").length} hint="returned & signed off" icon="book" tone="navy" />
      </div>

      <div className="mb-6 flex flex-wrap gap-1.5 rounded-2xl border border-slate-200 bg-white p-1.5 dark:border-navy-700 dark:bg-navy-900">
        {TABS.map((t) => (
          <button key={t.key} onClick={() => setTab(t.key)} className={`inline-flex flex-1 items-center justify-center gap-2 rounded-xl px-3.5 py-2.5 text-[13px] font-bold transition ${tab === t.key ? "bg-navy-800 text-white shadow-sm dark:bg-navy-600" : "text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-navy-800"}`}>
            <Icon name={t.icon} className="h-4 w-4" /> {t.label}
            {t.key === "bookings" && pending.length > 0 && <span className="rounded-full bg-rose-500 px-1.5 text-[10px] font-black text-white">{pending.length}</span>}
          </button>
        ))}
      </div>

      {/* -------------------------------- OVERVIEW -------------------------------- */}
      {tab === "overview" && (
        <div className="grid gap-6 lg:grid-cols-[1.3fr_1fr]">
          <div className={`${CARD} p-5`}>
            <SectionTitle title="Catalogue health" sub="Assets per department with the units currently committed." />
            <ul className="space-y-2.5">
              {DEPARTMENTS.map((d) => {
                const scoped = items.filter((e) => e.dept === d.key);
                const units = scoped.reduce((s, e) => s + e.total, 0);
                const free = scoped.reduce((s, e) => s + e.available, 0);
                const pct = units ? Math.round((free / units) * 100) : 0;
                return (
                  <li key={d.key}>
                    <div className="flex items-center justify-between gap-3 text-[13px]">
                      <span className="font-bold text-navy-900 dark:text-white">{d.short} · {scoped.length} assets</span>
                      <span className="text-slate-500 dark:text-slate-400">{free}/{units} units free</span>
                    </div>
                    <div className="mt-1 h-2 overflow-hidden rounded-full bg-slate-100 dark:bg-navy-800">
                      <div className={`h-full rounded-full ${pct > 60 ? "bg-emerald-500" : pct > 25 ? "bg-amber-500" : "bg-rose-500"}`} style={{ width: `${Math.max(3, pct)}%` }} />
                    </div>
                  </li>
                );
              })}
            </ul>
          </div>

          <div className="space-y-6">
            <div className={`${CARD} p-5`}>
              <h3 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white"><Icon name="alert" className="h-4.5 w-4.5 text-amber-500" /> Requests waiting for you</h3>
              {pending.length === 0 ? (
                <p className="mt-3 rounded-xl bg-emerald-50 p-3 text-[13px] font-semibold text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300">Queue clear — no pending approvals.</p>
              ) : (
                <ul className="mt-3 space-y-2">
                  {pending.slice(0, 5).map((b) => (
                    <li key={b.bookingId} className="rounded-xl border border-slate-200 p-3 dark:border-navy-700">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className="font-mono text-[11px] font-bold text-navy-700 dark:text-gold-300">{b.bookingId}</span>
                        <span className="text-[13px] font-bold text-navy-900 dark:text-white">{b.equipmentName}</span>
                        <span className="ml-auto text-[11.5px] text-slate-500 dark:text-slate-400">{formatDate(b.date)} · {b.quantity} unit(s)</span>
                      </div>
                      <div className="mt-1.5 text-[12px] text-slate-500 dark:text-slate-400">{b.userName} ({b.uid}) · {b.role}</div>
                      <div className="mt-2.5 flex flex-wrap gap-1.5">
                        <Button size="sm" variant="primary" onClick={() => { setBookingStatus(b.bookingId, "Approved", "Approved by lab administrator"); toast.push({ tone: "success", title: "Booking approved", body: `${b.bookingId} · ${b.equipmentName}` }); }}>Approve</Button>
                        <Button size="sm" variant="outline" onClick={() => { setBookingStatus(b.bookingId, "Rejected", "Declined — slot conflicts with the scheduled class"); toast.push({ tone: "warn", title: "Booking rejected", body: b.bookingId }); }}>Reject</Button>
                        <button onClick={() => setTab("bookings")} className={btn("ghost", "sm")}>All bookings</button>
                      </div>
                    </li>
                  ))}
                </ul>
              )}
            </div>

            <div className={`${CARD} p-5`}>
              <h3 className="font-display text-base font-bold text-navy-900 dark:text-white">Quick actions</h3>
              <div className="mt-3 grid gap-2 sm:grid-cols-2">
                <Button variant="gold" onClick={() => { setCreating(true); setTab("equipment"); }}><Icon name="plus" className="h-4 w-4" /> Add equipment</Button>
                <Button variant="outline" onClick={() => { setTab("labs"); }}><Icon name="building" className="h-4 w-4" /> Add a lab / subject</Button>
                <Button variant="outline" onClick={() => { setTab("data"); setBusy(true); void pushToServer().then((r) => { setBusy(false); toast.push({ tone: r.ok ? "success" : "error", title: r.ok ? "Catalogue pushed to the database" : "Database not reachable", body: r.ok ? `${r.count} equipment rows + bookings written` : r.error }); }); }}>
                  {busy ? <Icon name="clock" className="lb-spin h-4 w-4" /> : <Icon name="download" className="h-4 w-4" />} Push to database
                </Button>
                <Button variant="outline" onClick={() => { resetDemo(); toast.push({ tone: "info", title: "Demo data restored", body: "Seed catalogue, sample bookings and defaults reloaded." }); }}><Icon name="close" className="h-4 w-4" /> Reset demo data</Button>
              </div>
              <p className="mt-3 text-[12px] text-slate-500 dark:text-slate-400">
                Local store: {equipment.length} assets · {Object.keys(overrides).length} edited · {deleted.length} removed
              </p>
            </div>
          </div>
        </div>
      )}

      {/* -------------------------------- BOOKINGS -------------------------------- */}
      {tab === "bookings" && (
        <div className="space-y-4">
          <div className={`${CARD} flex flex-wrap items-center gap-3 p-3.5`}>
            <div className="relative min-w-[220px] flex-1">
              <Icon name="search" className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input value={filter.q} onChange={(e) => setFilter({ ...filter, q: e.target.value })} placeholder="Search booking ID, student, roll number or equipment…" className="w-full rounded-xl border border-slate-200 bg-slate-50/70 py-2.5 pl-9 pr-3 text-[13.5px] outline-none focus:border-navy-400 focus:bg-white dark:border-navy-700 dark:bg-navy-950/60 dark:text-slate-100" />
            </div>
            <select value={filter.dept} onChange={(e) => setFilter({ ...filter, dept: e.target.value })} className={INPUT + " !w-auto"}>
              <option value="all">All departments</option>
              {DEPARTMENTS.map((d) => <option key={d.key} value={d.key}>{d.short}</option>)}
            </select>
            <select value={filter.status} onChange={(e) => setFilter({ ...filter, status: e.target.value })} className={INPUT + " !w-auto"}>
              {["all", "Pending", "Approved", "Active", "Completed", "Cancelled", "Rejected"].map((s) => <option key={s} value={s}>{s === "all" ? "Any status" : s}</option>)}
            </select>
            <Button
              size="sm"
              variant="primary"
              onClick={() => {
                const rows = scopedBookings.filter((b) => b.status === "Pending");
                rows.forEach((b) => setBookingStatus(b.bookingId, "Approved", "Bulk approved by lab administrator"));
                toast.push({ tone: "success", title: `${rows.length} booking(s) approved`, body: rows.length ? "Availability already reflected on the public pages." : "Nothing was pending in this view." });
              }}
            >
              <Icon name="check" className="h-4 w-4" /> Approve shown pending
            </Button>
          </div>

          {scopedBookings.length === 0 ? (
            <EmptyState title="No bookings in this view" body="Adjust the filters, or ask students to submit requests — every booking appears here instantly." />
          ) : (
            <div className={`${CARD} overflow-x-auto`}>
              <table className="w-full min-w-[1000px] text-[13px]">
                <thead>
                  <tr className="border-b border-slate-200 bg-slate-50 text-left dark:border-navy-700 dark:bg-navy-950/60">
                    {["Booking", "Requester", "Equipment", "Dept / Lab", "Slot", "Qty", "Status", "Admin actions"].map((h) => (
                      <th key={h} className="px-3 py-2.5 text-[10.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">{h}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {scopedBookings.map((b) => (
                    <tr key={b.bookingId} className="border-b border-slate-100 align-middle last:border-0 hover:bg-slate-50/60 dark:border-navy-800 dark:hover:bg-navy-950/40">
                      <td className="px-3 py-2.5"><span className="block font-mono text-[11.5px] font-bold text-navy-700 dark:text-gold-300">{b.bookingId}</span><span className="text-[10.5px] text-slate-400">{formatDate(b.createdAt.slice(0, 10))}</span></td>
                      <td className="px-3 py-2.5"><span className="block font-bold text-navy-900 dark:text-white">{b.userName}</span><span className="text-[11px] text-slate-500 dark:text-slate-400">{b.uid} · {b.role}</span></td>
                      <td className="px-3 py-2.5"><Link href={`/equipment/${b.equipmentId}`} className="font-semibold text-navy-800 hover:underline dark:text-slate-200">{b.equipmentName}</Link><span className="block font-mono text-[10.5px] text-slate-400">{b.equipmentId}</span></td>
                      <td className="px-3 py-2.5 text-slate-600 dark:text-slate-300">{DEPARTMENTS.find((d) => d.key === b.dept)?.short}<span className="block text-[11px] text-slate-400">{SUBJECTS.find((s) => s.slug === b.subject)?.name ?? b.subject}</span></td>
                      <td className="px-3 py-2.5 whitespace-nowrap text-slate-600 dark:text-slate-300">{formatDate(b.date)}<span className="block text-[11px] text-slate-400">{b.startTime}–{b.endTime}</span></td>
                      <td className="px-3 py-2.5 text-center font-bold text-navy-900 dark:text-white">{b.quantity}</td>
                      <td className="px-3 py-2.5"><span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10.5px] font-bold ring-1 ${BOOKING_STATUS_STYLE[b.status]}`}>{b.status}</span></td>
                      <td className="px-3 py-2.5">
                        <div className="flex flex-wrap gap-1">
                          {(["Approved", "Active", "Completed", "Rejected", "Cancelled"] as BookingStatus[]).map((s) =>
                            b.status === s ? null : (
                              <button key={s} onClick={() => { setBookingStatus(b.bookingId, s, `Set to ${s} by ${session?.name ?? "admin"}`); toast.push({ tone: s === "Rejected" || s === "Cancelled" ? "warn" : "success", title: `${b.bookingId} → ${s}`, body: b.equipmentName }); }} className="rounded-md bg-slate-100 px-2 py-1 text-[11px] font-bold text-slate-600 transition hover:bg-navy-800 hover:text-white dark:bg-navy-800 dark:text-slate-300 dark:hover:bg-navy-600">
                                {s}
                              </button>
                            ),
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      )}

      {/* ------------------------------- EQUIPMENT -------------------------------- */}
      {tab === "equipment" && (
        <div className="space-y-4">
          <div className={`${CARD} flex flex-wrap items-center gap-3 p-3.5`}>
            <div className="relative min-w-[220px] flex-1">
              <Icon name="search" className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input value={filter.q} onChange={(e) => setFilter({ ...filter, q: e.target.value })} placeholder="Filter by name, ID, manufacturer or lab…" className="w-full rounded-xl border border-slate-200 bg-slate-50/70 py-2.5 pl-9 pr-3 text-[13.5px] outline-none focus:border-navy-400 focus:bg-white dark:border-navy-700 dark:bg-navy-950/60 dark:text-slate-100" />
            </div>
            <select value={filter.dept} onChange={(e) => setFilter({ ...filter, dept: e.target.value })} className={INPUT + " !w-auto"}>
              <option value="all">All departments</option>
              {DEPARTMENTS.map((d) => <option key={d.key} value={d.key}>{d.short}</option>)}
            </select>
            <Button variant="gold" size="sm" onClick={() => setCreating(true)}><Icon name="plus" className="h-4 w-4" /> Add equipment</Button>
          </div>

          <div className={`${CARD} overflow-hidden`}>
            <table className="w-full text-[13px]">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-left dark:border-navy-700 dark:bg-navy-950/60">
                  {["Asset", "Lab", "Manufacturer / Model", "Qty", "Free", "Status", "Controls"].map((h) => (
                    <th key={h} className="px-3 py-2.5 text-[10.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {items
                  .filter((e) => filter.dept === "all" || e.dept === filter.dept)
                  .filter((e) => !filter.q.trim() || [e.name, e.id, e.manufacturer, e.model, e.subjectName].join(" ").toLowerCase().includes(filter.q.trim().toLowerCase()))
                  .slice(0, 60)
                  .map((e) => (
                    <tr key={e.id} className="border-b border-slate-100 align-middle last:border-0 hover:bg-slate-50/60 dark:border-navy-800 dark:hover:bg-navy-950/40">
                      <td className="px-3 py-2.5">
                        <span className="flex items-center gap-2">
                          <PhotoImage photo={e.photo} label={e.name} className="h-10 w-14 shrink-0 rounded-md" width={160} height={120} />
                          <span className="min-w-0">
                            <Link href={`/equipment/${e.id}`} className="block max-w-[240px] truncate font-bold text-navy-900 hover:underline dark:text-white">{e.name}</Link>
                            <span className="font-mono text-[10.5px] text-slate-400">{e.id}</span>
                          </span>
                        </span>
                      </td>
                      <td className="px-3 py-2.5 text-slate-600 dark:text-slate-300">{DEPARTMENTS.find((d) => d.key === e.dept)?.short} · <span className="text-[11.5px]">{e.subjectName}</span></td>
                      <td className="px-3 py-2.5 text-slate-600 dark:text-slate-300">{e.manufacturer}<span className="block font-mono text-[10.5px] text-slate-400">{e.model}</span></td>
                      <td className="px-3 py-2.5">
                        <input type="number" min={0} value={e.total} onChange={(ev) => patchEquipment(e.id, { quantity: Math.max(0, Number(ev.target.value) || 0) })} className="w-16 rounded-lg border border-slate-200 bg-white px-2 py-1 text-center text-[12.5px] font-bold outline-none focus:border-navy-400 dark:border-navy-700 dark:bg-navy-900 dark:text-white" aria-label={`Total quantity for ${e.name}`} />
                      </td>
                      <td className="px-3 py-2.5 text-center font-bold text-emerald-600 dark:text-emerald-400">{e.available}</td>
                      <td className="px-3 py-2.5"><StatusBadge status={e.availability} size="sm" /></td>
                      <td className="px-3 py-2.5">
                        <div className="flex flex-wrap gap-1">
                          <button onClick={() => setEditing(e)} className={btn("outline", "sm")}><Icon name="edit" className="h-3.5 w-3.5" /> Edit</button>
                          <button onClick={() => { patchEquipment(e.id, { maintenance: !e.maintenance }); toast.push({ tone: "info", title: e.maintenance ? "Marked serviceable" : "Marked under maintenance", body: `${e.id} · availability updated for everyone` }); }} className={btn(e.maintenance ? "primary" : "ghost", "sm")}>
                            <Icon name="wrench" className="h-3.5 w-3.5" /> {e.maintenance ? "Restore" : "Maintenance"}
                          </button>
                          <button onClick={() => { removeEquipment(e.id); toast.push({ tone: "warn", title: "Equipment removed", body: `${e.id} hidden from the catalogue (demo data can be restored anytime).` }); }} className={btn("ghost", "sm") + " !text-rose-600"}>
                            <Icon name="trash" className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
              </tbody>
            </table>
            <p className="border-t border-slate-100 px-4 py-2.5 text-[11.5px] text-slate-500 dark:border-navy-800 dark:text-slate-400">
              Showing the first 60 rows. Editing quantity or maintenance updates the public cards, filters and booking validation immediately.
            </p>
          </div>
        </div>
      )}

      {/* ------------------------------ LABS / DEPTS ------------------------------ */}
      {tab === "labs" && (
        <div className="grid gap-6 lg:grid-cols-[1fr_1.1fr]">
          <div className={`${CARD} p-5`}>
            <SectionTitle title="Add a subject laboratory" sub="New labs appear on the department page immediately and can then hold equipment." />
            <LabForm
              onAdd={(lab) => {
                addLab(lab);
                toast.push({ tone: "success", title: "Laboratory added", body: `${lab.name} is now listed under ${DEPARTMENTS.find((d) => d.key === lab.dept)?.short}.` });
              }}
            />
            {customLabs.length > 0 && (
              <div className="mt-4 rounded-xl bg-slate-50 p-3 dark:bg-navy-950/60">
                <h4 className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Added in this session</h4>
                <ul className="mt-2 space-y-1 text-[13px]">
                  {customLabs.map((l) => (
                    <li key={l.slug} className="flex items-center justify-between gap-2">
                      <span className="font-semibold text-navy-900 dark:text-white">{l.name}</span>
                      <Chip>{l.slug}</Chip>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>

          <div className={`${CARD} overflow-hidden`}>
            <div className="border-b border-slate-100 px-5 py-3.5 dark:border-navy-800">
              <h3 className="font-display text-base font-bold text-navy-900 dark:white">Laboratories &amp; equipment count</h3>
              <p className="mt-0.5 text-[12.5px] text-slate-500 dark:text-slate-400">{SUBJECTS.length} built-in labs + {customLabs.length} added · {items.length} assets</p>
            </div>
            <div className="max-h-[560px] overflow-y-auto">
              {DEPARTMENTS.map((d) => (
                <div key={d.key} className="border-b border-slate-100 px-5 py-3 last:border-0 dark:border-navy-800">
                  <h4 className="mb-1.5 flex items-center gap-2 text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    <span className="grid h-4 w-4 place-items-center rounded text-[8px] font-black text-white" style={{ background: `hsl(${d.hue} 55% 38%)` }}>{d.short.slice(0, 2)}</span> {d.name}
                  </h4>
                  <ul className="grid gap-1 sm:grid-cols-2">
                    {SUBJECTS.filter((s) => s.dept === d.key).map((s) => {
                      const count = items.filter((e) => e.dept === d.key && e.subject === s.slug).length;
                      return (
                        <li key={s.slug} className="flex items-center justify-between gap-2 rounded-lg bg-slate-50 px-2.5 py-1.5 text-[12.5px] dark:bg-navy-950/60">
                          <Link href={`/departments/${d.key}/${s.slug}`} className="truncate font-semibold text-navy-800 hover:underline dark:text-slate-200">{s.name}</Link>
                          <span className="shrink-0 font-mono text-[10.5px] text-slate-500 dark:text-slate-400">{count}</span>
                        </li>
                      );
                    })}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* ---------------------------------- DATA ---------------------------------- */}
      {tab === "data" && (
        <div className="grid gap-6 lg:grid-cols-2">
          <div className={`${CARD} p-5`}>
            <SectionTitle title="Persistence model" sub="How the demo stores and mirrors data" />
            <ul className="space-y-2.5 text-[13.5px] text-slate-600 dark:text-slate-300">
              {[
                ["Browser (authoritative demo store)", "localStorage key labbook.store.v1 — bookings, admin edits, favourites, recently viewed and session survive refreshes."],
                ["PostgreSQL via Drizzle ORM", "The same mutations are mirrored to /api/bookings, /api/equipment and /api/seed so the schema is ready for a real deployment."],
                ["Swapping the source of truth", "Point the store hooks at the API instead of localStorage; the components already consume a single provider."],
              ].map(([t, d]) => (
                <li key={t} className="rounded-xl bg-slate-50 p-3 dark:bg-navy-950/60">
                  <div className="font-bold text-navy-900 dark:text-white">{t}</div>
                  <div className="mt-1 text-[12.5px] leading-relaxed text-slate-600 dark:text-slate-400">{d}</div>
                </li>
              ))}
            </ul>
            <div className="mt-4 flex flex-wrap gap-2">
              <Button variant="primary" size="sm" onClick={async () => { const r = await pushToServer(); toast.push({ tone: r.ok ? "success" : "error", title: r.ok ? "Pushed to PostgreSQL" : "Push failed", body: r.ok ? `${r.count} equipment rows written` : r.error }); }}>
                <Icon name="download" className="h-4 w-4" /> Push catalogue + bookings
              </Button>
              <Button variant="outline" size="sm" onClick={async () => { const r = await pullFromServer(); toast.push({ tone: r.ok ? "success" : "error", title: r.ok ? `Pulled ${r.count} booking(s)` : "Pull failed", body: r.error ?? "Merged into the local list by booking ID." }); }}>
                <Icon name="eye" className="h-4 w-4" /> Pull bookings from database
              </Button>
              <Button variant="ghost" size="sm" onClick={() => { resetDemo(); toast.push({ tone: "info", title: "Demo reset", body: "Seed catalogue and sample bookings restored." }); }}>
                <Icon name="close" className="h-4 w-4" /> Reset local store
              </Button>
            </div>
          </div>

          <div className={`${CARD} p-5`}>
            <SectionTitle title="Store snapshot" sub="Counts as currently held in this browser session" />
            <dl className="grid gap-3 sm:grid-cols-2">
              {[
                ["Seed catalogue", SEED_EQUIPMENT.length],
                ["Active catalogue", items.length],
                ["Edited assets", Object.keys(overrides).length],
                ["Removed assets", deleted.length],
                ["Bookings", bookings.length],
                ["Pending", bookings.filter((b) => b.status === "Pending").length],
                ["Departments", DEPARTMENTS.length],
                ["Labs", SUBJECTS.length + customLabs.length],
              ].map(([k, v]) => (
                <div key={String(k)} className="rounded-xl bg-slate-50 p-3 dark:bg-navy-950/60">
                  <dt className="text-[10.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">{k as string}</dt>
                  <dd className="font-display text-xl font-extrabold text-navy-900 dark:text-white">{v as number}</dd>
                </div>
              ))}
            </dl>
            <p className="mt-4 flex gap-2 rounded-xl bg-navy-50 p-3 text-[12.5px] leading-relaxed text-navy-800 dark:bg-navy-950/60 dark:text-slate-300">
              <Icon name="info" className="mt-0.5 h-4 w-4 shrink-0" /> Admin changes are session-scoped by design: they never touch the seed files, so re-deploying the site always returns the published catalogue.
            </p>
          </div>
        </div>
      )}

      {/* --------------------------------- modals --------------------------------- */}
      {(editing || creating) && (
        <EquipmentModal
          equipment={editing}
          onClose={() => { setEditing(null); setCreating(false); }}
          onSave={(eq, mode) => {
            if (mode === "create") {
              addEquipment(eq);
              toast.push({ tone: "success", title: "Equipment added", body: `${eq.id} is live in laboratory “${eq.subject}”.` });
            } else {
              patchEquipment(eq.id, {
                name: eq.name,
                short: eq.short,
                quantity: eq.quantity,
                manufacturer: eq.manufacturer,
                model: eq.model,
                photo: eq.photo,
                maintenance: eq.maintenance,
              });
              toast.push({ tone: "success", title: "Equipment updated", body: `${eq.id} saved and visible immediately.` });
            }
            setEditing(null);
            setCreating(false);
          }}
        />
      )}
    </Page>
  );
}

function LabForm({ onAdd }: { onAdd: (lab: { dept: DeptKey; slug: string; name: string; code?: string }) => void }) {
  const [dept, setDept] = useState<DeptKey>("cse");
  const [name, setName] = useState("");
  const [code, setCode] = useState("");
  const [err, setErr] = useState("");

  return (
    <form
      className="space-y-3"
      onSubmit={(e) => {
        e.preventDefault();
        if (name.trim().length < 4) { setErr("Give the laboratory a name of at least 4 characters."); return; }
        if (SUBJECTS.some((s) => s.name.toLowerCase() === name.trim().toLowerCase())) { setErr("A laboratory with this name already exists."); return; }
        const slug = name.trim().toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") + "-lab";
        onAdd({ dept, slug, name: name.trim(), code: code.trim() || "LAB-NEW" });
        setName(""); setCode(""); setErr("");
      }}
    >
      <Field label="Department" error={err}>
        <select value={dept} onChange={(e) => setDept(e.target.value as DeptKey)} className={INPUT}>
          {DEPARTMENTS.map((d) => <option key={d.key} value={d.key}>{d.short} — {d.name}</option>)}
        </select>
      </Field>
      <Field label="Laboratory name" hint="e.g. Embedded Systems Lab">
        <input value={name} onChange={(e) => setName(e.target.value)} className={INPUT} placeholder="Advanced Embedded Systems Lab" />
      </Field>
      <Field label="Course / lab code">
        <input value={code} onChange={(e) => setCode(e.target.value)} className={INPUT} placeholder="ECE-405" />
      </Field>
      <Button type="submit" variant="primary" size="sm" className="w-full"><Icon name="plus" className="h-4 w-4" /> Add laboratory</Button>
    </form>
  );
}

function EquipmentModal({ equipment, onClose, onSave }: { equipment: Equipment | null; onClose: () => void; onSave: (eq: Equipment, mode: "edit" | "create") => void }) {
  const create = !equipment;
  const [draft, setDraft] = useState<Equipment>(
    equipment ?? {
      id: `${(DEPARTMENTS[0].key as string).toUpperCase()}-NEW-001`,
      name: "",
      dept: "cse",
      subject: SUBJECTS[0].slug,
      category: "Test & Measurement" as Category,
      manufacturer: "",
      model: "",
      photo: "labInstruments" as PhotoKey,
      short: "",
      purpose: "",
      size: { footprint: "Bench top", weight: "—", bench: "Shared bench" },
      quantity: 1,
      specs: [],
      uses: [],
      instructions: [],
      addedOn: new Date().toISOString().slice(0, 10),
    },
  );
  const [err, setErr] = useState("");

  const set = <K extends keyof Equipment>(k: K, v: Equipment[K]) => setDraft((d) => ({ ...d, [k]: v }));

  return (
    <div className="fixed inset-0 z-[65] grid place-items-start justify-center overflow-y-auto bg-navy-950/65 p-4 backdrop-blur-sm" role="dialog" aria-modal="true">
      <div className={`${CARD} my-6 w-full max-w-3xl p-6 lb-fade-up`}>
        <div className="flex items-start justify-between gap-4">
          <div>
            <h3 className="font-display text-xl font-extrabold tracking-tight text-navy-900 dark:text-white">{create ? "Add equipment" : `Edit ${equipment?.id}`}</h3>
            <p className="mt-1 text-[13px] text-slate-600 dark:text-slate-400">{create ? "New assets appear instantly in the department → laboratory → equipment flow." : "Changes apply to the public catalogue, filters and booking validation."}</p>
          </div>
          <button onClick={onClose} className={btn("ghost", "sm")} aria-label="Close dialog"><Icon name="close" className="h-4 w-4" /></button>
        </div>

        <div className="mt-5 grid gap-4 sm:grid-cols-2">
          <Field label="Equipment name" error={err}>
            <input value={draft.name} onChange={(e) => set("name", e.target.value)} className={INPUT} placeholder="Digital Storage Oscilloscope" />
          </Field>
          <Field label="Equipment ID" hint="Used on cards, receipts and search">
            <input value={draft.id} onChange={(e) => set("id", e.target.value.toUpperCase())} className={INPUT + " font-mono"} />
          </Field>
          <Field label="Department">
            <select value={draft.dept} onChange={(e) => set("dept", e.target.value as DeptKey)} className={INPUT}>
              {DEPARTMENTS.map((d) => <option key={d.key} value={d.key}>{d.short} — {d.name}</option>)}
            </select>
          </Field>
          <Field label="Subject / Laboratory">
            <select value={draft.subject} onChange={(e) => set("subject", e.target.value)} className={INPUT}>
              {SUBJECTS.filter((s) => s.dept === draft.dept).map((s) => <option key={s.slug} value={s.slug}>{s.name}</option>)}
            </select>
          </Field>
          <Field label="Manufacturer">
            <input value={draft.manufacturer} onChange={(e) => set("manufacturer", e.target.value)} className={INPUT} placeholder="Rigol Technologies" />
          </Field>
          <Field label="Model number">
            <input value={draft.model} onChange={(e) => set("model", e.target.value)} className={INPUT} placeholder="DS1104Z-E Plus" />
          </Field>
          <Field label="Total quantity">
            <input type="number" min={0} value={draft.quantity} onChange={(e) => set("quantity", Math.max(0, Number(e.target.value) || 0))} className={INPUT} />
          </Field>
          <Field label="Category">
            <select value={draft.category} onChange={(e) => set("category", e.target.value as Category)} className={INPUT}>
              {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </Field>
          <Field label="Short description" hint="Shown on the equipment card">
            <input value={draft.short} onChange={(e) => set("short", e.target.value)} className={INPUT} />
          </Field>
          <Field label="Size / footprint">
            <input value={draft.size.footprint} onChange={(e) => set("size", { ...draft.size, footprint: e.target.value })} className={INPUT} placeholder="294 × 149 × 365 mm" />
          </Field>
          <Field label="Weight">
            <input value={draft.size.weight} onChange={(e) => set("size", { ...draft.size, weight: e.target.value })} className={INPUT} placeholder="4.3 kg" />
          </Field>
          <Field label="Photograph (image bank key)">
            <select value={draft.photo} onChange={(e) => set("photo", e.target.value as PhotoKey)} className={INPUT}>
              {PhotoKeyList.map((k) => <option key={k} value={k}>{k}</option>)}
            </select>
          </Field>
        </div>

        <Field label="Purpose" hint="Long description shown on the details page">
          <textarea rows={3} value={draft.purpose} onChange={(e) => set("purpose", e.target.value)} className={INPUT + " resize-y"} />
        </Field>

        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 pt-4 dark:border-navy-800">
          <label className="flex items-center gap-2 text-[13px] font-semibold text-slate-600 dark:text-slate-300">
            <input type="checkbox" checked={!!draft.maintenance} onChange={(e) => set("maintenance", e.target.checked)} className="h-4 w-4 rounded border-slate-300" /> Mark as under maintenance
          </label>
          <div className="flex gap-2">
            <button onClick={onClose} className={btn("outline", "sm")}>Cancel</button>
            <Button
              variant="gold"
              size="sm"
              onClick={() => {
                if (draft.name.trim().length < 3) { setErr("Equipment name must be at least 3 characters."); return; }
                if (!draft.id.trim()) { setErr("Equipment ID is required."); return; }
                onSave({ ...draft, uses: draft.uses.length ? draft.uses : ["Teaching laboratory practicals"], instructions: draft.instructions.length ? draft.instructions : ["Take the instrument from the store against the booking ID.", "Return it to the same bench before the end time."], specs: draft.specs.length ? draft.specs : [["Status", draft.maintenance ? "Under maintenance" : "Serviceable"]] }, create ? "create" : "edit");
              }}
            >
              <Icon name="check" className="h-4 w-4" /> {create ? "Add to catalogue" : "Save changes"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
