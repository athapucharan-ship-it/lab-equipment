"use client";

import Link from "next/link";
import { useState } from "react";
import { Page } from "@/components/chrome";
import { Button, CARD, Field, Icon, INPUT, SectionTitle, btn } from "@/components/ui";
import { COLLEGE_ADDRESS, COLLEGE_NAME, DEPARTMENTS } from "@/lib/data";
import { useLabbook } from "@/lib/store";
import { useToast } from "@/components/ui";

export default function ContactPage() {
  const { session } = useLabbook();
  const toast = useToast();
  const [form, setForm] = useState({ name: session?.name ?? "", email: session?.email ?? "", dept: session?.dept === "all" ? "cse" : (session?.dept ?? "cse"), topic: "Booking help", message: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const set = (k: keyof typeof form, v: string) => { setForm((f) => ({ ...f, [k]: v })); setErrors((e) => ({ ...e, [k]: "" })); };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const err: Record<string, string> = {};
    if (form.name.trim().length < 3) err.name = "Enter your name.";
    if (!/^[^@\s]+@[^@\s.]+\.[a-z]{2,}$/i.test(form.email.trim())) err.email = "Enter a valid e-mail address.";
    if (form.message.trim().length < 15) err.message = "Tell us a bit more (at least 15 characters).";
    setErrors(err);
    if (Object.keys(err).length) { toast.push({ tone: "error", title: "Message not sent", body: "Please correct the highlighted fields." }); return; }
    try {
      const key = "labbook.messages.v1";
      const prev = JSON.parse(localStorage.getItem(key) ?? "[]") as unknown[];
      localStorage.setItem(key, JSON.stringify([{ ...form, at: new Date().toISOString() }, ...prev].slice(0, 40)));
    } catch { /* ignore */ }
    setForm({ ...form, message: "" });
    toast.push({ tone: "success", title: "Query recorded", body: "The lab store answers within one working day (reference saved on this device)." });
  };

  return (
    <Page>
      <nav aria-label="Breadcrumb" className="mb-4 flex flex-wrap items-center gap-1.5 text-[13px]">
        <Link href="/" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Home</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <span className="font-semibold text-slate-500 dark:text-slate-400">Contact</span>
      </nav>

      <header className="mb-8 max-w-2xl">
        <div className="mb-1.5 text-[11px] font-bold uppercase tracking-[0.2em] text-navy-500 dark:text-gold-400">Contact &amp; support</div>
        <h1 className="font-display text-[30px] font-extrabold leading-tight tracking-tight text-navy-900 sm:text-[38px] dark:text-white">Talk to the central laboratory store</h1>
        <p className="mt-3 text-[14px] leading-relaxed text-slate-600 dark:text-slate-400">
          Damage reports, approval follow-ups, missing accessories and after-hours project requests all land here. For anything urgent during a lab session, walk to the counter — it is staffed through the working day.
        </p>
      </header>

      <div className="grid gap-6 lg:grid-cols-[1.05fr_1fr]">
        <section className={`${CARD} p-6`}>
          <SectionTitle title="Send a query" sub="Messages are stored locally in this demo; wire the handler to your mail or ticket endpoint for production." />
          <form onSubmit={submit} noValidate className="space-y-3.5">
            <div className="grid gap-3.5 sm:grid-cols-2">
              <Field label="Your name" error={errors.name}>
                <input value={form.name} onChange={(e) => set("name", e.target.value)} className={INPUT} placeholder="Full name" />
              </Field>
              <Field label="E-mail" error={errors.email}>
                <input value={form.email} onChange={(e) => set("email", e.target.value)} className={INPUT} placeholder="name@labbook.edu.in" />
              </Field>
            </div>
            <div className="grid gap-3.5 sm:grid-cols-2">
              <Field label="Department">
                <select value={form.dept} onChange={(e) => set("dept", e.target.value)} className={INPUT}>
                  {DEPARTMENTS.map((d) => <option key={d.key} value={d.key}>{d.short} — {d.name}</option>)}
                </select>
              </Field>
              <Field label="Topic">
                <select value={form.topic} onChange={(e) => set("topic", e.target.value)} className={INPUT}>
                  {["Booking help", "Equipment damaged", "Approval follow-up", "Missing accessory", "After-hours project use", "Report a wrong availability count", "Other"].map((t) => <option key={t}>{t}</option>)}
                </select>
              </Field>
            </div>
            <Field label="Message" error={errors.message} hint="Include the booking ID and equipment ID if your query is about an existing reservation.">
              <textarea rows={5} value={form.message} onChange={(e) => set("message", e.target.value)} className={INPUT + " resize-y"} placeholder="e.g. Booking LB-20260212-AB12 — the CRO CH2 probe is intermittent; we stopped the experiment and logged it with the bench number D4." />
            </Field>
            <Button type="submit" variant="gold" size="lg" className="w-full"><Icon name="mail" className="h-4.5 w-4.5" /> Send to the lab store</Button>
          </form>
        </section>

        <div className="space-y-6">
          <section className={`${CARD} p-6`}>
            <h2 className="font-display text-base font-bold text-navy-900 dark:text-white">Direct contacts</h2>
            <ul className="mt-3 space-y-3 text-[13.5px]">
              {[
                ["Central lab store (all departments)", "+91 40 2300 1234", "lab.booking@svcoet.edu.in", "Ext. 110 · 08:40–17:00"],
                ["Maintenance & calibration cell", "+91 40 2300 1298", "lab.maintenance@svcoet.edu.in", "Ext. 118 · 09:00–16:30"],
                ["Workshop & CNC safety officer", "+91 40 2300 1310", "workshop@svcoet.edu.in", "Ext. 402 · Hall A"],
                ["Dean Research & Innovation", "—", "innovation@svcoet.edu.in", "Ext. 700 · Central hub"],
              ].map(([t, phone, mail, extra]) => (
                <li key={t} className="rounded-xl bg-slate-50 p-3 dark:bg-navy-950/60">
                  <div className="font-bold text-navy-900 dark:text-white">{t}</div>
                  <div className="mt-1 flex flex-wrap gap-x-4 gap-y-1 text-[12.5px] text-slate-600 dark:text-slate-400">
                    {phone !== "—" && <span className="inline-flex items-center gap-1.5"><Icon name="phone" className="h-3.5 w-3.5" />{phone}</span>}
                    <a href={`mailto:${mail}`} className="inline-flex items-center gap-1.5 text-navy-700 hover:underline dark:text-gold-300"><Icon name="mail" className="h-3.5 w-3.5" />{mail}</a>
                    <span className="inline-flex items-center gap-1.5"><Icon name="clock" className="h-3.5 w-3.5" />{extra}</span>
                  </div>
                </li>
              ))}
            </ul>
          </section>

          <section className={`${CARD} overflow-hidden`}>
            <div className="border-b border-slate-100 px-5 py-3.5 dark:border-navy-800">
              <h2 className="font-display text-base font-bold text-navy-900 dark:text-white">Department stores</h2>
              <p className="mt-0.5 text-[12.5px] text-slate-500 dark:text-slate-400">Collect and return at the counter listed for your department.</p>
            </div>
            <ul className="divide-y divide-slate-100 dark:divide-navy-800">
              {DEPARTMENTS.map((d) => (
                <li key={d.key} className="flex flex-wrap items-center gap-2 px-5 py-2.5 text-[13px]">
                  <span className="grid h-6 w-6 place-items-center rounded-lg text-[9px] font-black text-white" style={{ background: `hsl(${d.hue} 55% 38%)` }}>{d.short.slice(0, 3)}</span>
                  <span className="min-w-0 flex-1 truncate font-semibold text-navy-900 dark:text-white">{d.name}</span>
                  <span className="shrink-0 text-[12px] text-slate-500 dark:text-slate-400">{d.contact}</span>
                </li>
              ))}
            </ul>
          </section>

          <section className={`${CARD} overflow-hidden`}>
            <div className="relative h-[190px] bg-navy-100 dark:bg-navy-900">
              <svg viewBox="0 0 400 190" className="absolute inset-0 h-full w-full" role="img" aria-label="Schematic campus map showing the laboratory blocks">
                <rect width="400" height="190" fill="none" />
                <g stroke="currentColor" className="text-navy-300 dark:text-navy-700" strokeWidth="1">
                  {Array.from({ length: 12 }).map((_, i) => <line key={`h${i}`} x1="0" y1={i * 16} x2="400" y2={i * 16} />)}
                  {Array.from({ length: 26 }).map((_, i) => <line key={`v${i}`} x1={i * 16} y1="0" x2={i * 16} y2="190" />)}
                </g>
                <path d="M0 120 C 120 96, 260 150, 400 110" fill="none" stroke="currentColor" className="text-gold-400" strokeWidth="6" opacity="0.7" />
                {[
                  { x: 60, y: 60, t: "B2 · CSE" }, { x: 150, y: 40, t: "E1 · ECE" }, { x: 250, y: 66, t: "P3 · EEE" },
                  { x: 320, y: 120, t: "W1 · ME" }, { x: 210, y: 140, t: "C4 · CE" }, { x: 110, y: 132, t: "S1/S2 · Science" },
                  { x: 300, y: 30, t: "I0 · Innovation" },
                ].map((b) => (
                  <g key={b.t}>
                    <rect x={b.x - 4} y={b.y - 4} width="10" height="10" rx="2" className="fill-navy-700 dark:fill-gold-400" />
                    <text x={b.x + 12} y={b.y + 5} className="fill-navy-800 dark:fill-slate-200" fontSize="9" fontWeight="700">{b.t}</text>
                  </g>
                ))}
              </svg>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-3 p-4">
              <div>
                <div className="text-[13.5px] font-bold text-navy-900 dark:text-white">{COLLEGE_NAME}</div>
                <div className="mt-0.5 text-[12.5px] text-slate-500 dark:text-slate-400">{COLLEGE_ADDRESS}</div>
              </div>
              <a href="https://maps.google.com/?q=Tirumalagiri+Hyderabad" target="_blank" rel="noreferrer noopener" className={btn("outline", "sm")}>
                <Icon name="pin" className="h-4 w-4" /> Open in Maps
              </a>
            </div>
          </section>
        </div>
      </div>
    </Page>
  );
}
