"use client";

import Link from "next/link";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Page } from "@/components/chrome";
import { PhotoImage } from "@/components/equipment";
import { Button, CARD, Field, Icon, INPUT, SectionTitle, btn } from "@/components/ui";
import { DEPARTMENTS, type DeptKey, type UserRole } from "@/lib/data";
import { useLabbook } from "@/lib/store";
import { useToast } from "@/components/ui";

const ROLE_TABS: { key: UserRole; label: string; blurb: string; icon: string }[] = [
  { key: "student", label: "Student login", blurb: "Book instruments for your lab slots and project work.", icon: "user" },
  { key: "faculty", label: "Faculty login", blurb: "Sponsor project bookings and approve lab lists.", icon: "book" },
  { key: "admin", label: "Admin login", blurb: "Manage catalogue, quantities, images and approvals.", icon: "shield" },
];

export default function LoginPage() {
  const { login, session, logout, items } = useLabbook();
  const toast = useToast();
  const router = useRouter();
  const [role, setRole] = useState<UserRole>("student");
  const [form, setForm] = useState({ name: "", uid: "", dept: "cse" as DeptKey | "all", email: "", phone: "", password: "" });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const set = (k: keyof typeof form, v: string) => { setForm((f) => ({ ...f, [k]: v })); setErrors((e) => ({ ...e, [k]: "" })); };

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const err: Record<string, string> = {};
    if (form.name.trim().length < 3) err.name = "Enter your full name.";
    if (!/^[A-Za-z0-9-]{4,16}$/.test(form.uid.trim())) err.uid = role === "admin" ? "Admin ID looks like ADM-0001." : "Roll / staff ID (4–16 characters).";
    if (role !== "admin" && !/^[^@\s]+@[^@\s.]+\.[a-z]{2,}$/i.test(form.email.trim())) err.email = "Use your college e-mail address.";
    if (form.password.length < 4) err.password = "Any password of 4+ characters works in this demo.";
    setErrors(err);
    if (Object.keys(err).length) { toast.push({ tone: "error", title: "Check the highlighted fields" }); return; }

    login({
      name: form.name.trim(),
      uid: form.uid.trim().toUpperCase(),
      role,
      dept: role === "admin" ? "all" : form.dept,
      email: form.email.trim() || `${form.uid.trim().toLowerCase()}@labbook.edu.in`,
      phone: form.phone.trim() || "+91 98490 00000",
    });
    toast.push({ tone: "success", title: `Signed in as ${role}`, body: `Welcome, ${form.name.trim().split(" ")[0]}. Your bookings and favourites stay on this device.` });
    router.push(role === "admin" ? "/admin" : "/my-bookings");
  };

  const hero = items.find((i) => i.photo === "computerLab") ?? items[0];

  return (
    <Page>
      <div className="grid items-start gap-8 lg:grid-cols-[1.05fr_1fr]">
        <div>
          <nav aria-label="Breadcrumb" className="mb-4 flex items-center gap-1.5 text-[13px]">
            <Link href="/" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Home</Link>
            <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
            <span className="font-semibold text-slate-500 dark:text-slate-400">Login</span>
          </nav>
          <div className="mb-1.5 text-[11px] font-bold uppercase tracking-[0.2em] text-navy-500 dark:text-gold-400">Accounts</div>
          <h1 className="font-display text-[30px] font-extrabold leading-tight tracking-tight text-navy-900 sm:text-[38px] dark:text-white">Sign in to LABBOOK</h1>
          <p className="mt-3 max-w-xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400">
            Students and faculty can track their own booking history; administrators get the catalogue, quantity, image and approval controls. This demonstration authenticates locally — the <code className="rounded bg-slate-100 px-1 font-mono text-[12px] dark:bg-navy-800">login()</code> call in the store is the single place to wire LDAP, SSO, Firebase Auth or your own JWT endpoint.
          </p>

          <div className={`${CARD} mt-6 overflow-hidden`}>
            {hero && <PhotoImage photo={hero.photo} label="College laboratory" className="aspect-[16/7] w-full" width={1200} height={520} />}
            <div className="grid gap-3 p-5 sm:grid-cols-3">
              {[
                ["My bookings", "history, status, receipts", "/my-bookings"],
                ["Favourites", "instruments you starred", "/favorites"],
                ["Equipment", "search the full catalogue", "/equipment"],
              ].map(([t, d, href]) => (
                <Link key={t} href={href} className="group rounded-xl border border-slate-200 p-3 transition hover:border-navy-400 hover:bg-navy-50/50 dark:border-navy-700 dark:hover:bg-navy-800/60">
                  <div className="flex items-center gap-1.5 text-[13.5px] font-bold text-navy-900 dark:text-white">{t} <Icon name="arrowRight" className="h-3.5 w-3.5 opacity-0 transition group-hover:translate-x-0.5 group-hover:opacity-100" /></div>
                  <div className="mt-1 text-[11.5px] text-slate-500 dark:text-slate-400">{d}</div>
                </Link>
              ))}
            </div>
          </div>
        </div>

        <div className={`${CARD} p-6`}>
          <div className="mb-5 grid gap-1.5 rounded-2xl bg-slate-100 p-1.5 dark:bg-navy-950/60">
            {ROLE_TABS.map((t) => (
              <button key={t.key} onClick={() => setRole(t.key)} className={`flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-left transition ${role === t.key ? "bg-white shadow-sm dark:bg-navy-800" : "hover:bg-white/60 dark:hover:bg-navy-900"}`}>
                <span className={`grid h-8 w-8 shrink-0 place-items-center rounded-lg ${role === t.key ? "bg-navy-800 text-white" : "bg-slate-200 text-slate-500 dark:bg-navy-800 dark:text-slate-400"}`}>
                  <Icon name={t.icon} className="h-4 w-4" />
                </span>
                <span className="min-w-0">
                  <span className="block text-[13.5px] font-bold text-navy-900 dark:text-white">{t.label}</span>
                  <span className="block truncate text-[11.5px] text-slate-500 dark:text-slate-400">{t.blurb}</span>
                </span>
              </button>
            ))}
          </div>

          <form onSubmit={submit} noValidate className="space-y-3.5">
            <Field label="Full name" error={errors.name}>
              <input value={form.name} onChange={(e) => set("name", e.target.value)} className={INPUT} placeholder={role === "admin" ? "Lab Administrator" : "e.g. Arjun Prakash"} />
            </Field>
            <Field label={role === "faculty" ? "Staff ID" : role === "admin" ? "Admin ID" : "Roll number"} error={errors.uid}>
              <input value={form.uid} onChange={(e) => set("uid", e.target.value)} className={INPUT} placeholder={role === "admin" ? "ADM-0001" : role === "faculty" ? "FAC-1042" : "B22CSE018"} />
            </Field>
            <div className="grid gap-3.5 sm:grid-cols-2">
              <Field label="Department">
                <select value={form.dept} onChange={(e) => set("dept", e.target.value)} className={INPUT} disabled={role === "admin"}>
                  {DEPARTMENTS.map((d) => <option key={d.key} value={d.key}>{d.short}</option>)}
                  {role === "admin" && <option value="all">All departments</option>}
                </select>
              </Field>
              <Field label="Password" error={errors.password} hint="demo: any value">
                <input type="password" value={form.password} onChange={(e) => set("password", e.target.value)} className={INPUT} placeholder="••••••" />
              </Field>
            </div>
            <div className="grid gap-3.5 sm:grid-cols-2">
              <Field label="College e-mail" error={errors.email}>
                <input value={form.email} onChange={(e) => set("email", e.target.value)} className={INPUT} placeholder="name@labbook.edu.in" />
              </Field>
              <Field label="Phone">
                <input value={form.phone} onChange={(e) => set("phone", e.target.value)} className={INPUT} placeholder="+91 98490 11223" />
              </Field>
            </div>

            <Button type="submit" variant="gold" size="lg" className="w-full">
              <Icon name="login" className="h-4.5 w-4.5" /> Sign in as {role}
            </Button>
          </form>

          <div className="mt-4 grid gap-2 sm:grid-cols-2">
            <button onClick={() => { login({ name: "Lab Administrator", uid: "ADM-0001", role: "admin", dept: "all", email: "lab.admin@labbook.edu.in", phone: "+91 40 2300 1234" }); toast.push({ tone: "success", title: "Demo administrator signed in" }); router.push("/admin"); }} className={btn("outline", "sm")}>
              <Icon name="shield" className="h-4 w-4" /> Enter as demo admin
            </button>
            <Link href="/departments" className={btn("ghost", "sm")}>Browse without an account <Icon name="arrowRight" className="h-4 w-4" /></Link>
          </div>

          {session && (
            <div className="mt-5 flex flex-wrap items-center justify-between gap-2 rounded-xl bg-navy-50 p-3 text-[13px] dark:bg-navy-950/60">
              <span className="font-semibold text-navy-900 dark:text-white">Currently signed in: {session.name} ({session.role})</span>
              <button onClick={() => { logout(); toast.push({ tone: "info", title: "Signed out" }); }} className={btn("outline", "sm")}>Sign out</button>
            </div>
          )}

          <div className="mt-6">
            <SectionTitle title="What the account unlocks" />
            <ul className="-mt-2 grid gap-2 text-[13px] text-slate-600 dark:text-slate-400">
              {[
                "Booking history scoped to your roll / staff ID",
                "Printable QR receipts for the store counter",
                "Favourites and side-by-side equipment comparison",
                "Admin: approvals, quantities, images, maintenance and the lab list",
              ].map((t) => (
                <li key={t} className="flex gap-2"><Icon name="check" className="mt-0.5 h-4 w-4 shrink-0 text-emerald-500" /> {t}</li>
              ))}
            </ul>
          </div>
        </div>
      </div>
    </Page>
  );
}
