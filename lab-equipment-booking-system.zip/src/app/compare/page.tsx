"use client";

import Link from "next/link";
import { useMemo } from "react";
import { Page } from "@/components/chrome";
import { PhotoImage } from "@/components/equipment";
import { CARD, Icon, LinkButton, LoadingBlock, SectionTitle, StatusBadge, btn } from "@/components/ui";
import { DEPARTMENTS } from "@/lib/data";
import { useLabbook } from "@/lib/store";

export default function ComparePage() {
  const { compare, items, ready, toggleCompare } = useLabbook();
  const list = useMemo(() => compare.map((id) => items.find((e) => e.id === id)).filter(Boolean), [compare, items]) as NonNullable<ReturnType<typeof items.find>>[];

  if (!ready) return <Page><LoadingBlock label="Building the comparison table…" /></Page>;

  const specLabels = Array.from(new Set(list.flatMap((e) => e.specs.map(([k]) => k))));

  const rows: { label: string; render: (e: (typeof list)[number]) => React.ReactNode }[] = [
    { label: "Equipment ID", render: (e) => <span className="font-mono text-[12px] font-bold text-navy-700 dark:text-gold-300">{e.id}</span> },
    { label: "Department", render: (e) => e.deptShort },
    { label: "Laboratory / Subject", render: (e) => <Link href={`/departments/${e.dept}/${e.subject}`} className="text-navy-700 underline decoration-gold-400 hover:underline dark:text-gold-300">{e.subjectName}</Link> },
    { label: "Category", render: (e) => e.category },
    { label: "Manufacturer", render: (e) => e.manufacturer },
    { label: "Model", render: (e) => <span className="font-mono text-[12px]">{e.model}</span> },
    { label: "Availability", render: (e) => <StatusBadge status={e.availability} size="sm" /> },
    { label: "Total quantity", render: (e) => <strong>{e.total}</strong> },
    { label: "Free now", render: (e) => <strong className={e.available ? "text-emerald-600 dark:text-emerald-400" : "text-rose-600 dark:text-rose-400"}>{e.available}</strong> },
    { label: "Size / footprint", render: (e) => e.size.footprint },
    { label: "Weight", render: (e) => e.size.weight },
    { label: "Bench requirement", render: (e) => e.size.bench ?? "—" },
    { label: "Power", render: (e) => e.size.power ?? "—" },
    { label: "Location", render: (e) => e.location ?? "—" },
    { label: "Calibration / service", render: (e) => e.calibrationDue ?? "—" },
    { label: "Purpose", render: (e) => <span className="text-[12.5px] leading-relaxed">{e.purpose}</span> },
    { label: "Main uses", render: (e) => <ul className="space-y-1">{e.uses.map((u) => <li key={u} className="flex gap-1.5 text-[12.5px]"><Icon name="check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" />{u}</li>)}</ul> },
    { label: "Safety", render: (e) => <span className="text-[12.5px]">{e.safety ?? "Standard lab care."}</span> },
  ];

  return (
    <Page>
      <nav aria-label="Breadcrumb" className="mb-4 flex flex-wrap items-center gap-1.5 text-[13px]">
        <Link href="/" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Home</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <Link href="/equipment" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Equipment</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <span className="font-semibold text-slate-500 dark:text-slate-400">Comparison</span>
      </nav>

      <SectionTitle
        eyebrow="Side by side"
        title="Equipment comparison"
        sub="Add up to four instruments from any card or detail page and compare size, quantity, specifications and uses before you book."
        right={list.length > 0 ? <button onClick={() => list.forEach((e) => toggleCompare(e.id))} className={btn("ghost", "sm")}><Icon name="close" className="h-4 w-4" /> Clear comparison</button> : undefined}
      />

      {list.length === 0 ? (
        <div className={`${CARD} flex flex-col items-center gap-3 px-6 py-16 text-center`}>
          <span className="grid h-12 w-12 place-items-center rounded-2xl bg-navy-50 text-navy-500 dark:bg-navy-800 dark:text-navy-200"><Icon name="compare" className="h-6 w-6" /></span>
          <h2 className="font-display text-lg font-bold text-navy-900 dark:text-white">Nothing selected yet</h2>
          <p className="max-w-md text-sm text-slate-600 dark:text-slate-400">Tap the compare icon on an equipment card — for example a digital storage oscilloscope against an analogue CRO — then return here.</p>
          <LinkButton href="/departments/ece/digital-electronics-lab" size="sm" variant="primary">Open Digital Electronics Lab</LinkButton>
        </div>
      ) : (
        <div className={`${CARD} overflow-x-auto`}>
          <table className="w-full min-w-[720px] border-collapse text-left text-[13px]">
            <thead>
              <tr>
                <th className="sticky left-0 z-10 w-[168px] bg-white p-3 text-[10.5px] font-bold uppercase tracking-wider text-slate-500 dark:bg-navy-900 dark:text-slate-400">Attribute</th>
                {list.map((e) => (
                  <th key={e.id} className="min-w-[240px] border-l border-slate-100 bg-slate-50/70 p-3 align-top text-left dark:border-navy-800 dark:bg-navy-950/50">
                    <div className="relative">
                      <PhotoImage photo={e.photo} label={e.name} className="mb-2 aspect-[4/3] w-full rounded-xl" width={520} height={390} />
                      <button onClick={() => toggleCompare(e.id)} className="absolute right-1.5 top-1.5 grid h-7 w-7 place-items-center rounded-lg bg-white/90 text-slate-500 shadow-sm transition hover:text-rose-600 dark:bg-navy-900/90" aria-label={`Remove ${e.name} from comparison`}>
                        <Icon name="close" className="h-4 w-4" />
                      </button>
                      <div className="text-[14px] font-extrabold leading-snug text-navy-900 dark:text-white">{e.name}</div>
                      <div className="mt-1 flex flex-wrap gap-1.5">
                        <Link href={`/equipment/${e.id}`} className={btn("outline", "sm")}><Icon name="eye" className="h-3.5 w-3.5" /> Details</Link>
                        <Link href={`/booking/${e.id}`} className={btn("gold", "sm")}><Icon name="calendar" className="h-3.5 w-3.5" /> Book</Link>
                      </div>
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => (
                <tr key={r.label} className={i % 2 ? "bg-slate-50/60 dark:bg-navy-950/30" : ""}>
                  <th scope="row" className={`sticky left-0 z-10 p-3 text-left align-top text-[11.5px] font-bold uppercase tracking-wide text-slate-500 dark:text-slate-400 ${i % 2 ? "bg-slate-50" : "bg-white"} dark:bg-navy-900`}>{r.label}</th>
                  {list.map((e) => (
                    <td key={e.id} className="border-l border-slate-100 p-3 align-top font-medium text-navy-900 dark:border-navy-800 dark:text-slate-200">{r.render(e)}</td>
                  ))}
                </tr>
              ))}
              {specLabels.map((label) => (
                <tr key={label} className="border-t border-slate-100 dark:border-navy-800">
                  <th scope="row" className="sticky left-0 z-10 bg-white p-3 text-left align-top text-[11.5px] font-bold uppercase tracking-wide text-navy-600 dark:bg-navy-900 dark:text-gold-300">{label}</th>
                  {list.map((e) => (
                    <td key={e.id} className="border-l border-slate-100 p-3 align-top text-[12.5px] text-slate-600 dark:border-navy-800 dark:text-slate-300">
                      {e.specs.find(([k]) => k === label)?.[1] ?? <span className="text-slate-300 dark:text-slate-600">—</span>}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      <p className="mt-4 text-[12px] text-slate-500 dark:text-slate-400">
        Comparison list is stored in your browser alongside favourites and recently viewed equipment. {DEPARTMENTS.length} departments and their laboratories are always reachable from the navigation bar.
      </p>
    </Page>
  );
}
