"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { Page } from "@/components/chrome";
import { PhotoImage } from "@/components/equipment";
import { BookingCalendar } from "@/components/extras";
import { ReceiptActions, ReceiptSheet } from "@/components/receipt";
import { BOOKING_STATUS_STYLE, Button, CARD, EmptyState, Icon, LinkButton, LoadingBlock, SectionTitle, StatCard, btn } from "@/components/ui";
import { DEPARTMENTS, SUBJECTS, formatDate, type Booking } from "@/lib/data";
import { useLabbook } from "@/lib/store";
import { useToast } from "@/components/ui";

const STATUSES = ["All", "Pending", "Approved", "Active", "Completed", "Cancelled"] as const;

export default function MyBookingsPage() {
  const { bookings, items, ready, session, cancelBooking } = useLabbook();
  const toast = useToast();
  const [status, setStatus] = useState<(typeof STATUSES)[number]>("All");
  const [query, setQuery] = useState("");
  const [openId, setOpenId] = useState<string | null>(null);
  const [confirmId, setConfirmId] = useState<string | null>(null);

  const mine = useMemo(() => (session ? bookings.filter((b) => b.uid === session.uid) : bookings), [bookings, session]);

  const list = useMemo(() => {
    let out = [...mine].sort((a, b) => (b.date + b.startTime).localeCompare(a.date + a.startTime));
    if (status !== "All") out = out.filter((b) => b.status === status);
    const q = query.trim().toLowerCase();
    if (q)
      out = out.filter((b) =>
        [b.bookingId, b.equipmentName, b.equipmentId, b.subject, b.status, DEPARTMENTS.find((d) => d.key === b.dept)?.name ?? b.dept, SUBJECTS.find((s) => s.slug === b.subject)?.name ?? ""]
          .join(" ")
          .toLowerCase()
          .includes(q),
      );
    return out;
  }, [mine, status, query]);

  const selected = mine.find((b) => b.bookingId === openId) ?? null;

  if (!ready) return <Page><LoadingBlock label="Loading your bookings…" /></Page>;

  const count = (s: string) => mine.filter((b) => b.status === s).length;
  const canCancel = (b: Booking) => b.status === "Pending" || b.status === "Approved";

  const doCancel = (b: Booking) => {
    cancelBooking(b.bookingId, "Cancelled by requester from My Bookings");
    setConfirmId(null);
    if (openId === b.bookingId) setOpenId(null);
    toast.push({ tone: "warn", title: `Booking ${b.bookingId} cancelled`, body: "The reserved units are back in the available pool." });
  };

  return (
    <Page>
      <nav aria-label="Breadcrumb" className="mb-4 flex flex-wrap items-center gap-1.5 text-[13px]">
        <Link href="/" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Home</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <span className="font-semibold text-slate-500 dark:text-slate-400">My bookings</span>
      </nav>

      <header className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="mb-1.5 text-[11px] font-bold uppercase tracking-[0.2em] text-navy-500 dark:text-gold-400">Booking dashboard</div>
          <h1 className="font-display text-[28px] font-extrabold leading-tight tracking-tight text-navy-900 sm:text-[34px] dark:text-white">
            {session ? `Bookings for ${session.name}` : "All bookings on this device"}
          </h1>
          <p className="mt-2 max-w-2xl text-[13.5px] text-slate-600 dark:text-slate-400">
            {session
              ? "History, status, receipts and cancellation — everything stored locally so it survives a refresh."
              : "This demonstration device is not signed in, so every booking stored in this browser is listed. Sign in to scope the list to one ID."}
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {!session && <LinkButton href="/login" variant="outline" size="sm"><Icon name="login" className="h-4 w-4" /> Sign in</LinkButton>}
          <LinkButton href="/booking" variant="gold" size="sm"><Icon name="plus" className="h-4 w-4" /> New booking</LinkButton>
        </div>
      </header>

      <div className="mb-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-5">
        <StatCard label="Total" value={mine.length} hint="all time on this device" icon="book" tone="navy" />
        <StatCard label="Pending" value={count("Pending")} hint="awaiting approval" icon="alert" tone="gold" />
        <StatCard label="Active" value={count("Active")} hint="issued right now" icon="clock" tone="emerald" />
        <StatCard label="Completed" value={count("Completed")} hint="returned & inspected" icon="check" tone="sky" />
        <StatCard label="Cancelled" value={count("Cancelled")} hint="units released back" icon="close" tone="rose" />
      </div>

      <div className={`${CARD} mb-6 flex flex-wrap items-center gap-3 p-3.5`}>
        <div className="relative min-w-[200px] flex-1">
          <Icon name="search" className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search by booking ID, equipment, lab or status…" aria-label="Search your bookings" className="w-full rounded-xl border border-slate-200 bg-slate-50/70 py-2.5 pl-9 pr-3 text-[13.5px] outline-none focus:border-navy-400 focus:bg-white dark:border-navy-700 dark:bg-navy-950/60 dark:text-slate-100" />
        </div>
        <div className="flex flex-wrap items-center gap-1">
          {STATUSES.map((s) => (
            <button key={s} onClick={() => setStatus(s)} className={`rounded-lg px-2.5 py-1.5 text-[12.5px] font-bold transition ${status === s ? "bg-navy-800 text-white dark:bg-navy-600" : "bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-navy-900 dark:text-slate-300"}`}>
              {s}
              {s !== "All" && <span className="ml-1 opacity-70">{count(s)}</span>}
            </button>
          ))}
        </div>
      </div>

      {list.length === 0 ? (
        <EmptyState
          title={mine.length ? "No bookings match this filter" : "No bookings yet"}
          body={mine.length ? "Clear the search box or choose a different status to see the rest of your history." : "Pick a department, a laboratory and an instrument, then reserve the exact unit you need."}
          action={<LinkButton href="/departments" size="sm">Explore departments</LinkButton>}
        />
      ) : (
        <>
          {/* table on large screens */}
          <div className={`${CARD} hidden overflow-hidden lg:block`}>
            <table className="w-full text-[13px]">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-left dark:border-navy-700 dark:bg-navy-950/60">
                  {["Booking ID", "Equipment", "Department", "Subject / Lab", "Date", "Time", "Qty", "Status", "Actions"].map((h) => (
                    <th key={h} className="px-3 py-2.5 text-[10.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {list.map((b) => {
                  const eq = items.find((i) => i.id === b.equipmentId);
                  return (
                    <tr key={b.bookingId} className="border-b border-slate-100 align-middle last:border-0 hover:bg-slate-50/70 dark:border-navy-800 dark:hover:bg-navy-950/40">
                      <td className="px-3 py-2.5 font-mono text-[11.5px] font-bold text-navy-700 dark:text-gold-300">{b.bookingId}</td>
                      <td className="px-3 py-2.5">
                        <span className="flex items-center gap-2">
                          {eq && <PhotoImage photo={eq.photo} label={eq.name} className="h-9 w-12 shrink-0 rounded-md" width={120} height={90} />}
                          <span className="min-w-0">
                            <Link href={`/equipment/${b.equipmentId}`} className="block max-w-[220px] truncate font-bold text-navy-900 hover:underline dark:text-white">{b.equipmentName}</Link>
                            <span className="font-mono text-[10.5px] text-slate-400">{b.equipmentId}</span>
                          </span>
                        </span>
                      </td>
                      <td className="px-3 py-2.5 font-semibold text-slate-600 dark:text-slate-300">{DEPARTMENTS.find((d) => d.key === b.dept)?.short ?? b.dept}</td>
                      <td className="px-3 py-2.5 text-slate-600 dark:text-slate-300">{SUBJECTS.find((s) => s.slug === b.subject)?.name ?? b.subject}</td>
                      <td className="px-3 py-2.5 whitespace-nowrap text-slate-600 dark:text-slate-300">{formatDate(b.date)}</td>
                      <td className="px-3 py-2.5 whitespace-nowrap text-slate-600 dark:text-slate-300">{b.startTime}–{b.endTime}</td>
                      <td className="px-3 py-2.5 text-center font-bold text-navy-900 dark:text-white">{b.quantity}</td>
                      <td className="px-3 py-2.5"><span className={`inline-flex items-center rounded-full px-2 py-0.5 text-[10.5px] font-bold ring-1 ${BOOKING_STATUS_STYLE[b.status]}`}>{b.status}</span></td>
                      <td className="px-3 py-2.5">
                        <span className="flex items-center justify-end gap-1">
                          <button onClick={() => setOpenId(openId === b.bookingId ? null : b.bookingId)} className={btn("outline", "sm")} aria-expanded={openId === b.bookingId}>
                            <Icon name="eye" className="h-3.5 w-3.5" /> View
                          </button>
                          {canCancel(b) && (
                            <button onClick={() => setConfirmId(b.bookingId)} className={btn("ghost", "sm") + " !text-rose-600 hover:!bg-rose-50 dark:hover:!bg-rose-500/10"}>
                              Cancel
                            </button>
                          )}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          {/* cards on small screens */}
          <div className="space-y-3 lg:hidden">
            {list.map((b) => (
              <div key={b.bookingId} className={`${CARD} p-4`}>
                <div className="flex items-start justify-between gap-3">
                  <div>
                    <div className="font-mono text-[11.5px] font-bold text-navy-700 dark:text-gold-300">{b.bookingId}</div>
                    <Link href={`/equipment/${b.equipmentId}`} className="mt-1 block text-[15px] font-bold text-navy-900 hover:underline dark:text-white">{b.equipmentName}</Link>
                  </div>
                  <span className={`shrink-0 rounded-full px-2 py-0.5 text-[10.5px] font-bold ring-1 ${BOOKING_STATUS_STYLE[b.status]}`}>{b.status}</span>
                </div>
                <dl className="mt-3 grid grid-cols-2 gap-2 text-[12.5px]">
                  {[["Department", DEPARTMENTS.find((d) => d.key === b.dept)?.short ?? b.dept], ["Lab", SUBJECTS.find((s) => s.slug === b.subject)?.name ?? b.subject], ["Date", formatDate(b.date)], ["Time", `${b.startTime}–${b.endTime}`], ["Quantity", `${b.quantity} unit(s)`], ["Return", `${formatDate(b.returnDate)} ${b.returnTime}`]].map(([k, v]) => (
                    <div key={k as string}>
                      <dt className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">{k as string}</dt>
                      <dd className="font-semibold text-navy-900 dark:text-white">{v as string}</dd>
                    </div>
                  ))}
                </dl>
                <div className="mt-3 flex flex-wrap gap-2">
                  <Button variant="outline" size="sm" onClick={() => setOpenId(openId === b.bookingId ? null : b.bookingId)}><Icon name="eye" className="h-4 w-4" /> View booking</Button>
                  {canCancel(b) && <Button variant="ghost" size="sm" className="!text-rose-600" onClick={() => setConfirmId(b.bookingId)}>Cancel booking</Button>}
                </div>
              </div>
            ))}
          </div>
        </>
      )}

      {selected && (
        <section id="receipt" className="mt-8 scroll-mt-24">
          <SectionTitle
            eyebrow="Receipt"
            title={`Booking ${selected.bookingId}`}
            sub="Print or download the receipt; it carries the booking ID, the QR code and the countersignature lines."
            right={<button onClick={() => setOpenId(null)} className={btn("ghost", "sm")}><Icon name="close" className="h-4 w-4" /> Close</button>}
          />
          <div className="mb-3 flex flex-wrap items-center gap-2 no-print">
            <ReceiptActions booking={selected} />
            {canCancel(selected) && <Button variant="danger" size="sm" onClick={() => setConfirmId(selected.bookingId)}><Icon name="trash" className="h-4 w-4" /> Cancel this booking</Button>}
            <Link href={`/equipment/${selected.equipmentId}`} className={btn("outline", "sm")}><Icon name="eye" className="h-4 w-4" /> Equipment details</Link>
            {selected.adminNote && <span className="rounded-lg bg-slate-100 px-2.5 py-1 text-[12px] font-semibold text-slate-600 dark:bg-navy-800 dark:text-slate-300">In-charge note: {selected.adminNote}</span>}
          </div>
          <ReceiptSheet booking={selected} />
        </section>
      )}

      <div className="mt-10 grid gap-6 lg:grid-cols-[1.2fr_1fr]">
        <BookingCalendar bookings={mine} items={items} />
        <div className={`${CARD} p-5`}>
          <h3 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white"><Icon name="info" className="h-4.5 w-4.5 text-navy-500 dark:text-gold-400" /> Status meanings</h3>
          <ul className="mt-3 space-y-2 text-[13px]">
            {[
              ["Pending", "submitted, waiting for the lab in-charge to approve"],
              ["Approved", "instrument kept aside for your slot — collect on time"],
              ["Active", "issued to you; return before the end time"],
              ["Completed", "returned, inspected and signed off"],
              ["Cancelled", "withdrawn by you or the lab; units released"],
              ["Rejected", "not approved — see the in-charge note for the reason"],
            ].map(([s, d]) => (
              <li key={s} className="flex items-start gap-2.5">
                <span className={`mt-0.5 inline-flex shrink-0 items-center rounded-full px-2 py-0.5 text-[10.5px] font-bold ring-1 ${BOOKING_STATUS_STYLE[s]}`}>{s}</span>
                <span className="text-slate-600 dark:text-slate-400">{d}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {confirmId && (
        <div className="fixed inset-0 z-[60] grid place-items-center bg-navy-950/60 p-4 backdrop-blur-sm no-print" role="dialog" aria-modal="true" aria-label="Cancel booking confirmation">
          <div className={`${CARD} w-full max-w-md p-6 lb-fade-up`}>
            <span className="grid h-11 w-11 place-items-center rounded-2xl bg-rose-500/12 text-rose-600"><Icon name="alert" className="h-6 w-6" /></span>
            <h3 className="mt-3 font-display text-lg font-bold text-navy-900 dark:text-white">Cancel booking {confirmId}?</h3>
            <p className="mt-2 text-[13.5px] leading-relaxed text-slate-600 dark:text-slate-400">
              The reserved units return to the pool immediately and the receipt becomes invalid for the store counter. You can book the same instrument again in a new slot.
            </p>
            <div className="mt-5 flex justify-end gap-2">
              <button onClick={() => setConfirmId(null)} className={btn("outline", "sm")}>Keep booking</button>
              <button onClick={() => { const b = mine.find((x) => x.bookingId === confirmId); if (b) doCancel(b); }} className={btn("danger", "sm")}>
                <Icon name="check" className="h-4 w-4" /> Yes, cancel it
              </button>
            </div>
          </div>
        </div>
      )}
    </Page>
  );
}
