"use client";

import Link from "next/link";
import { Page } from "@/components/chrome";
import { PhotoImage } from "@/components/equipment";
import { CARD, Icon, LinkButton, SectionTitle, StatCard, btn } from "@/components/ui";
import { COLLEGE_ADDRESS, COLLEGE_NAME, DEPARTMENTS, SEED_EQUIPMENT, SUBJECTS } from "@/lib/data";
import { useLabbook } from "@/lib/store";

export default function AboutPage() {
  const { items } = useLabbook();
  const units = items.reduce((s, e) => s + e.total, 0);

  return (
    <Page>
      <nav aria-label="Breadcrumb" className="mb-4 flex flex-wrap items-center gap-1.5 text-[13px]">
        <Link href="/" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Home</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <span className="font-semibold text-slate-500 dark:text-slate-400">About</span>
      </nav>

      <header className={`${CARD} mb-8 overflow-hidden`}>
        <div className="grid gap-0 lg:grid-cols-[1.25fr_1fr]">
          <div className="p-7">
            <div className="mb-2 text-[11px] font-bold uppercase tracking-[0.2em] text-navy-500 dark:text-gold-400">About the platform</div>
            <h1 className="font-display text-[30px] font-extrabold leading-tight tracking-tight text-navy-900 sm:text-[38px] dark:text-white">
              A laboratory store that students can actually navigate
            </h1>
            <p className="mt-4 text-[14.5px] leading-relaxed text-slate-600 dark:text-slate-400">
              {COLLEGE_NAME} runs teaching and research laboratories across {DEPARTMENTS.length} departments. Before LABBOOK, instruments were allocated on paper registers — students could not tell what was free, and stores staff spent the first half-hour of every lab answering the same question. LABBOOK publishes every asset against its department and subject laboratory, keeps a live count of what is issued, and lets a student reserve a specific unit for a specific slot.
            </p>
            <div className="mt-5 flex flex-wrap gap-2">
              <LinkButton href="/departments" variant="primary" size="sm"><Icon name="layers" className="h-4 w-4" /> Browse departments</LinkButton>
              <LinkButton href="/equipment" variant="outline" size="sm"><Icon name="box" className="h-4 w-4" /> Equipment catalogue</LinkButton>
              <LinkButton href="/contact" variant="ghost" size="sm">Contact the store <Icon name="arrowRight" className="h-4 w-4" /></LinkButton>
            </div>
          </div>
          <div className="relative min-h-[240px]">
            <PhotoImage photo="codingClass" label="Students working in a college laboratory" className="h-full w-full" width={900} height={700} />
            <div className="absolute inset-0 bg-gradient-to-t from-navy-950/70 to-transparent" />
            <div className="absolute bottom-4 left-4 right-4 rounded-xl bg-white/95 p-3 text-[12px] font-medium text-navy-800 shadow-sm dark:bg-navy-900/95 dark:text-slate-200">
              Equipment photo: Ludovic Delot / Pexels · Pexels License
            </div>
          </div>
        </div>
      </header>

      <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Departments" value={DEPARTMENTS.length} hint="including central facilities" icon="layers" tone="navy" />
        <StatCard label="Laboratories" value={SUBJECTS.length} hint="subject-wise labs" icon="building" tone="violet" />
        <StatCard label="Equipment types" value={SEED_EQUIPMENT.length} hint={`${units} physical units`} icon="box" tone="sky" />
        <StatCard label="Counter hours" value="08:40–17:00" hint="Mon–Sat issue & return" icon="clock" tone="gold" />
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        <section className={`${CARD} p-6`}>
          <h2 className="font-display text-xl font-bold tracking-tight text-navy-900 dark:text-white">What the system guarantees</h2>
          <ul className="mt-4 space-y-3">
            {[
              ["No giant flat list", "Equipment is separated department-wise and subject-wise. A laboratory page shows only the instruments belonging to that laboratory."],
              ["Honest availability", "Free units are computed per date: total quantity minus what other bookings already hold, including your own pending request."],
              ["Traceable issue", "Each booking gets a unique ID and a QR receipt; the store counter verifies the serial number against the same record."],
              ["Maintenance visibility", "Instruments under servicing are labelled with text and icon — never colour alone — and cannot be reserved."],
              ["Accountable usage", "Cancellation, approvals, in-charge notes and completion are recorded against the booking ID."],
            ].map(([t, d]) => (
              <li key={t} className="flex gap-3">
                <span className="mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-emerald-500/12 text-emerald-600 dark:text-emerald-400"><Icon name="check" className="h-4 w-4" strokeWidth={2.4} /></span>
                <span>
                  <span className="block text-[14px] font-bold text-navy-900 dark:text-white">{t}</span>
                  <span className="mt-0.5 block text-[13px] leading-relaxed text-slate-600 dark:text-slate-400">{d}</span>
                </span>
              </li>
            ))}
          </ul>
        </section>

        <section className={`${CARD} p-6`}>
          <h2 className="font-display text-xl font-bold tracking-tight text-navy-900 dark:text-white">Who uses what</h2>
          <div className="mt-4 overflow-hidden rounded-xl border border-slate-200 dark:border-navy-700">
            <table className="w-full text-[13px]">
              <thead>
                <tr className="bg-slate-50 text-left dark:bg-navy-950/60">
                  <th className="px-3 py-2 text-[10.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Role</th>
                  <th className="px-3 py-2 text-[10.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Can do</th>
                </tr>
              </thead>
              <tbody>
                {[
                  ["Student", "Browse catalogue, check availability, book, cancel, print receipt, favourite & compare equipment."],
                  ["Faculty", "Everything a student can do, plus sponsor project slots, view class-wise bookings for their department."],
                  ["Lab engineer", "Issue and return entries, mark maintenance, adjust quantities and calibration dates."],
                  ["Administrator", "Full CRUD on equipment, add departments/labs, approve or reject bookings, manage images and sync the database."],
                ].map(([r, d], i) => (
                  <tr key={r} className={i % 2 ? "bg-slate-50/60 dark:bg-navy-950/30" : ""}>
                    <th scope="row" className="w-[110px] px-3 py-2.5 text-left font-bold text-navy-900 dark:text-white">{r}</th>
                    <td className="px-3 py-2.5 text-slate-600 dark:text-slate-400">{d}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <h3 className="mt-6 font-display text-base font-bold text-navy-900 dark:text-white">Technology & data model</h3>
          <p className="mt-2 text-[13px] leading-relaxed text-slate-600 dark:text-slate-400">
            The interface is plain HTML5 semantics, CSS3 and JavaScript — delivered here on a Next.js shell so the same routes can be opened directly in a browser. Data lives in a realistic structure (
            <code className="mx-1 rounded bg-slate-100 px-1 font-mono text-[12px] dark:bg-navy-800">departments → subjects → equipment → bookings</code>)
            inside <code className="rounded bg-slate-100 px-1 font-mono text-[12px] dark:bg-navy-800">src/lib/data</code>, persisted through localStorage in
            <code className="mx-1 rounded bg-slate-100 px-1 font-mono text-[12px] dark:bg-navy-800">src/lib/store.tsx</code>.
            A Drizzle ORM schema with <code className="rounded bg-slate-100 px-1 font-mono text-[12px] dark:bg-navy-800">/api/bookings</code> and
            <code className="mx-1 rounded bg-slate-100 px-1 font-mono text-[12px] dark:bg-navy-800"> /api/equipment</code> endpoints mirrors the same shapes, so switching to MySQL, PostgreSQL, Mongo or Firebase is a data-source swap.
          </p>
        </section>
      </div>

      <section className={`${CARD} mt-6 p-6`}>
        <SectionTitle eyebrow="Departments" title="Laboratory ownership" sub="Each department keeps its own lab list; the store counter is shared." />
        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-4">
          {DEPARTMENTS.map((d) => (
            <Link key={d.key} href={`/departments/${d.key}`} className="group flex items-start gap-3 rounded-xl border border-slate-200 p-3 transition hover:-translate-y-0.5 hover:shadow-[var(--shadow-card)] dark:border-navy-700">
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl text-white" style={{ background: `hsl(${d.hue} 55% 36%)` }}>
                <svg viewBox="0 0 24 24" className="h-4.5 w-4.5" fill="none" stroke="currentColor" strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round"><path d={d.icon} /></svg>
              </span>
              <span className="min-w-0">
                <span className="block text-[13.5px] font-bold text-navy-900 group-hover:underline dark:text-white">{d.short}</span>
                <span className="block truncate text-[11.5px] text-slate-500 dark:text-slate-400">{SUBJECTS.filter((s) => s.dept === d.key).length} labs · {d.building}</span>
              </span>
            </Link>
          ))}
        </div>
        <p className="mt-4 text-[12px] text-slate-500 dark:text-slate-400">{COLLEGE_ADDRESS}</p>
        <Link href="/faq" className={`${btn("outline", "sm")} mt-3`}>Policies &amp; FAQ <Icon name="arrowRight" className="h-4 w-4" /></Link>
      </section>
    </Page>
  );
}
