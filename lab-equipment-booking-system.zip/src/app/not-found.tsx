import Link from "next/link";

export default function NotFound() {
  return (
    <div className="mx-auto flex min-h-[60vh] max-w-lg flex-col items-center justify-center gap-4 px-6 py-20 text-center">
      <span className="grid h-16 w-16 place-items-center rounded-3xl bg-navy-900 font-display text-2xl font-black text-gold-400">404</span>
      <h1 className="font-display text-2xl font-extrabold tracking-tight text-navy-900 dark:text-white">That page is not in the catalogue</h1>
      <p className="text-sm leading-relaxed text-slate-600 dark:text-slate-400">
        The link may be old, or the equipment was withdrawn by the laboratory admin. Start from the departments list and drill down: department → subject laboratory → equipment.
      </p>
      <div className="flex flex-wrap justify-center gap-2 pt-2">
        <Link href="/departments" className="rounded-xl bg-navy-800 px-4 py-2.5 text-sm font-semibold text-white transition hover:bg-navy-700">Browse departments</Link>
        <Link href="/equipment" className="rounded-xl border border-slate-300 px-4 py-2.5 text-sm font-semibold text-navy-800 transition hover:bg-slate-50 dark:border-navy-600 dark:text-slate-100 dark:hover:bg-navy-800">Search equipment</Link>
      </div>
    </div>
  );
}
