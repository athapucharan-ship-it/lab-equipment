"use client";

import Link from "next/link";
import { use } from "react";
import { BackLink, Page } from "@/components/chrome";
import { BookingForm } from "@/components/booking-form";
import { PhotoImage } from "@/components/equipment";
import { CARD, EmptyState, Icon, LinkButton, SectionTitle, StatusBadge } from "@/components/ui";
import { formatDate } from "@/lib/data";
import { useLabbook } from "@/lib/store";

export default function BookingForEquipmentPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const decoded = decodeURIComponent(id);
  const { byId, ready, items } = useLabbook();
  const eq = byId(decoded);

  if (!ready) return <Page><div className="py-20 text-center text-slate-500">Loading equipment…</div></Page>;

  if (!eq) {
    return (
      <Page>
        <EmptyState title="Equipment not found" body={`Cannot start a booking for “${decoded}” — that asset id is not in the catalogue.`} action={<LinkButton href="/booking" size="sm">Open the general booking form</LinkButton>} />
      </Page>
    );
  }

  const others = items.filter((e) => e.subject === eq.subject && e.id !== eq.id).slice(0, 3);

  return (
    <Page>
      <nav aria-label="Breadcrumb" className="mb-4 flex flex-wrap items-center gap-1.5 text-[13px]">
        <Link href="/" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Home</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <Link href={`/departments/${eq.dept}`} className="font-medium text-navy-600 hover:underline dark:text-navy-200">{eq.deptShort}</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <Link href={`/departments/${eq.dept}/${eq.subject}`} className="font-medium text-navy-600 hover:underline dark:text-navy-200">{eq.subjectName}</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <Link href={`/equipment/${eq.id}`} className="font-medium text-navy-600 hover:underline dark:text-navy-200">{eq.id}</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <span className="font-semibold text-slate-500 dark:text-slate-400">Booking</span>
      </nav>

      <BackLink href={`/equipment/${eq.id}`} label="Back to equipment details" />

      <div className="grid gap-6 lg:grid-cols-[minmax(0,2.2fr)_minmax(0,1fr)]">
        <div>
          <div className="mb-5">
            <div className="mb-1.5 text-[11px] font-bold uppercase tracking-[0.2em] text-navy-500 dark:text-gold-400">Booking request · {eq.id}</div>
            <h1 className="font-display text-[26px] font-extrabold leading-tight tracking-tight text-navy-900 sm:text-[32px] dark:text-white">
              Reserve {eq.name}
            </h1>
            <p className="mt-2 max-w-2xl text-[13.5px] text-slate-600 dark:text-slate-400">
              {eq.short} Free units are re-checked for the date you choose; a booking ID and QR receipt are generated on submission.
            </p>
          </div>
          <BookingForm presetEquipmentId={eq.id} />
        </div>

        <aside className="space-y-5">
          <div className={`${CARD} overflow-hidden`}>
            <PhotoImage photo={eq.photo} label={eq.name} className="aspect-[4/3] w-full" width={640} height={480} />
            <div className="p-4">
              <div className="flex items-center justify-between gap-2">
                <h2 className="font-display text-[15px] font-bold text-navy-900 dark:text-white">{eq.name}</h2>
                <StatusBadge status={eq.availability} size="sm" />
              </div>
              <dl className="mt-3 space-y-1.5 text-[12.5px]">
                {[
                  ["Equipment ID", eq.id],
                  ["Laboratory", eq.subjectName],
                  ["Total quantity", `${eq.total} unit(s)`],
                  ["Free right now", `${eq.available} unit(s)`],
                  ["Size", eq.size.footprint],
                  ["Weight", eq.size.weight],
                  ["Added", formatDate(eq.addedOn)],
                ].map(([k, v]) => (
                  <div key={k} className="flex justify-between gap-3 border-b border-dashed border-slate-200 pb-1.5 last:border-0 dark:border-navy-700">
                    <dt className="text-slate-500 dark:text-slate-400">{k}</dt>
                    <dd className="text-right font-bold text-navy-900 dark:text-white">{v}</dd>
                  </div>
                ))}
              </dl>
              <LinkButton href={`/equipment/${eq.id}`} variant="outline" size="sm" className="mt-3 w-full">
                <Icon name="eye" className="h-4 w-4" /> Full specification
              </LinkButton>
            </div>
          </div>

          {eq.safety && (
            <div className={`${CARD} border-amber-300/60 bg-amber-50/70 p-4 dark:border-amber-500/30 dark:bg-amber-500/10`}>
              <h3 className="flex items-center gap-2 text-[13px] font-bold text-navy-900 dark:text-white"><Icon name="shield" className="h-4 w-4 text-amber-600" /> Before you book</h3>
              <p className="mt-1.5 text-[12.5px] leading-relaxed text-slate-700 dark:text-slate-300">{eq.safety}</p>
            </div>
          )}

          {others.length > 0 && (
            <div className={`${CARD} p-4`}>
              <SectionTitle title="Also in this lab" />
              <ul className="-mt-2 space-y-2">
                {others.map((o) => (
                  <li key={o.id} className="flex items-center gap-2.5">
                    <PhotoImage photo={o.photo} label={o.name} className="h-10 w-14 shrink-0 rounded-lg" width={160} height={120} />
                    <span className="min-w-0 flex-1">
                      <Link href={`/booking/${o.id}`} className="block truncate text-[13px] font-bold text-navy-900 hover:underline dark:text-white">{o.name}</Link>
                      <span className="text-[11px] text-slate-500 dark:text-slate-400">{o.available}/{o.total} free</span>
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </aside>
      </div>
    </Page>
  );
}
