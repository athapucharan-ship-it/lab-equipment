"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { Page } from "@/components/chrome";
import { BookingForm } from "@/components/booking-form";
import { BookingCalendar } from "@/components/extras";
import { CARD, Icon, LoadingBlock, SectionTitle } from "@/components/ui";
import { useLabbook } from "@/lib/store";

export default function BookingPage() {
  const { items, ready, bookings } = useLabbook();
  const [presets, setPresets] = useState<{ dept?: string; subject?: string }>({});

  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    setPresets({ dept: p.get("dept") ?? undefined, subject: p.get("subject") ?? undefined });
  }, []);

  const maintenance = items.filter((e) => e.availability === "maintenance");

  return (
    <Page>
      <nav aria-label="Breadcrumb" className="mb-4 flex flex-wrap items-center gap-1.5 text-[13px]">
        <Link href="/" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Home</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <Link href="/equipment" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Equipment</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <span className="font-semibold text-slate-500 dark:text-slate-400">New booking</span>
      </nav>

      <div className="mb-7 flex flex-wrap items-end justify-between gap-4">
        <div className="max-w-2xl">
          <div className="mb-1.5 text-[11px] font-bold uppercase tracking-[0.2em] text-navy-500 dark:text-gold-400">Step 5 · Booking request</div>
          <h1 className="font-display text-[28px] font-extrabold leading-tight tracking-tight text-navy-900 sm:text-[34px] dark:text-white">Book laboratory equipment</h1>
          <p className="mt-2 text-[13.5px] leading-relaxed text-slate-600 dark:text-slate-400">
            Pick the department, the subject laboratory and the instrument. LABBOOK checks the free units for your exact date and time window before generating a booking ID.
          </p>
        </div>
      </div>

      <div className="grid gap-6 lg:grid-cols-[minmax(0,2.2fr)_minmax(0,1fr)]">
        <div>{ready ? <BookingForm presetDept={presets.dept} presetSubject={presets.subject} /> : <LoadingBlock label="Preparing the booking form…" />}</div>

        <aside className="space-y-5">
          <div className={`${CARD} p-5`}>
            <h2 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white"><Icon name="info" className="h-4.5 w-4.5 text-navy-500 dark:text-gold-400" /> How approval works</h2>
            <ol className="mt-3 space-y-2.5 text-[13px] text-slate-600 dark:text-slate-400">
              {[
                ["Pending", "Request lands in the lab in-charge queue."],
                ["Approved", "Instrument is kept aside and labelled with your booking ID."],
                ["Active", "Issued at the counter — timer starts."],
                ["Completed", "Returned, inspected and signed off."],
              ].map(([t, d], i) => (
                <li key={t} className="flex gap-3">
                  <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-navy-800 font-mono text-[11px] font-bold text-white dark:bg-navy-700">{i + 1}</span>
                  <span><strong className="font-bold text-navy-900 dark:text-white">{t}</strong> — {d}</span>
                </li>
              ))}
            </ol>
          </div>

          <div className={`${CARD} p-5`}>
            <h2 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white"><Icon name="clock" className="h-4.5 w-4.5 text-navy-500 dark:text-gold-400" /> Counter hours</h2>
            <ul className="mt-3 space-y-1.5 text-[13px]">
              <li className="flex justify-between rounded-lg bg-slate-50 px-3 py-2 dark:bg-navy-950/60"><span className="text-slate-500 dark:text-slate-400">Mon – Fri</span><span className="font-bold text-navy-900 dark:text-white">08:40 – 17:00</span></li>
              <li className="flex justify-between rounded-lg bg-slate-50 px-3 py-2 dark:bg-navy-950/60"><span className="text-slate-500 dark:text-slate-400">Saturday</span><span className="font-bold text-navy-900 dark:text-white">09:00 – 13:00</span></li>
              <li className="flex justify-between rounded-lg bg-slate-50 px-3 py-2 dark:bg-navy-950/60"><span className="text-slate-500 dark:text-slate-400">Field kits (CE)</span><span className="font-bold text-navy-900 dark:text-white">collect by 08:40</span></li>
            </ul>
          </div>

          {maintenance.length > 0 && (
            <div className={`${CARD} border-sky-300/60 bg-sky-50/70 p-5 dark:border-sky-500/30 dark:bg-sky-500/10`}>
              <h2 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white"><Icon name="wrench" className="h-4.5 w-4.5 text-sky-600 dark:text-sky-300" /> Under maintenance ({maintenance.length})</h2>
              <ul className="mt-2.5 space-y-1.5 text-[12.5px] text-slate-700 dark:text-slate-300">
                {maintenance.slice(0, 6).map((m) => (
                  <li key={m.id} className="flex items-center justify-between gap-2 rounded-lg bg-white/70 px-2.5 py-1.5 dark:bg-navy-900/60">
                    <Link href={`/equipment/${m.id}`} className="truncate font-semibold hover:underline">{m.name}</Link>
                    <span className="shrink-0 font-mono text-[10.5px] text-slate-500 dark:text-slate-400">{m.id}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}

          {ready && <BookingCalendar bookings={bookings} items={items} />}

          <div className={`${CARD} p-5`}>
            <SectionTitle title="Need the full policy?" />
            <p className="-mt-2 text-[13px] text-slate-600 dark:text-slate-400">Suspension rules, damage reporting, PPE requirements and project bookings after hours are covered in the FAQ.</p>
            <Link href="/faq" className="mt-3 inline-flex items-center gap-1.5 text-[13px] font-bold text-navy-700 underline decoration-gold-400 dark:text-gold-300">Read the FAQ <Icon name="arrowRight" className="h-4 w-4" /></Link>
          </div>
        </aside>
      </div>
    </Page>
  );
}

const btnLink = "";
