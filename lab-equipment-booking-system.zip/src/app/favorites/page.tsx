"use client";

import Link from "next/link";
import { useMemo } from "react";
import { Page } from "@/components/chrome";
import { EquipmentGrid, RecentlyViewed } from "@/components/equipment";
import { EmptyState, Icon, LinkButton, LoadingBlock, SectionTitle, btn } from "@/components/ui";
import { useLabbook } from "@/lib/store";

export default function FavoritesPage() {
  const { favorites, items, ready, toggleFavorite, compare } = useLabbook();
  const safeList = useMemo(() => items.filter((e) => favorites.includes(e.id)), [items, favorites]);

  if (!ready) return <Page><LoadingBlock label="Loading your favourites…" /></Page>;

  return (
    <Page>
      <nav aria-label="Breadcrumb" className="mb-4 flex flex-wrap items-center gap-1.5 text-[13px]">
        <Link href="/" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Home</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <span className="font-semibold text-slate-500 dark:text-slate-400">Favourites</span>
      </nav>

      <SectionTitle
        eyebrow="Saved on this device"
        title={`Favourite equipment (${safeList.length})`}
        sub="Star the instruments you use every week — the list is stored in your browser, not on a server, and follows the same department → lab → equipment links."
        right={safeList.length > 0 ? (
          <div className="flex flex-wrap gap-2">
            <LinkButton href="/compare" variant="outline" size="sm">Compare list ({compare.length})</LinkButton>
            <button onClick={() => safeList.forEach((e) => toggleFavorite(e.id))} className={btn("ghost", "sm")}><Icon name="trash" className="h-4 w-4" /> Clear all</button>
          </div>
        ) : undefined}
      />

      {safeList.length === 0 ? (
        <EmptyState
          title="No favourites yet"
          body="Open any laboratory, hover an equipment card and tap the heart. Favourites appear here for quick access before your lab session."
          action={<LinkButton href="/departments" size="sm">Browse departments</LinkButton>}
        />
      ) : (
        <EquipmentGrid items={safeList} />
      )}

      <div className="mt-10"><RecentlyViewed /></div>
    </Page>
  );
}
