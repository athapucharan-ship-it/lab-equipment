"use client";

import Link from "next/link";
import { use } from "react";
import { Page } from "@/components/chrome";
import { CARD, EmptyState, Icon, LinkButton, LoadingBlock, StatCard, btn } from "@/components/ui";
import { DEPARTMENTS, SUBJECTS, equipmentCounts, type DeptKey } from "@/lib/data";
import { useLabbook } from "@/lib/store";

export default function DepartmentPage({ params }: { params: Promise<{ dept: string }> }) {
  const { dept } = use(params);
  const { items, ready } = useLabbook();

  if (!ready) return <Page><LoadingBlock label="Loading department laboratories…" /></Page>;

  const d = DEPARTMENTS.find((x) => x.key === (dept as DeptKey));
  if (!d) {
    return (
      <Page>
        <EmptyState
          title="Department not found"
          body={`“${dept}” is not a registered department code. Choose one of the ${DEPARTMENTS.length} departments to see its laboratories.`}
          action={<LinkButton href="/departments" size="sm">Back to all departments</LinkButton>}
        />
      </Page>
    );
  }

  const labs = SUBJECTS.filter((s) => s.dept === d.key);
  const scoped = items.filter((e) => e.dept === d.key);
  const units = scoped.reduce((s, e) => s + e.total, 0);
  const free = scoped.reduce((s, e) => s + e.available, 0);
  const booked = units - free;
  const maint = scoped.filter((e) => e.availability === "maintenance");

  return (
    <>
      <section className="relative overflow-hidden text-white" style={{ background: `linear-gradient(135deg, hsl(${d.hue} 62% 22%), hsl(${(d.hue + 40) % 360} 58% 34%))` }}>
        <div className="lb-grid-bg absolute inset-0 opacity-50" />
        <Page className="relative !py-10">
          <nav aria-label="Breadcrumb" className="mb-4 flex flex-wrap items-center gap-1.5 text-[13px] text-white/80">
            <Link href="/" className="font-medium hover:text-white hover:underline">Home</Link>
            <Icon name="chevronRight" className="h-3.5 w-3.5" />
            <Link href="/departments" className="font-medium hover:text-white hover:underline">Departments</Link>
            <Icon name="chevronRight" className="h-3.5 w-3.5" />
            <span className="font-bold text-white">{d.short}</span>
          </nav>

          <div className="flex flex-wrap items-start justify-between gap-6">
            <div className="max-w-3xl">
              <div className="flex items-center gap-3">
                <span className="grid h-12 w-12 place-items-center rounded-2xl bg-white/15 ring-1 ring-white/25">
                  <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round"><path d={d.icon} /></svg>
                </span>
                <div>
                  <h1 className="font-display text-[27px] font-extrabold leading-tight tracking-tight sm:text-[34px]">{d.name}</h1>
                  <p className="text-[13px] font-semibold uppercase tracking-[0.14em] text-white/70">{d.tagline}</p>
                </div>
              </div>
              <p className="mt-4 text-[14.5px] leading-relaxed text-white/85">{d.description}</p>
              <dl className="mt-5 grid gap-x-8 gap-y-2 text-[13px] sm:grid-cols-2">
                <div><dt className="text-white/60">Head of department</dt><dd className="font-semibold">{d.hod}</dd></div>
                <div><dt className="text-white/60">Location</dt><dd className="font-semibold">{d.building} · {d.floor}</dd></div>
                <div><dt className="text-white/60">Lab store contact</dt><dd className="font-semibold">{d.contact}</dd></div>
                <div><dt className="text-white/60">Laboratory subjects</dt><dd className="font-semibold">{labs.length} labs · {equipmentCounts(d.key)} equipment types</dd></div>
              </dl>
            </div>
            <div className="rounded-2xl bg-white/10 p-4 ring-1 ring-white/20 backdrop-blur">
              <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-white/70">Live availability</div>
              <div className="mt-2 font-display text-4xl font-extrabold">{free}<span className="text-xl text-white/60">/{units}</span></div>
              <div className="mt-1 text-[12px] text-white/75">units free across {labs.length} laboratories</div>
              <div className="mt-3 h-2 overflow-hidden rounded-full bg-white/20">
                <div className="h-full rounded-full bg-emerald-400" style={{ width: `${Math.round((free / Math.max(1, units)) * 100)}%` }} />
              </div>
              <div className="mt-3 grid grid-cols-2 gap-2 text-[11.5px]">
                <span className="rounded-lg bg-white/10 px-2 py-1">{booked} reserved</span>
                <span className="rounded-lg bg-white/10 px-2 py-1">{maint.length} maintenance</span>
              </div>
            </div>
          </div>
        </Page>
      </section>

      <Page>
        <div className="mb-6 flex flex-wrap items-center gap-2">
          <Link href="/departments" className={btn("outline", "sm")}><Icon name="back" className="h-4 w-4" /> All departments</Link>
          <Link href="/equipment" className={btn("ghost", "sm")}><Icon name="search" className="h-4 w-4" /> Search this department</Link>
          <Link href={`/equipment?dept=${d.key}`} className={btn("ghost", "sm")}><Icon name="box" className="h-4 w-4" /> All {d.short} equipment</Link>
        </div>

        <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          <StatCard label="Laboratories" value={labs.length} hint="subject-wise labs" icon="building" tone="navy" />
          <StatCard label="Equipment types" value={equipmentCounts(d.key)} hint={`${units} units in total`} icon="box" tone="sky" />
          <StatCard label="Free units" value={free} hint={`${booked} already reserved`} icon="check" tone="emerald" />
          <StatCard label="Under maintenance" value={maint.length} hint={maint.length ? maint.map((m) => m.id).join(", ") : "all serviceable"} icon="wrench" tone="rose" />
        </div>

        <h2 className="mb-4 font-display text-2xl font-bold tracking-tight text-navy-900 dark:text-white">
          Laboratory subjects in {d.short}
        </h2>
        <p className="-mt-2 mb-5 max-w-2xl text-[13.5px] text-slate-600 dark:text-slate-400">
          Select a laboratory to open only its equipment list. Availability counts are calculated for today.
        </p>

        <div className="grid gap-5 md:grid-cols-2">
          {labs.map((s, i) => {
            const labItems = scoped.filter((e) => e.subject === s.slug);
            const labFree = labItems.reduce((acc, e) => acc + e.available, 0);
            const labUnits = labItems.reduce((acc, e) => acc + e.total, 0);
            return (
              <article key={s.slug} className="lb-fade-up" style={{ animationDelay: `${i * 40}ms` }}>
                <div className={`${CARD} flex h-full flex-col p-5 transition hover:shadow-[var(--shadow-lift)]`}>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <h3 className="font-display text-[17px] font-bold leading-snug text-navy-900 dark:text-white">
                        <Link href={`/departments/${d.key}/${s.slug}`} className="transition hover:text-navy-600 dark:hover:text-gold-300">{s.name}</Link>
                      </h3>
                      <div className="mt-1.5 flex flex-wrap items-center gap-1.5 text-[11.5px]">
                        <span className="rounded-md bg-navy-900 px-1.5 py-0.5 font-mono font-bold text-white dark:bg-navy-700">{s.code}</span>
                        <span className="text-slate-500 dark:text-slate-400">{s.semester}</span>
                        <span className="text-slate-400">·</span>
                        <span className="text-slate-500 dark:text-slate-400">Room {s.room}</span>
                      </div>
                    </div>
                    <span className="shrink-0 rounded-xl px-2.5 py-1.5 text-center text-white" style={{ background: `hsl(${d.hue} 55% 36%)` }}>
                      <span className="block font-display text-lg font-extrabold leading-none">{labItems.length}</span>
                      <span className="block text-[9.5px] uppercase tracking-wider opacity-80">assets</span>
                    </span>
                  </div>

                  <p className="mt-3 text-[13px] leading-relaxed text-slate-600 dark:text-slate-400">
                    {s.description ?? `${s.name} — teaching laboratory handled by ${d.short}. Book the instruments below against your lab slot; the supervisor issues and receives each unit.`}
                  </p>

                  <ul className="mt-3 space-y-1.5">
                    {labItems.slice(0, 5).map((e) => (
                      <li key={e.id} className="flex items-center gap-2 text-[13px]">
                        <span className={`h-1.5 w-1.5 shrink-0 rounded-full ${e.availability === "available" ? "bg-emerald-500" : e.availability === "partial" ? "bg-amber-500" : e.availability === "maintenance" ? "bg-sky-500" : "bg-rose-500"}`} />
                        <Link href={`/equipment/${e.id}`} className="truncate font-medium text-navy-800 hover:underline dark:text-slate-200">{e.name}</Link>
                        <span className="ml-auto shrink-0 font-mono text-[11px] text-slate-400">{e.id}</span>
                      </li>
                    ))}
                    {labItems.length > 5 && <li className="text-[12px] font-semibold text-slate-400">+ {labItems.length - 5} more instruments in this lab</li>}
                  </ul>

                  <div className="mt-4 grid grid-cols-3 gap-2 border-t border-slate-100 pt-3 text-center dark:border-navy-800">
                    <div>
                      <div className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Free</div>
                      <div className="font-display text-[15px] font-extrabold text-emerald-600 dark:text-emerald-400">{labFree}</div>
                    </div>
                    <div className="border-x border-slate-100 dark:border-navy-800">
                      <div className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Units</div>
                      <div className="font-display text-[15px] font-extrabold text-navy-900 dark:text-white">{labUnits}</div>
                    </div>
                    <div>
                      <div className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Lab hours</div>
                      <div className="mt-0.5 truncate text-[11px] font-semibold text-slate-600 dark:text-slate-300">{s.labHours.split("·")[0]}</div>
                    </div>
                  </div>

                  <div className="mt-4 flex items-center gap-2">
                    <Link href={`/departments/${d.key}/${s.slug}`} className={`${btn("primary", "sm")} flex-1`}>
                      View Laboratory <Icon name="arrowRight" className="h-3.5 w-3.5" />
                    </Link>
                    <Link href={`/equipment?dept=${d.key}&subject=${s.slug}`} className={btn("outline", "sm")} title="Open this laboratory inside the searchable catalogue">
                      <Icon name="search" className="h-4 w-4" />
                    </Link>
                  </div>
                </div>
              </article>
            );
          })}
        </div>

        <div className={`${CARD} mt-8 grid gap-5 p-6 md:grid-cols-2`}>
          <div>
            <h3 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white"><Icon name="shield" className="h-4.5 w-4.5 text-navy-500 dark:text-gold-400" /> Laboratory safety for {d.short}</h3>
            <ul className="mt-3 space-y-2 text-[13px] text-slate-600 dark:text-slate-400">
              {labs.slice(0, 4).map((s) => (
                <li key={s.slug} className="flex gap-2 rounded-xl bg-slate-50 p-2.5 dark:bg-navy-950/60">
                  <Icon name="alert" className="mt-0.5 h-4 w-4 shrink-0 text-amber-500" />
                  <span><strong className="font-bold text-navy-900 dark:text-white">{s.name}:</strong> {s.safety}</span>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h3 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white"><Icon name="check" className="h-4.5 w-4.5 text-emerald-500" /> What each lab delivers</h3>
            <ul className="mt-3 space-y-2.5 text-[13px] text-slate-600 dark:text-slate-400">
              {labs.slice(0, 4).map((s) => (
                <li key={s.slug}>
                  <div className="font-bold text-navy-900 dark:text-white">{s.name}</div>
                  <ul className="mt-1 grid gap-1">
                    {s.outcomes.map((o) => (
                      <li key={o} className="flex items-start gap-1.5"><Icon name="check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" /> {o}</li>
                    ))}
                  </ul>
                </li>
              ))}
            </ul>
          </div>
        </div>
      </Page>
    </>
  );
}


