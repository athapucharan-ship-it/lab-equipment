"use client";

import Link from "next/link";
import { use } from "react";
import { useMemo, useState } from "react";
import { BackLink, Page } from "@/components/chrome";
import { EquipmentGrid } from "@/components/equipment";
import { MaintenanceNotice } from "@/components/equipment";
import { CARD, EmptyState, Icon, LinkButton, LoadingBlock, SectionTitle, StatusBadge, btn } from "@/components/ui";
import { DEPARTMENTS, SUBJECTS, equipmentCounts } from "@/lib/data";
import { useLabbook } from "@/lib/store";

export default function SubjectLabPage({ params }: { params: Promise<{ dept: string; subject: string }> }) {
  const { dept, subject } = use(params);
  const { items, ready } = useLabbook();
  const [query, setQuery] = useState("");
  const [only, setOnly] = useState<"all" | "free" | "maint">("all");
  const [sort, setSort] = useState<"az" | "availability" | "recent">("availability");

  const d = DEPARTMENTS.find((x) => x.key === dept);
  const lab = SUBJECTS.find((s) => s.dept === dept && s.slug === subject);

  const labItems = useMemo(() => {
    let list = items.filter((e) => e.dept === dept && e.subject === subject);
    const q = query.trim().toLowerCase();
    if (q) list = list.filter((e) => [e.name, e.id, e.manufacturer, e.model, e.category, e.short].join(" ").toLowerCase().includes(q));
    if (only === "free") list = list.filter((e) => e.available > 0 && e.availability !== "maintenance");
    if (only === "maint") list = list.filter((e) => e.availability === "maintenance");
    const rank = { available: 0, partial: 1, booked: 2, maintenance: 3 } as const;
    if (sort === "az") list = [...list].sort((a, b) => a.name.localeCompare(b.name));
    if (sort === "availability") list = [...list].sort((a, b) => rank[a.availability] - rank[b.availability]);
    if (sort === "recent") list = [...list].sort((a, b) => (b.addedOn || "").localeCompare(a.addedOn || ""));
    return list;
  }, [items, dept, subject, query, only, sort]);

  if (!ready) return <Page><LoadingBlock label="Loading laboratory equipment…" /></Page>;

  if (!d || !lab) {
    return (
      <Page>
        <EmptyState title="Laboratory not found" body={`The subject “${subject}” does not exist under “${dept}”. Open the department page to see the laboratories that do.`} action={<LinkButton href="/departments" size="sm">Browse departments</LinkButton>} />
      </Page>
    );
  }

  const units = labItems.reduce((s, e) => s + e.total, 0);
  const free = labItems.reduce((s, e) => s + e.available, 0);
  const siblings = SUBJECTS.filter((s) => s.dept === dept && s.slug !== subject);

  return (
    <Page>
      <nav aria-label="Breadcrumb" className="mb-4 flex flex-wrap items-center gap-1.5 text-[13px]">
        <Link href="/" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Home</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <Link href="/departments" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Departments</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <Link href={`/departments/${d.key}`} className="font-medium text-navy-600 hover:underline dark:text-navy-200">{d.short}</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <span className="font-semibold text-slate-500 dark:text-slate-400">{lab.name}</span>
      </nav>

      <BackLink href={`/departments/${d.key}`} label={`Back to ${d.short}`} />

      <header className={`${CARD} relative mb-7 overflow-hidden`}>
        <div className="absolute inset-y-0 left-0 w-1.5" style={{ background: `linear-gradient(180deg, hsl(${d.hue} 58% 40%), hsl(${(d.hue + 40) % 360} 62% 55%))` }} />
        <div className="grid gap-6 p-6 pl-8 lg:grid-cols-[1.5fr_1fr]">
          <div>
            <div className="flex flex-wrap items-center gap-2">
              <span className="rounded-md bg-navy-900 px-2 py-1 font-mono text-[11px] font-bold text-white dark:bg-navy-700">{lab.code}</span>
              <span className="rounded-md bg-slate-100 px-2 py-1 text-[11px] font-bold text-slate-600 dark:bg-navy-800 dark:text-slate-300">{d.short}</span>
              <span className="rounded-md bg-slate-100 px-2 py-1 text-[11px] font-semibold text-slate-600 dark:bg-navy-800 dark:text-slate-300">{lab.semester}</span>
              {labItems.length > 0 && <StatusBadge status={free === 0 ? "booked" : free < units ? "partial" : "available"} size="sm" />}
            </div>
            <h1 className="mt-3 font-display text-[26px] font-extrabold leading-tight tracking-tight text-navy-900 sm:text-[32px] dark:text-white">{lab.name}</h1>
            <p className="mt-2.5 max-w-2xl text-[14px] leading-relaxed text-slate-600 dark:text-slate-400">
              {lab.description ?? `${lab.name} is a ${d.short} teaching laboratory (${lab.code}) handled by ${lab.supervisor}. All instruments listed below belong to this laboratory only — booking, issue and return are recorded against this lab's slot.`}
            </p>
            <dl className="mt-4 grid gap-x-6 gap-y-2 text-[13px] sm:grid-cols-2">
              <div className="flex gap-2"><Icon name="pin" className="mt-0.5 h-4 w-4 shrink-0 text-navy-500 dark:text-gold-400" /><span><dt className="inline font-semibold text-slate-500 dark:text-slate-400">Room:</dt> <dd className="inline font-bold text-navy-900 dark:text-white">{lab.room}</dd></span></div>
              <div className="flex gap-2"><Icon name="clock" className="mt-0.5 h-4 w-4 shrink-0 text-navy-500 dark:text-gold-400" /><span><dt className="inline font-semibold text-slate-500 dark:text-slate-400">Lab hours:</dt> <dd className="inline font-bold text-navy-900 dark:text-white">{lab.labHours}</dd></span></div>
              <div className="flex gap-2"><Icon name="user" className="mt-0.5 h-4 w-4 shrink-0 text-navy-500 dark:text-gold-400" /><span><dt className="inline font-semibold text-slate-500 dark:text-slate-400">Supervisor:</dt> <dd className="inline font-bold text-navy-900 dark:text-white">{lab.supervisor}</dd></span></div>
              <div className="flex gap-2"><Icon name="box" className="mt-0.5 h-4 w-4 shrink-0 text-navy-500 dark:text-gold-400" /><span><dt className="inline font-semibold text-slate-500 dark:text-slate-400">Equipment in this lab:</dt> <dd className="inline font-bold text-navy-900 dark:text-white">{equipmentCounts(dept, subject)} types</dd></span></div>
            </dl>
          </div>

          <div className="rounded-2xl bg-slate-50 p-4 dark:bg-navy-950/60">
            <div className="text-[11px] font-bold uppercase tracking-[0.16em] text-slate-500 dark:text-slate-400">This laboratory today</div>
            <div className="mt-2 grid grid-cols-3 gap-2 text-center">
              {[
                ["Units", units, "text-navy-900 dark:text-white"],
                ["Free", free, "text-emerald-600 dark:text-emerald-400"],
                ["Reserved", units - free, "text-amber-600 dark:text-amber-400"],
              ].map(([k, v, cls]) => (
                <div key={String(k)} className="rounded-xl bg-white py-2.5 shadow-sm dark:bg-navy-900">
                  <div className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">{k as string}</div>
                  <div className={`font-display text-xl font-extrabold ${cls as string}`}>{v as number}</div>
                </div>
              ))}
            </div>
            <ul className="mt-3 space-y-1.5">
              {lab.outcomes.map((o) => (
                <li key={o} className="flex items-start gap-1.5 text-[12.5px] text-slate-600 dark:text-slate-300"><Icon name="check" className="mt-0.5 h-3.5 w-3.5 shrink-0 text-emerald-500" /> {o}</li>
              ))}
            </ul>
            <p className="mt-3 flex gap-2 rounded-xl bg-amber-50 p-2.5 text-[12px] text-amber-800 ring-1 ring-amber-200 dark:bg-amber-500/10 dark:text-amber-200 dark:ring-amber-500/30">
              <Icon name="alert" className="mt-0.5 h-4 w-4 shrink-0" /> {lab.safety}
            </p>
          </div>
        </div>
      </header>

      <MaintenanceNotice ids={labItems.map((e) => e.id)} />

      <div className={`${CARD} mb-5 flex flex-wrap items-center gap-3 p-3.5`}>
        <div className="relative min-w-[210px] flex-1">
          <Icon name="search" className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder={`Search inside ${lab.name}…`} aria-label="Search equipment in this laboratory" className="w-full rounded-xl border border-slate-200 bg-slate-50/70 py-2.5 pl-9 pr-3 text-[13.5px] outline-none transition focus:border-navy-400 focus:bg-white dark:border-navy-700 dark:bg-navy-950/60 dark:text-slate-100" />
        </div>
        <div className="flex items-center gap-1 rounded-xl bg-slate-100 p-1 dark:bg-navy-950/60">
          {([["all", "All"], ["free", "Available"], ["maint", "Maintenance"]] as const).map(([k, label]) => (
            <button key={k} onClick={() => setOnly(k)} className={`rounded-lg px-3 py-1.5 text-[12.5px] font-bold transition ${only === k ? "bg-white text-navy-900 shadow-sm dark:bg-navy-700 dark:text-white" : "text-slate-500 hover:text-navy-800 dark:text-slate-400"}`}>
              {label}
            </button>
          ))}
        </div>
        <label className="flex items-center gap-2 text-[12.5px] font-semibold text-slate-500 dark:text-slate-400">
          Sort
          <select value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} className="rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-[12.5px] font-semibold text-navy-900 outline-none dark:border-navy-700 dark:bg-navy-900 dark:text-slate-100">
            <option value="availability">Availability</option>
            <option value="az">Name A–Z</option>
            <option value="recent">Recently added</option>
          </select>
        </label>
        <Link href={`/booking?dept=${dept}&subject=${subject}`} className={btn("gold", "sm")}>
          <Icon name="calendar" className="h-4 w-4" /> Book in this lab
        </Link>
      </div>

      {labItems.length === 0 ? (
        <EmptyState title="No equipment mapped yet" body={`No instruments are attached to ${lab.name} in the catalogue. An administrator can add equipment to this laboratory from the admin dashboard.`} action={<LinkButton href="/admin" size="sm" variant="outline">Open admin dashboard</LinkButton>} />
      ) : (
        <>
          <SectionTitle eyebrow={`${labItems.length} instrument type(s)`} title={`Equipment of ${lab.name}`} sub="Click a photograph to open full details — size, quantity, specifications, uses and usage instructions — then book from there." />
          <EquipmentGrid items={labItems} />
        </>
      )}

      <div className="mt-10">
        <SectionTitle eyebrow="Continue" title={`Other laboratories in ${d.short}`} />
        <div className="flex flex-wrap gap-2">
          {siblings.map((s) => (
            <Link key={s.slug} href={`/departments/${d.key}/${s.slug}`} className={`${CARD} group flex items-center gap-2.5 px-3.5 py-2.5 text-[13px] font-bold text-navy-800 transition hover:-translate-y-0.5 hover:shadow-[var(--shadow-lift)] dark:text-slate-200`}>
              <Icon name="building" className="h-4 w-4 text-navy-500 dark:text-gold-400" />
              {s.name}
              <span className="rounded bg-slate-100 px-1.5 py-0.5 text-[10.5px] text-slate-500 group-hover:bg-navy-100 dark:bg-navy-800 dark:text-slate-400">{equipmentCounts(dept, s.slug)}</span>
            </Link>
          ))}
        </div>
      </div>
    </Page>
  );
}
