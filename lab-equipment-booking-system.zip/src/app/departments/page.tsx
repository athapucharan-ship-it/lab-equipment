"use client";

import Link from "next/link";
import { useMemo } from "react";
import { Page } from "@/components/chrome";
import { CARD, Icon, LinkButton, LoadingBlock, SectionTitle, StatCard, btn } from "@/components/ui";
import { DEPARTMENTS, SEED_EQUIPMENT, SUBJECTS, equipmentCounts, statsFor } from "@/lib/data";
import { useLabbook } from "@/lib/store";

export default function DepartmentsPage() {
  const { items, ready } = useLabbook();
  const stats = useMemo(() => statsFor(items), [items]);

  if (!ready) return <Page><LoadingBlock label="Loading departments and laboratories…" /></Page>;

  return (
    <Page>
      <nav aria-label="Breadcrumb" className="mb-5 text-[13px]">
        <Link href="/" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Home</Link>
        <span className="mx-1.5 text-slate-400">›</span>
        <span className="font-semibold text-slate-500 dark:text-slate-400">Departments</span>
      </nav>

      <header className="mb-8 flex flex-wrap items-end justify-between gap-5">
        <div className="max-w-2xl">
          <div className="mb-2 text-[11px] font-bold uppercase tracking-[0.2em] text-navy-500 dark:text-gold-400">Step 1 of the navigation flow</div>
          <h1 className="font-display text-[30px] font-extrabold leading-tight tracking-tight text-navy-900 sm:text-[38px] dark:text-white">Departments &amp; their laboratories</h1>
          <p className="mt-3 text-[14.5px] leading-relaxed text-slate-600 dark:text-slate-400">
            Choose a department to see only its laboratory subjects. Choose a laboratory to see only the equipment that belongs to it — the catalogue is never shown as one long list.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <LinkButton href="/equipment" variant="outline" size="sm"><Icon name="search" className="h-4 w-4" /> Search all equipment</LinkButton>
          <LinkButton href="/booking" variant="gold" size="sm"><Icon name="plus" className="h-4 w-4" /> Book directly</LinkButton>
        </div>
      </header>

      <div className="mb-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatCard label="Total Departments" value={DEPARTMENTS.length} hint="8 including central facilities" icon="layers" tone="navy" />
        <StatCard label="Total Laboratories" value={SUBJECTS.length} hint="subject-wise labs" icon="building" tone="violet" />
        <StatCard label="Equipment Types" value={SEED_EQUIPMENT.length} hint={`${stats.units} bookable units`} icon="box" tone="sky" />
        <StatCard label="Free Right Now" value={stats.available + stats.partial} hint={`${stats.availableUnits} units unreserved`} icon="check" tone="emerald" />
      </div>

      <div className="grid gap-5 lg:grid-cols-2">
        {DEPARTMENTS.map((d, idx) => {
          const labs = SUBJECTS.filter((s) => s.dept === d.key);
          const scoped = items.filter((e) => e.dept === d.key);
          const units = scoped.reduce((s, e) => s + e.total, 0);
          const free = scoped.reduce((s, e) => s + e.available, 0);
          const maint = scoped.filter((e) => e.availability === "maintenance").length;
          return (
            <article key={d.key} className="lb-fade-up" style={{ animationDelay: `${idx * 45}ms` }}>
              <div className={`${CARD} flex h-full flex-col overflow-hidden`}>
                <div className="relative flex items-start gap-4 p-5" style={{ background: `linear-gradient(135deg, hsl(${d.hue} 55% 96%), transparent 70%)` }}>
                  <span className="grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white shadow-md" style={{ background: `linear-gradient(140deg, hsl(${d.hue} 58% 34%), hsl(${d.hue + 26} 62% 48%))` }}>
                    <svg viewBox="0 0 24 24" className="h-6 w-6" fill="none" stroke="currentColor" strokeWidth={1.7} strokeLinecap="round" strokeLinejoin="round"><path d={d.icon} /></svg>
                  </span>
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <h2 className="font-display text-[18px] font-extrabold leading-tight text-navy-900 dark:text-white">{d.name}</h2>
                      <span className="rounded-md bg-navy-900 px-1.5 py-0.5 text-[10px] font-bold text-white dark:bg-navy-700">{d.short}</span>
                    </div>
                    <p className="mt-1 text-[12.5px] font-medium text-slate-500 dark:text-slate-400">{d.tagline}</p>
                  </div>
                </div>

                <div className="flex flex-1 flex-col px-5 pb-5">
                  <p className="text-[13.5px] leading-relaxed text-slate-600 dark:text-slate-400">{d.description}</p>

                  <dl className="mt-4 grid grid-cols-2 gap-2 sm:grid-cols-4">
                    {[
                      ["Labs", String(labs.length)],
                      ["Equipment", String(equipmentCounts(d.key))],
                      ["Units", String(units)],
                      ["Free units", String(free)],
                    ].map(([k, v]) => (
                      <div key={k} className="rounded-xl bg-slate-50 px-2.5 py-2 dark:bg-navy-950/60">
                        <dt className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">{k}</dt>
                        <dd className="font-display text-[17px] font-extrabold text-navy-900 dark:text-white">{v}</dd>
                      </div>
                    ))}
                  </dl>

                  <ul className="mt-4 grid gap-1.5 sm:grid-cols-2">
                    {labs.map((s) => {
                      const count = equipmentCounts(d.key, s.slug);
                      return (
                        <li key={s.slug}>
                          <Link href={`/departments/${d.key}/${s.slug}`} className="group flex items-center gap-2 rounded-xl border border-slate-200 px-2.5 py-2 transition hover:border-navy-400 hover:bg-navy-50/60 dark:border-navy-700 dark:hover:bg-navy-800">
                            <Icon name="box" className="h-4 w-4 shrink-0 text-navy-500 dark:text-gold-400" />
                            <span className="min-w-0 flex-1 truncate text-[13px] font-semibold text-navy-900 dark:text-slate-100">{s.name}</span>
                            <span className="shrink-0 rounded bg-white px-1.5 py-0.5 text-[10.5px] font-bold text-slate-500 ring-1 ring-slate-200 group-hover:ring-navy-300 dark:bg-navy-900 dark:text-slate-400 dark:ring-navy-700">{count}</span>
                          </Link>
                        </li>
                      );
                    })}
                  </ul>

                  <div className="mt-4 flex flex-wrap items-center gap-2 border-t border-slate-100 pt-3 dark:border-navy-800">
                    <span className="text-[11.5px] text-slate-500 dark:text-slate-400">{d.building} · {d.floor}</span>
                    {maint > 0 && <span className="inline-flex items-center gap-1 rounded-full bg-sky-50 px-2 py-0.5 text-[11px] font-bold text-sky-700 ring-1 ring-sky-200 dark:bg-sky-500/10 dark:text-sky-300 dark:ring-sky-500/30"><Icon name="wrench" className="h-3 w-3" /> {maint} under maintenance</span>}
                    <Link href={`/departments/${d.key}`} className={`${btn("primary", "sm")} ml-auto`}>
                      View Department <Icon name="arrowRight" className="h-3.5 w-3.5" />
                    </Link>
                  </div>
                </div>
              </div>
            </article>
          );
        })}
      </div>

      <div className={`${CARD} mt-8 p-6`}>
        <SectionTitle eyebrow="Directory" title="All laboratories in one place" sub="28 subject laboratories across the departments — pick any to open its own equipment list." />
        <div className="grid gap-x-8 gap-y-1 md:grid-cols-2">
          {DEPARTMENTS.map((d) => (
            <div key={d.key} className="mb-3">
              <h3 className="mb-1.5 text-[11px] font-bold uppercase tracking-[0.16em] text-slate-500 dark:text-slate-400">{d.short}</h3>
              {SUBJECTS.filter((s) => s.dept === d.key).map((s) => (
                <Link key={s.slug} href={`/departments/${d.key}/${s.slug}`} className="flex items-center justify-between gap-3 border-b border-dashed border-slate-200 py-1.5 text-[13.5px] last:border-0 dark:border-navy-800">
                  <span className="font-medium text-navy-800 hover:underline dark:text-slate-200">{s.name}</span>
                  <span className="shrink-0 text-[11.5px] text-slate-400">{s.code} · {equipmentCounts(d.key, s.slug)} assets</span>
                </Link>
              ))}
            </div>
          ))}
        </div>
      </div>
    </Page>
  );
}
