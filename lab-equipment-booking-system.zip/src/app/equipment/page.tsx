"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useMemo, useState } from "react";
import { Page } from "@/components/chrome";
import { EquipmentGrid } from "@/components/equipment";
import { StatusLegend } from "@/components/extras";
import { CARD, Icon, LinkButton, LoadingBlock, btn } from "@/components/ui";
import { CATEGORIES, DEPARTMENTS, SUBJECTS, searchEquipment, type Availability } from "@/lib/data";
import { useLabbook } from "@/lib/store";

const PER_PAGE = 9;

export default function EquipmentCatalogPage() {
  const { items, ready, equipment, bookings } = useLabbook();
  const router = useRouter();
  const [q, setQ] = useState("");
  const [dept, setDept] = useState("all");
  const [subject, setSubject] = useState("all");
  const [category, setCategory] = useState("all");
  const [availability, setAvailability] = useState<"all" | "available" | "maintenance">("all");
  const [sort, setSort] = useState<"availability" | "az" | "recent">("availability");
  const [date, setDate] = useState("");
  const [page, setPage] = useState(1);
  const [hydrated, setHydrated] = useState(false);

  /* hydrate filters from the URL (?q=&dept=&subject=&availability=&date=) */
  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    setQ(p.get("q") ?? "");
    setSubject(p.get("subject") ?? "all");
    setDept(p.get("dept") ?? "all");
    setSubject(p.get("subject") ?? "all");
    setCategory(p.get("category") ?? "all");
    setAvailability(((p.get("availability") ?? "all") as typeof availability) || "all");
    setSort((p.get("sort") as typeof sort) ?? "availability");
    setDate(p.get("date") ?? "");
    setHydrated(true);
  }, []);

  /* keep the URL in sync so filtered views can be shared / bookmarked */
  useEffect(() => {
    if (!hydrated) return;
    const p = new URLSearchParams();
    if (q) p.set("q", q);
    if (dept !== "all") p.set("dept", dept);
    if (subject !== "all") p.set("subject", subject);
    if (category !== "all") p.set("category", category);
    if (availability !== "all") p.set("availability", availability);
    if (sort !== "availability") p.set("sort", sort);
    if (date) p.set("date", date);
    const qs = p.toString();
    router.replace(`/equipment${qs ? `?${qs}` : ""}`, { scroll: false });
  }, [q, dept, subject, category, availability, sort, date, hydrated, router]);

  const scopedItems = useMemo(() => (date ? items : items), [items, date]);
  const results = useMemo(
    () =>
      searchEquipment(scopedItems, { query: q, dept, subject, category, availability, sort }),
    [scopedItems, q, dept, subject, category, availability, sort],
  );
  const labs = dept === "all" ? SUBJECTS : SUBJECTS.filter((s) => s.dept === dept);
  const visible = results.slice(0, page * PER_PAGE);
  const activeFilters = [dept !== "all", subject !== "all", category !== "all", availability !== "all", !!q, !!date].filter(Boolean).length;

  if (!ready || !hydrated) return <Page><LoadingBlock label="Loading the equipment catalogue…" /></Page>;

  const clear = () => {
    setQ("");
    setDept("all");
    setSubject("all");
    setCategory("all");
    setAvailability("all");
    setSort("availability");
    setDate("");
    setPage(1);
  };

  return (
    <Page>
      <nav aria-label="Breadcrumb" className="mb-4 flex flex-wrap items-center gap-1.5 text-[13px]">
        <Link href="/" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Home</Link>
        <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
        <span className="font-semibold text-slate-500 dark:text-slate-400">Equipment catalogue</span>
      </nav>

      <header className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div className="max-w-2xl">
          <div className="mb-1.5 text-[11px] font-bold uppercase tracking-[0.2em] text-navy-500 dark:text-gold-400">Search · filter · sort</div>
          <h1 className="font-display text-[28px] font-extrabold leading-tight tracking-tight text-navy-900 sm:text-[34px] dark:text-white">Equipment catalogue</h1>
          <p className="mt-2 text-[13.5px] leading-relaxed text-slate-600 dark:text-slate-400">
            Prefer browsing lab by lab? Use <Link href="/departments" className="font-semibold text-navy-700 underline decoration-gold-400 dark:text-gold-300">Departments → Subject laboratory → Equipment</Link>. This view is for searching across the whole college.
          </p>
        </div>
        <LinkButton href="/booking" variant="gold" size="sm"><Icon name="plus" className="h-4 w-4" /> New booking</LinkButton>
      </header>

      {/* ------------------------------ filter panel ------------------------------ */}
      <section className={`${CARD} mb-6 p-4`}>
        <div className="grid gap-3 lg:grid-cols-[1.4fr_repeat(4,1fr)]">
          <label className="block">
            <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500 dark:text-slate-400">Search</span>
            <span className="relative block">
              <Icon name="search" className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-slate-400" />
              <input
                value={q}
                onChange={(e) => { setQ(e.target.value); setPage(1); }}
                placeholder="Name, ID, manufacturer, model, lab…"
                aria-label="Search by equipment name, ID, department, subject, laboratory or manufacturer"
                className="w-full rounded-xl border border-slate-200 bg-slate-50/70 py-2.5 pl-9 pr-3 text-[13.5px] outline-none transition focus:border-navy-400 focus:bg-white dark:border-navy-700 dark:bg-navy-950/60 dark:text-slate-100"
              />
            </span>
          </label>

          <label className="block">
            <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500 dark:text-slate-400">Department</span>
            <select value={dept} onChange={(e) => { setDept(e.target.value); setSubject("all"); setPage(1); }} className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-[13.5px] font-medium outline-none focus:border-navy-400 dark:border-navy-700 dark:bg-navy-950/60 dark:text-slate-100">
              <option value="all">All departments</option>
              {DEPARTMENTS.map((d) => <option key={d.key} value={d.key}>{d.short} — {d.name}</option>)}
            </select>
          </label>

          <label className="block">
            <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500 dark:text-slate-400">Subject / Laboratory</span>
            <select value={subject} onChange={(e) => { setSubject(e.target.value); setPage(1); }} className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-[13.5px] font-medium outline-none focus:border-navy-400 dark:border-navy-700 dark:bg-navy-950/60 dark:text-slate-100">
              <option value="all">{dept === "all" ? "All laboratories" : `All labs in ${DEPARTMENTS.find((d) => d.key === dept)?.short ?? ""}`}</option>
              {labs.map((s) => <option key={s.slug} value={s.slug}>{s.name}</option>)}
            </select>
          </label>

          <label className="block">
            <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500 dark:text-slate-400">Category</span>
            <select value={category} onChange={(e) => { setCategory(e.target.value); setPage(1); }} className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-[13.5px] font-medium outline-none focus:border-navy-400 dark:border-navy-700 dark:bg-navy-950/60 dark:text-slate-100">
              <option value="all">All categories</option>
              {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </label>

          <label className="block">
            <span className="mb-1.5 block text-[11px] font-semibold uppercase tracking-[0.14em] text-slate-500 dark:text-slate-400">Availability</span>
            <select value={availability} onChange={(e) => { setAvailability(e.target.value as typeof availability); setPage(1); }} className="w-full rounded-xl border border-slate-200 bg-white px-3 py-2.5 text-[13.5px] font-medium outline-none focus:border-navy-400 dark:border-navy-700 dark:bg-navy-950/60 dark:text-slate-100">
              <option value="all">Any status</option>
              <option value="available">Free units only</option>
              <option value="maintenance">Under maintenance</option>
            </select>
          </label>
        </div>

        <div className="mt-3 flex flex-wrap items-center gap-3 border-t border-slate-100 pt-3 dark:border-navy-800">
          <label className="flex items-center gap-2 text-[12.5px] font-semibold text-slate-500 dark:text-slate-400">
            <Icon name="calendar" className="h-4 w-4" />
            Availability for date
            <input type="date" value={date} onChange={(e) => { setDate(e.target.value); setPage(1); }} className="rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-[12.5px] font-medium outline-none focus:border-navy-400 dark:border-navy-700 dark:bg-navy-900 dark:text-slate-100" />
          </label>
          <label className="flex items-center gap-2 text-[12.5px] font-semibold text-slate-500 dark:text-slate-400">
            Sort
            <select value={sort} onChange={(e) => setSort(e.target.value as typeof sort)} className="rounded-lg border border-slate-200 bg-white px-2 py-1.5 text-[12.5px] font-medium outline-none focus:border-navy-400 dark:border-navy-700 dark:bg-navy-900 dark:text-slate-100">
              <option value="availability">By availability</option>
              <option value="az">Name A – Z</option>
              <option value="recent">Recently added</option>
            </select>
          </label>
          <span className="rounded-lg bg-slate-100 px-2.5 py-1 text-[12px] font-bold text-slate-600 dark:bg-navy-800 dark:text-slate-300">{results.length} result(s)</span>
          {date && <span className="rounded-lg bg-navy-50 px-2.5 py-1 text-[12px] font-semibold text-navy-700 dark:bg-navy-800 dark:text-navy-200">counts shown for {date}</span>}
          {activeFilters > 0 && (
            <button onClick={clear} className={btn("ghost", "sm")}>
              <Icon name="close" className="h-3.5 w-3.5" /> Clear {activeFilters} filter(s)
            </button>
          )}
          <StatusLegend className="ml-auto" />
        </div>
      </section>

      {results.length === 0 ? (
        <div className={`${CARD} flex flex-col items-center gap-3 px-6 py-16 text-center`}>
          <span className="grid h-12 w-12 place-items-center rounded-2xl bg-slate-100 text-slate-500 dark:bg-navy-800"><Icon name="search" className="h-6 w-6" /></span>
          <h2 className="font-display text-lg font-bold text-navy-900 dark:text-white">Nothing matches those filters</h2>
          <p className="max-w-md text-sm text-slate-600 dark:text-slate-400">Try a broader search term such as “oscilloscope”, “lathe”, “total station” or an equipment ID like ECE-DE-001.</p>
          <button onClick={clear} className={`${btn("primary", "sm")} mt-1`}>Reset filters</button>
        </div>
      ) : (
        <>
          <EquipmentGrid items={visible} />
          {visible.length < results.length && (
            <div className="mt-7 flex flex-col items-center gap-2">
              <p className="text-[12.5px] text-slate-500 dark:text-slate-400">Showing {visible.length} of {results.length} matching equipment</p>
              <button onClick={() => setPage((p) => p + 1)} className={btn("outline", "sm")}>
                <Icon name="plus" className="h-4 w-4" /> Load {Math.min(PER_PAGE, results.length - visible.length)} more
              </button>
            </div>
          )}
        </>
      )}

      <section className={`${CARD} mt-10 p-5`}>
        <h2 className="font-display text-base font-bold text-navy-900 dark:text-white">Jump straight into a laboratory</h2>
        <p className="mt-1 text-[13px] text-slate-600 dark:text-slate-400">{SUBJECTS.length} laboratories · {items.length} equipment types · grouped exactly as the department publishes them.</p>
        <div className="mt-3 flex flex-wrap gap-2">
          {SUBJECTS.map((s) => (
            <Link key={`${s.dept}-${s.slug}`} href={`/departments/${s.dept}/${s.slug}`} className="rounded-full border border-slate-200 px-3 py-1.5 text-[12.5px] font-semibold text-navy-800 transition hover:border-navy-400 hover:bg-navy-50 dark:border-navy-700 dark:text-slate-200 dark:hover:bg-navy-800">
              {s.name}
            </Link>
          ))}
        </div>
      </section>
    </Page>
  );
}
