"use client";

import Link from "next/link";
import { use, useEffect, useMemo, useState } from "react";
import { BackLink, Page } from "@/components/chrome";
import { EquipmentGrid, PhotoImage } from "@/components/equipment";
import { CARD, Chip, EmptyState, Icon, KeyValue, LinkButton, LoadingBlock, SectionTitle, StatusBadge, btn } from "@/components/ui";
import { LICENSE_NOTE, photoCredit, type PhotoKey } from "@/lib/images";
import { formatDate, timeToMinutes } from "@/lib/data";
import { useLabbook } from "@/lib/store";

export default function EquipmentDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = use(params);
  const decoded = decodeURIComponent(id);
  const { byId, items, ready, bookings, photoFor, viewEquipment, toggleFavorite, favorites, toggleCompare, compare } = useLabbook();
  const [active, setActive] = useState(0);

  const eq = byId(decoded);
  const gallery: PhotoKey[] = useMemo(() => (eq ? [eq.photo, ...(eq.gallery ?? [])] : []), [eq]);

  useEffect(() => {
    if (eq) viewEquipment(eq.id);
    // record a view once per asset
  }, [eq?.id]); // eslint-disable-line react-hooks/exhaustive-deps

  const schedule = useMemo(
    () =>
      eq
        ? bookings
            .filter((b) => b.equipmentId === eq.id && b.status !== "Cancelled" && b.status !== "Rejected")
            .sort((a, b) => (a.date + a.startTime).localeCompare(b.date + b.startTime))
            .slice(0, 6)
        : [],
    [bookings, eq],
  );

  if (!ready) return <Page><LoadingBlock label="Loading equipment details…" /></Page>;

  if (!eq) {
    return (
      <Page>
        <EmptyState
          title="Equipment not found"
          body={`No asset with ID “${decoded}” exists in the catalogue. It may have been removed by the laboratory administrator.`}
          action={<LinkButton href="/equipment" size="sm">Back to equipment list</LinkButton>}
        />
      </Page>
    );
  }

  const index = Math.min(active, gallery.length - 1);
  const photo = photoFor(gallery[index] ?? eq.photo);
  const credit = photoCredit(gallery[index] ?? eq.photo);
  const blocked = eq.availability === "maintenance" || eq.available === 0;
  const fav = favorites.includes(eq.id);
  const cmp = compare.includes(eq.id);
  const siblings = items.filter((e) => e.dept === eq.dept && e.subject === eq.subject && e.id !== eq.id);

  return (
    <>
      <Page>
        <nav aria-label="Breadcrumb" className="mb-4 flex flex-wrap items-center gap-1.5 text-[13px]">
          <Link href="/" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Home</Link>
          <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
          <Link href="/departments" className="font-medium text-navy-600 hover:underline dark:text-navy-200">Departments</Link>
          <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
          <Link href={`/departments/${eq.dept}`} className="font-medium text-navy-600 hover:underline dark:text-navy-200">{eq.deptShort}</Link>
          <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
          <Link href={`/departments/${eq.dept}/${eq.subject}`} className="font-medium text-navy-600 hover:underline dark:text-navy-200">{eq.subjectName}</Link>
          <Icon name="chevronRight" className="h-3.5 w-3.5 text-slate-400" />
          <span className="font-semibold text-slate-500 dark:text-slate-400">{eq.id}</span>
        </nav>

        <BackLink href={`/departments/${eq.dept}/${eq.subject}`} label={`Back to ${eq.subjectName}`} />

        <div className="grid gap-7 lg:grid-cols-[minmax(0,1.05fr)_minmax(0,1fr)]">
          {/* ------------------------------ gallery ------------------------------ */}
          <div>
            <div className={`${CARD} overflow-hidden`}>
              <div className="relative bg-navy-950">
                {/* the photograph itself opens a full-size view */}
                <a
                  href={photo.src}
                  target="_blank"
                  rel="noreferrer noopener"
                  className="group relative block aspect-[3/2] w-full"
                  title="Open the full-resolution photograph in a new tab"
                >
                  <PhotoImage photo={gallery[index] ?? eq.photo} label={eq.name} className="h-full w-full" width={1400} height={933} />
                  <span className="pointer-events-none absolute inset-0 bg-gradient-to-t from-navy-950/70 via-transparent to-transparent" />
                  <span className="absolute right-3 top-3 grid h-9 w-9 place-items-center rounded-xl bg-navy-950/70 text-white opacity-0 backdrop-blur transition group-hover:opacity-100">
                    <Icon name="eye" className="h-4.5 w-4.5" />
                  </span>
                  <span className="absolute bottom-3 left-3 flex flex-wrap items-center gap-2">
                    <StatusBadge status={eq.availability} />
                    <span className="rounded-lg bg-white/92 px-2 py-1 font-mono text-[11px] font-bold text-navy-800 dark:bg-navy-900/90 dark:text-gold-300">{eq.id}</span>
                  </span>
                </a>
              </div>

              {gallery.length > 1 && (
                <div className="lb-scroll-x flex gap-2 overflow-x-auto border-t border-slate-100 p-3 dark:border-navy-800">
                  {gallery.map((g, i) => (
                    <button
                      key={`${g}-${i}`}
                      onClick={() => setActive(i)}
                      aria-label={`Show photograph ${i + 1} of ${gallery.length}`}
                      className={`relative h-16 w-24 shrink-0 overflow-hidden rounded-lg ring-2 transition ${i === index ? "ring-navy-600 dark:ring-gold-400" : "ring-transparent hover:ring-navy-300"}`}
                    >
                      <PhotoImage photo={g} label={`${eq.name} view ${i + 1}`} className="h-full w-full" width={240} height={160} />
                    </button>
                  ))}
                </div>
              )}

              <div className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-100 px-4 py-3 text-[11.5px] dark:border-navy-800">
                <p className="flex flex-wrap items-center gap-1.5 text-slate-500 dark:text-slate-400">
                  <Icon name="info" className="h-3.5 w-3.5" />
                  <span>Image source / credit:</span>
                  <a href={credit.photoUrl} target="_blank" rel="noreferrer noopener" className="font-semibold text-navy-700 underline decoration-gold-400 hover:text-navy-900 dark:text-gold-300">
                    {photo.credit} · Pexels photo page
                  </a>
                  <a href={credit.authorUrl} target="_blank" rel="noreferrer noopener" className="font-medium text-navy-600 hover:underline dark:text-slate-300">
                    photographer profile
                  </a>
                </p>
                <p className="text-slate-400">{LICENSE_NOTE}</p>
              </div>
            </div>

            {/* quick facts under the photo */}
            <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4">
              {[
                { k: "Total quantity", v: eq.total, tone: "navy" },
                { k: "Available now", v: eq.available, tone: "emerald" },
                { k: "Reserved", v: eq.reserved, tone: "amber" },
                { k: "Under maintenance", v: eq.availability === "maintenance" ? "Yes" : "No", tone: "sky" },
              ].map((s) => (
                <div key={s.k} className={`${CARD} p-3 text-center`}>
                  <div className="text-[9.5px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">{s.k}</div>
                  <div className={`mt-1 font-display text-2xl font-extrabold ${s.tone === "emerald" ? "text-emerald-600 dark:text-emerald-400" : s.tone === "amber" ? "text-amber-600 dark:text-amber-400" : "text-navy-900 dark:text-white"}`}>{s.v}</div>
                </div>
              ))}
            </div>

            {/* size & quantity */}
            <div className={`${CARD} mt-4 p-5`}>
              <h2 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white">
                <Icon name="ruler" className="h-4.5 w-4.5 text-navy-500 dark:text-gold-400" /> Size, weight &amp; quantity
              </h2>
              <div className="mt-3">
                <KeyValue k="Physical size / footprint" v={eq.size.footprint} />
                <KeyValue k="Weight" v={eq.size.weight} />
                {eq.size.bench && <KeyValue k="Bench / mounting requirement" v={eq.size.bench} />}
                {eq.size.power && <KeyValue k="Power requirement" v={eq.size.power} />}
                <KeyValue k="Total quantity in this laboratory" v={<span>{eq.total} unit(s)</span>} />
                <KeyValue k="Currently free" v={<span className="text-emerald-600 dark:text-emerald-400">{eq.available} of {eq.total} unit(s)</span>} />
                <KeyValue k="Booked / reserved" v={`${eq.reserved} unit(s)`} />
                {eq.location && <KeyValue k="Stored at" v={eq.location} />}
              </div>
              <p className="mt-3 flex gap-2 rounded-xl bg-navy-50 p-3 text-[12.5px] leading-relaxed text-navy-800 dark:bg-navy-950/60 dark:text-slate-300">
                <Icon name="info" className="mt-0.5 h-4 w-4 shrink-0 text-navy-500 dark:text-gold-400" />
                Availability is per date: the free count changes when you pick a booking date, because each reservation holds its units only for that day and time window.
              </p>
            </div>
          </div>

          {/* ------------------------------ details ------------------------------ */}
          <div>
            <div className={`${CARD} p-5`}>
              <div className="flex flex-wrap items-center gap-1.5">
                <Chip className="!bg-navy-900 !text-white !ring-navy-900 dark:!bg-gold-400 dark:!text-navy-950 dark:!ring-gold-400">{eq.deptShort}</Chip>
                <Chip>{eq.category}</Chip>
                <Chip>{eq.subjectName}</Chip>
              </div>
              <h1 className="mt-3 font-display text-[24px] font-extrabold leading-tight tracking-tight text-navy-900 sm:text-[28px] dark:text-white">{eq.name}</h1>
              <p className="mt-2 text-[14px] leading-relaxed text-slate-600 dark:text-slate-400">{eq.short}</p>

              <div className="mt-4 grid gap-x-6 sm:grid-cols-2">
                <KeyValue k="Equipment ID" v={<span className="font-mono">{eq.id}</span>} />
                <KeyValue k="Department" v={eq.deptName} />
                <KeyValue k="Laboratory / Subject" v={<Link href={`/departments/${eq.dept}/${eq.subject}`} className="text-navy-700 underline decoration-gold-400 hover:text-navy-900 dark:text-gold-300">{eq.subjectName}</Link>} />
                <KeyValue k="Status" v={<StatusBadge status={eq.availability} size="sm" />} />
                <KeyValue k="Manufacturer" v={eq.manufacturer} />
                <KeyValue k="Model number" v={<span className="font-mono text-[12.5px]">{eq.model}</span>} />
                <KeyValue k="Quantity / available" v={`${eq.total} / ${eq.available}`} />
                <KeyValue k="Added to catalogue" v={formatDate(eq.addedOn)} />
                {eq.calibrationDue && <KeyValue k="Calibration / service" v={eq.calibrationDue} />}
                {eq.location && <KeyValue k="Location" v={eq.location} />}
              </div>

              <div className="mt-5 flex flex-wrap gap-2">
                <Link href={`/booking/${encodeURIComponent(eq.id)}`} className={`${btn(blocked ? "subtle" : "gold", "lg")} flex-1`}>
                  <Icon name="calendar" className="h-4.5 w-4.5" /> {blocked ? "Booking blocked" : "Book Equipment"}
                </Link>
                <button onClick={() => toggleFavorite(eq.id)} className={`${btn("outline", "lg")} ${fav ? "!border-rose-300 !text-rose-600 dark:!border-rose-500/40" : ""}`} title="Add to favourites" aria-label="Toggle favourite">
                  <Icon name="heart" className="h-4.5 w-4.5" />
                </button>
                <button onClick={() => toggleCompare(eq.id)} className={`${btn("outline", "lg")} ${cmp ? "!border-navy-500 !text-navy-900 dark:!text-white" : ""}`} title="Add to comparison" aria-label="Toggle compare">
                  <Icon name="compare" className="h-4.5 w-4.5" />
                </button>
              </div>
              {blocked && (
                <p className="mt-2.5 flex gap-2 rounded-xl bg-rose-50 p-3 text-[12.5px] font-medium text-rose-700 ring-1 ring-rose-200 dark:bg-rose-500/10 dark:text-rose-300 dark:ring-rose-500/30">
                  <Icon name="alert" className="mt-0.5 h-4 w-4 shrink-0" />
                  {eq.availability === "maintenance"
                    ? "This instrument is under maintenance — booking is disabled until the technical staff marks it serviceable again."
                    : `All ${eq.total} unit(s) are already reserved for today. Pick another date in the booking form.`}
                </p>
              )}
            </div>

            {/* purpose + uses */}
            <div className={`${CARD} mt-4 p-5`}>
              <h2 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white">
                <Icon name="sparkle" className="h-4.5 w-4.5 text-navy-500 dark:text-gold-400" /> Purpose of this equipment
              </h2>
              <p className="mt-2 text-[13.5px] leading-relaxed text-slate-600 dark:text-slate-400">{eq.purpose}</p>

              <h3 className="mt-4 text-[11px] font-bold uppercase tracking-[0.16em] text-slate-500 dark:text-slate-400">Uses</h3>
              <ul className="mt-2 grid gap-2">
                {eq.uses.map((u) => (
                  <li key={u} className="flex gap-2.5 rounded-xl bg-slate-50 p-3 text-[13px] font-medium text-navy-900 dark:bg-navy-950/60 dark:text-slate-200">
                    <span className="mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-md bg-emerald-500/15 text-emerald-600 dark:text-emerald-400">
                      <Icon name="check" className="h-3.5 w-3.5" strokeWidth={2.4} />
                    </span>
                    {u}
                  </li>
                ))}
              </ul>
            </div>

            {/* specifications */}
            <div className={`${CARD} mt-4 overflow-hidden`}>
              <div className="flex items-center justify-between gap-3 border-b border-slate-100 px-5 py-3.5 dark:border-navy-800">
                <h2 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white">
                  <Icon name="grid" className="h-4.5 w-4.5 text-navy-500 dark:text-gold-400" /> Technical specifications
                </h2>
                <span className="text-[11px] uppercase tracking-wider text-slate-400">{eq.specs.length} entries</span>
              </div>
              <table className="w-full text-[13px]">
                <tbody>
                  {eq.specs.map(([k, v], i) => (
                    <tr key={k} className={i % 2 ? "bg-slate-50/70 dark:bg-navy-950/40" : ""}>
                      <th scope="row" className="w-[38%] px-5 py-2.5 text-left align-top font-semibold text-slate-500 dark:text-slate-400">{k}</th>
                      <td className="px-5 py-2.5 align-top font-medium text-navy-900 dark:text-slate-100">{v}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* instructions */}
            <div className={`${CARD} mt-4 p-5`}>
              <h2 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white">
                <Icon name="book" className="h-4.5 w-4.5 text-navy-500 dark:text-gold-400" /> Usage instructions (SOP)
              </h2>
              <ol className="mt-3 space-y-2.5">
                {eq.instructions.map((step, i) => (
                  <li key={step} className="flex gap-3 text-[13.5px] leading-relaxed text-slate-600 dark:text-slate-300">
                    <span className="grid h-6 w-6 shrink-0 place-items-center rounded-lg bg-navy-800 font-mono text-[11px] font-bold text-white dark:bg-navy-700">{i + 1}</span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
              {eq.safety && (
                <p className="mt-4 flex gap-2 rounded-xl bg-amber-50 p-3 text-[12.5px] font-medium leading-relaxed text-amber-900 ring-1 ring-amber-200 dark:bg-amber-500/10 dark:text-amber-200 dark:ring-amber-500/30">
                  <Icon name="shield" className="mt-0.5 h-4 w-4 shrink-0" /> <span><strong>Safety:</strong> {eq.safety}</span>
                </p>
              )}
            </div>

            {/* live schedule */}
            <div className={`${CARD} mt-4 p-5`}>
              <div className="flex items-center justify-between gap-3">
                <h2 className="flex items-center gap-2 font-display text-base font-bold text-navy-900 dark:text-white">
                  <Icon name="clock" className="h-4.5 w-4.5 text-navy-500 dark:text-gold-400" /> Current bookings &amp; schedule
                </h2>
                <Link href={`/booking/${encodeURIComponent(eq.id)}`} className={btn("outline", "sm")}>Check a date</Link>
              </div>
              {schedule.length === 0 ? (
                <p className="mt-3 rounded-xl bg-emerald-50 p-3 text-[13px] font-semibold text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300">
                  No reservations on record for this asset — all {eq.total} unit(s) are free for a standard lab slot (09:00–17:00).
                </p>
              ) : (
                <ul className="mt-3 space-y-2">
                  {schedule.map((b) => (
                    <li key={b.bookingId} className="flex flex-wrap items-center gap-2 rounded-xl border border-slate-200 px-3 py-2.5 text-[12.5px] dark:border-navy-700">
                      <span className="font-mono text-[11px] font-bold text-navy-700 dark:text-gold-300">{b.bookingId}</span>
                      <span className="font-semibold text-navy-900 dark:text-white">{b.uid}</span>
                      <span className="text-slate-500 dark:text-slate-400">{formatDate(b.date)} · {b.startTime}–{b.endTime}</span>
                      <span className="ml-auto rounded-full bg-slate-100 px-2 py-0.5 text-[11px] font-bold text-slate-600 dark:bg-navy-800 dark:text-slate-300">{b.quantity} unit(s)</span>
                      <span className={`rounded-full px-2 py-0.5 text-[10.5px] font-bold ${b.status === "Active" ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300" : "bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300"}`}>{b.status}</span>
                    </li>
                  ))}
                </ul>
              )}
            </div>
          </div>
        </div>

        {siblings.length > 0 && (
          <div className="mt-12">
            <SectionTitle eyebrow="Same laboratory" title={`More equipment in ${eq.subjectName}`} sub="Everything below belongs to the same department and subject laboratory." />
            <EquipmentGrid items={siblings.slice(0, 3)} />
            <div className="mt-5 flex flex-wrap gap-2">
              <LinkButton href={`/departments/${eq.dept}/${eq.subject}`} variant="outline" size="sm">
                <Icon name="back" className="h-4 w-4" /> Full laboratory list
              </LinkButton>
              <LinkButton href={`/departments/${eq.dept}`} variant="ghost" size="sm">All {eq.deptShort} laboratories</LinkButton>
            </div>
          </div>
        )}
      </Page>
    </>
  );
}
