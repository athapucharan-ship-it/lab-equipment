import { NextResponse } from "next/server";
import { deleteEquipmentById, updateEquipmentById } from "@/db/api";
import type { Equipment } from "@/lib/data";

export const dynamic = "force-dynamic";

/** PATCH /api/equipment/:id — quantity, maintenance flag, image, text fields. */
export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  let patch: Partial<Equipment>;
  try {
    patch = (await req.json()) as Partial<Equipment>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }
  try {
    const rows = await updateEquipmentById(decodeURIComponent(id), patch);
    if (!rows) return NextResponse.json({ error: "Equipment not found" }, { status: 404 });
    return NextResponse.json({ ok: true, updated: rows });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "db error" }, { status: 503 });
  }
}

/** DELETE /api/equipment/:id — hides the asset from the catalogue. */
export async function DELETE(_req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  try {
    const rows = await deleteEquipmentById(decodeURIComponent(id));
    if (!rows) return NextResponse.json({ error: "Equipment not found" }, { status: 404 });
    return NextResponse.json({ ok: true, removed: rows });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "db error" }, { status: 503 });
  }
}
