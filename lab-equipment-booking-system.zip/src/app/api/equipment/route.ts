import { NextResponse } from "next/server";
import { listEquipment, upsertEquipment } from "@/db/api";
import type { Equipment } from "@/lib/data";

export const dynamic = "force-dynamic";

/** GET /api/equipment — the full catalogue stored in the database. */
export async function GET() {
  try {
    return NextResponse.json(await listEquipment());
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "db error" }, { status: 503 });
  }
}

/** POST /api/equipment — create (or replace) an asset from the admin dashboard. */
export async function POST(req: Request) {
  let body: Partial<Equipment>;
  try {
    body = (await req.json()) as Partial<Equipment>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON" }, { status: 400 });
  }
  if (!body.id || !body.name || !body.dept || !body.subject) {
    return NextResponse.json({ error: "id, name, dept and subject are required" }, { status: 400 });
  }
  try {
    const record = {
      id: String(body.id),
      name: String(body.name),
      dept: body.dept as Equipment["dept"],
      subject: String(body.subject),
      category: (body.category ?? "Test & Measurement") as Equipment["category"],
      manufacturer: body.manufacturer ?? "—",
      model: body.model ?? "—",
      photo: body.photo ?? ("labInstruments" as Equipment["photo"]),
      gallery: body.gallery ?? [],
      short: body.short ?? "",
      purpose: body.purpose ?? "",
      size: body.size ?? { footprint: "—", weight: "—" },
      quantity: Number(body.quantity ?? 1),
      maintenance: !!body.maintenance,
      specs: body.specs ?? [],
      uses: body.uses ?? [],
      instructions: body.instructions ?? [],
      safety: body.safety,
      location: body.location,
      calibrationDue: body.calibrationDue,
      addedOn: body.addedOn ?? new Date().toISOString().slice(0, 10),
    } satisfies Equipment;
    await upsertEquipment(record);
    return NextResponse.json({ ok: true, equipment: record }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "db error" }, { status: 503 });
  }
}
