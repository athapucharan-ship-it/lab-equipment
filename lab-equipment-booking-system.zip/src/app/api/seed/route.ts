import { sql } from "drizzle-orm";
import { NextResponse } from "next/server";
import { db } from "@/db";
import { bookings as bookingsTable, equipment as equipmentTable } from "@/db/schema";
import { bookingToRow, equipmentToRow, ensureSeeded } from "@/db/api";
import type { Booking, Equipment } from "@/lib/data";

export const dynamic = "force-dynamic";

/**
 * POST /api/seed — mirrors the browser store into PostgreSQL.
 * Body: { equipment?: Equipment[], bookings?: Booking[] }
 * With an empty body it simply seeds the bundled catalogue.
 */
export async function POST(req: Request) {
  let body: { equipment?: Equipment[]; bookings?: Booking[] } = {};
  try {
    body = (await req.json()) as typeof body;
  } catch {
    /* empty body → seed defaults */
  }

  try {
    const base = await ensureSeeded();
    let written = base.count;

    if (Array.isArray(body.equipment) && body.equipment.length) {
      for (const eq of body.equipment) {
        await db
          .insert(equipmentTable)
          .values(equipmentToRow(eq))
          .onConflictDoUpdate({ target: equipmentTable.id, set: equipmentToRow(eq) });
      }
      written = body.equipment.length;
    }

    if (Array.isArray(body.bookings) && body.bookings.length) {
      await db.insert(bookingsTable).values(body.bookings.map(bookingToRow)).onConflictDoNothing();
    }

    const total = await db.select({ count: sql<number>`count(*)::int` }).from(bookingsTable);

    return NextResponse.json({
      ok: true,
      equipment: written,
      bookings: body.bookings?.length ?? 0,
      totalBookings: Number(total[0]?.count ?? 0),
      seededNow: base.seeded,
    });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error instanceof Error ? error.message : "db error" }, { status: 503 });
  }
}

/** GET /api/seed — status of the database copy. */
export async function GET() {
  try {
    const base = await ensureSeeded();
    return NextResponse.json({ ok: true, equipment: base.count, seededNow: base.seeded });
  } catch (error) {
    return NextResponse.json({ ok: false, error: error instanceof Error ? error.message : "db error" }, { status: 503 });
  }
}
