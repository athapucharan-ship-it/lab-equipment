import { NextResponse } from "next/server";
import { patchBooking } from "@/db/api";

export const dynamic = "force-dynamic";

const STATUSES = ["Pending", "Approved", "Active", "Completed", "Cancelled", "Rejected"] as const;

/** PATCH /api/bookings/:bookingId — approve / reject / complete / cancel. */
export async function PATCH(req: Request, ctx: { params: Promise<{ id: string }> }) {
  const { id } = await ctx.params;
  let body: { status?: string; adminNote?: string } = {};
  try {
    body = (await req.json()) as typeof body;
  } catch {
    /* allow query-only updates */
  }
  if (body.status && !STATUSES.includes(body.status as (typeof STATUSES)[number])) {
    return NextResponse.json({ error: `status must be one of ${STATUSES.join(", ")}` }, { status: 400 });
  }
  try {
    const row = await patchBooking(decodeURIComponent(id), { status: body.status, adminNote: body.adminNote });
    if (!row) return NextResponse.json({ error: "Booking not found" }, { status: 404 });
    return NextResponse.json({ ok: true, booking: row });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "db error" }, { status: 503 });
  }
}
