import { NextResponse } from "next/server";
import { insertBooking, listBookings } from "@/db/api";
import { isHolding, makeBookingId, type Booking } from "@/lib/data";

export const dynamic = "force-dynamic";

/** GET /api/bookings — every booking stored in the database. */
export async function GET() {
  try {
    const rows = await listBookings();
    return NextResponse.json(rows);
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "db error" }, { status: 503 });
  }
}

/**
 * POST /api/bookings — creates a booking after checking live availability.
 * Availability = equipment.quantity − units held by Pending/Approved/Active bookings for that date.
 */
export async function POST(req: Request) {
  let body: Partial<Booking>;
  try {
    body = (await req.json()) as Partial<Booking>;
  } catch {
    return NextResponse.json({ error: "Invalid JSON body" }, { status: 400 });
  }

  const required = ["userName", "uid", "dept", "subject", "equipmentId", "date", "startTime", "endTime"] as const;
  const missing = required.filter((k) => !body[k]);
  if (missing.length) return NextResponse.json({ error: `Missing fields: ${missing.join(", ")}` }, { status: 400 });

  try {
    const { equipment: equipmentTable } = await import("@/db/schema");
    const { db } = await import("@/db");
    const { eq } = await import("drizzle-orm");
    const rows = await db.select().from(equipmentTable).where(eq(equipmentTable.id, body.equipmentId!));
    const asset = rows[0];
    if (!asset) return NextResponse.json({ error: "Unknown equipment id" }, { status: 404 });
    if (asset.maintenance) return NextResponse.json({ error: "Equipment is under maintenance" }, { status: 409 });

    const qty = Math.max(1, Number(body.quantity ?? 1));
    const existing = await listBookings();
    const held = existing.filter((b) => b.equipmentId === body.equipmentId && b.date === body.date && isHolding(b)).reduce((s, b) => s + b.quantity, 0);
    const free = Math.max(0, (asset.quantity ?? 0) - held);
    if (qty > free) return NextResponse.json({ error: `Only ${free} unit(s) available on ${body.date}`, free }, { status: 409 });

    const booking: Booking = {
      bookingId: makeBookingId(),
      createdAt: new Date().toISOString(),
      userName: String(body.userName),
      uid: String(body.uid),
      role: (body.role ?? "student") as Booking["role"],
      dept: body.dept as Booking["dept"],
      subject: String(body.subject),
      equipmentId: String(body.equipmentId),
      equipmentName: String(body.equipmentName ?? asset.name),
      quantity: qty,
      date: String(body.date),
      startTime: String(body.startTime),
      endTime: String(body.endTime),
      purpose: String(body.purpose ?? ""),
      returnDate: String(body.returnDate ?? body.date),
      returnTime: String(body.returnTime ?? body.endTime),
      phone: String(body.phone ?? ""),
      email: String(body.email ?? ""),
      notes: body.notes ? String(body.notes) : undefined,
      status: "Pending",
    };

    await insertBooking(booking);
    return NextResponse.json({ ok: true, booking }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: error instanceof Error ? error.message : "db error" }, { status: 503 });
  }
}
