import { NextResponse } from "next/server";
import { ensureSeeded, listBookings, listEquipment } from "@/db/api";

export const dynamic = "force-dynamic";

/**
 * GET /api/bootstrap — one call that hydrates the whole client app.
 * Falls back to the bundled seed catalogue when the database is unavailable,
 * which is what keeps the static/demo deployment working offline.
 */
export async function GET() {
  try {
    const seed = await ensureSeeded();
    const [equipment, bookings] = await Promise.all([listEquipment(), listBookings()]);
    return NextResponse.json({
      source: "database",
      seeded: seed.seeded,
      equipment,
      bookings,
      counts: { equipment: equipment.length, bookings: bookings.length },
    });
  } catch (error) {
    return NextResponse.json(
      {
        source: "seed",
        error: error instanceof Error ? error.message : "database unavailable",
      },
      { status: 200 },
    );
  }
}
