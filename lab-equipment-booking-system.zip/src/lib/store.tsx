"use client";

/**
 * LABBOOK client store.
 * localStorage is the authoritative demo store (bookings, admin edits, favourites,
 * recently viewed, session) — every mutation is also mirrored to the Drizzle/Postgres
 * API on a best-effort basis so the same code can be switched to a real backend later.
 */
import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  SEED_EQUIPMENT,
  deriveAll,
  makeBookingId,
  overlaps,
  type Booking,
  type BookingStatus,
  type Equipment,
  type Derived,
  type Session,
} from "./data";
import { PHOTOS, type PhotoKey } from "./images";
import type { DeptKey } from "./data/departments";

const KEY = "labbook.store.v1";

export interface AdminEquipmentEdit {
  quantity?: number;
  maintenance?: boolean;
  name?: string;
  short?: string;
  photo?: PhotoKey;
  manufacturer?: string;
  model?: string;
}

interface PersistShape {
  equipment: Equipment[];
  overrides: Record<string, AdminEquipmentEdit>;
  deleted: string[];
  bookings: Booking[];
  session: Session | null;
  favorites: string[];
  recent: string[];
  compare: string[];
  customLabs: { dept: DeptKey; slug: string; name: string; code?: string }[];
  customDepts: { key: string; name: string }[];
}

const initial: PersistShape = {
  equipment: SEED_EQUIPMENT,
  overrides: {},
  deleted: [],
  bookings: [],
  session: null,
  favorites: [],
  recent: [],
  compare: [],
  customLabs: [],
  customDepts: [],
};

/** Three sample bookings so the dashboard, statuses and receipts are demonstrable. */
function demoBookings(equipment: Equipment[]): Booking[] {
  const today = new Date();
  const iso = (d: number) => {
    const t = new Date(today);
    t.setDate(t.getDate() + d);
    return t.toISOString().slice(0, 10);
  };
  const pick = (id: string) => equipment.find((e) => e.id === id);
  const rows: [string, BookingStatus, number, string, string][] = [
    ["ECE-DE-001", "Active", 0, "09:00", "12:00"],
    ["ME-WS-001", "Approved", 1, "14:00", "17:00"],
    ["CSE-NW-001", "Pending", 2, "09:00", "10:30"],
    ["CH-CL-005", "Completed", -6, "11:00", "13:00"],
  ];
  return rows.flatMap(([id, status, dayOffset, start, end]) => {
    const eq = pick(id);
    if (!eq) return [];
    const b: Booking = {
      bookingId: makeBookingId(new Date(iso(dayOffset))),
      createdAt: new Date().toISOString(),
      userName: status === "Completed" ? "Nandini Rao" : "Arjun Prakash",
      uid: status === "Completed" ? "B22ECE045" : "B22CSE018",
      role: "student",
      dept: eq.dept,
      subject: eq.subject,
      equipmentId: eq.id,
      equipmentName: eq.name,
      quantity: 1,
      date: iso(dayOffset),
      startTime: start,
      endTime: end,
      purpose:
        status === "Completed"
          ? "Beer–Lambert law calibration curve for the practical record"
          : "Weekly laboratory experiment and data collection for the course record",
      returnDate: iso(dayOffset),
      returnTime: end,
      phone: "+91 98490 11223",
      email: "arjun.prakash@labbook.edu.in",
      status,
    };
    return [b];
  });
}

export type Result = { ok: boolean; message: string; booking?: Booking };

interface StoreValue extends PersistShape {
  ready: boolean;
  dbStatus: "unknown" | "online" | "offline";
  items: Derived[];
  byId: (id: string) => Derived | undefined;
  photoFor: (key: PhotoKey) => { src: string; alt: string; credit: string; creditUrl: string; page: string };
  book: (input: Omit<Booking, "bookingId" | "createdAt" | "status"> & { status?: BookingStatus }) => Result;
  cancelBooking: (id: string, reason?: string) => void;
  setBookingStatus: (id: string, status: BookingStatus, note?: string) => void;
  patchEquipment: (id: string, patch: AdminEquipmentEdit) => void;
  addEquipment: (eq: Equipment) => void;
  removeEquipment: (id: string) => void;
  toggleFavorite: (id: string) => void;
  toggleCompare: (id: string) => void;
  viewEquipment: (id: string) => void;
  login: (s: Session) => void;
  logout: () => void;
  addLab: (lab: { dept: DeptKey; slug: string; name: string; code?: string }) => void;
  resetDemo: () => void;
  pushToServer: () => Promise<{ ok: boolean; count?: number; error?: string }>;
  pullFromServer: () => Promise<{ ok: boolean; count?: number; error?: string }>;
}

const Ctx = createContext<StoreValue | null>(null);

export function LabbookProvider({ children }: { children: ReactNode }) {
  const [state, setState] = useState<PersistShape>(initial);
  const [ready, setReady] = useState(false);
  const [dbStatus, setDbStatus] = useState<StoreValue["dbStatus"]>("unknown");
  const booted = useRef(false);

  /* ------------------------------ hydrate ------------------------------ */
  useEffect(() => {
    if (booted.current) return;
    booted.current = true;
    let loaded: PersistShape | null = null;
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) loaded = { ...initial, ...(JSON.parse(raw) as PersistShape) };
    } catch {
      loaded = null;
    }
    const next = loaded ?? { ...initial, equipment: SEED_EQUIPMENT, bookings: demoBookings(SEED_EQUIPMENT) };
    if (!loaded) {
      // seed the demo bookings once so My Bookings / admin are not empty on first visit
      next.equipment = SEED_EQUIPMENT;
    }
    if (!next.equipment?.length) next.equipment = SEED_EQUIPMENT;
    setState(next);
    setReady(true);

    // optional server bootstrap (falls back silently to localStorage-only mode)
    void (async () => {
      try {
        const res = await fetch("/api/bootstrap", { cache: "no-store" });
        if (!res.ok) throw new Error("bad status");
        const data = (await res.json()) as { source?: string; bookings?: Booking[] };
        setDbStatus("online");
        if (Array.isArray(data.bookings) && data.bookings.length) {
          setState((prev) => {
            const ids = new Set(prev.bookings.map((b) => b.bookingId));
            const merged = [...prev.bookings, ...data.bookings!.filter((b) => !ids.has(b.bookingId))];
            return { ...prev, bookings: merged };
          });
        }
      } catch {
        setDbStatus("offline");
      }
    })();
  }, []);

  /* ------------------------------ persist ------------------------------ */
  useEffect(() => {
    if (!ready) return;
    try {
      localStorage.setItem(KEY, JSON.stringify(state));
    } catch {
      /* storage full / disabled — the demo keeps working in memory */
    }
  }, [state, ready]);

  /* --------------------------- theme (class) --------------------------- */
  useEffect(() => {
    const apply = () => {
      const stored = localStorage.getItem("labbook.theme");
      const dark = stored ? stored === "dark" : window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false;
      document.documentElement.classList.toggle("dark", dark);
    };
    apply();
    window.addEventListener("labbook:theme", apply as EventListener);
    return () => window.removeEventListener("labbook:theme", apply as EventListener);
  }, []);

  const equipment = useMemo(() => {
    const deleted = new Set(state.deleted);
    return state.equipment
      .filter((e) => !deleted.has(e.id))
      .map((e) => (state.overrides[e.id] ? { ...e, ...state.overrides[e.id] } : e));
  }, [state.equipment, state.overrides, state.deleted]);

  const items = useMemo(() => deriveAll(equipment, state.bookings), [equipment, state.bookings]);
  const byId = useCallback((id: string) => items.find((e) => e.id === id), [items]);

  const photoFor = useCallback((key: PhotoKey) => {
    const photo = PHOTOS[key] ?? PHOTOS.electronicsBench;
    return {
      src: photo.src ?? `https://images.pexels.com/photos/${photo.pid}/pexels-photo-${photo.pid}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=1200&h=800`,
      alt: photo.alt,
      credit: photo.credit,
      creditUrl: photo.creditUrl,
      page: photo.page,
    };
  }, []);

  /* ------------------------------ booking ------------------------------ */
  const book = useCallback<StoreValue["book"]>(
    (input) => {
      const eq = equipment.find((e) => e.id === input.equipmentId);
      if (!eq) return { ok: false, message: "Unknown equipment." };
      if (eq.maintenance) return { ok: false, message: `${eq.name} is under maintenance and cannot be booked.` };

      const qty = Number(input.quantity) || 0;
      if (qty < 1) return { ok: false, message: "Enter a quantity of at least 1." };

      let reserved = 0;
      for (const b of state.bookings) {
        if (b.equipmentId !== eq.id || b.date !== input.date) continue;
        if (["Pending", "Approved", "Active"].includes(b.status)) reserved += Number(b.quantity) || 0;
      }
      const availableOnDate = Math.max(0, (Number(eq.quantity) || 0) - reserved);
      if (qty > availableOnDate) {
        return {
          ok: false,
          message:
            availableOnDate === 0
              ? `All ${eq.quantity} unit(s) of ${eq.name} are already booked on ${input.date}.`
              : `Only ${availableOnDate} unit(s) of ${eq.name} are free on ${input.date}.`,
        };
      }
      const draft: Booking = {
        ...(input as Booking),
        bookingId: makeBookingId(),
        createdAt: new Date().toISOString(),
        status: input.status ?? "Pending",
      };
      const clash = state.bookings.find((b) => overlaps(b, draft) && b.uid === draft.uid && b.bookingId !== draft.bookingId);
      if (clash) {
        return {
          ok: false,
          message: `You already have booking ${clash.bookingId} for ${clash.equipmentName} in that time window.`,
        };
      }
      setState((prev) => ({ ...prev, bookings: [draft, ...prev.bookings] }));
      void fetch("/api/bookings", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(draft),
      }).catch(() => undefined);
      return { ok: true, message: `Booking ${draft.bookingId} created.`, booking: draft };
    },
    [equipment, state.bookings],
  );

  const cancelBooking = useCallback<StoreValue["cancelBooking"]>((id, reason) => {
    setState((prev) => ({
      ...prev,
      bookings: prev.bookings.map((b) =>
        b.bookingId === id ? { ...b, status: "Cancelled" as BookingStatus, adminNote: reason ?? b.adminNote } : b,
      ),
    }));
    void fetch(`/api/bookings/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ status: "Cancelled", adminNote: reason ?? "Cancelled by user" }),
    }).catch(() => undefined);
  }, []);

  const setBookingStatus = useCallback<StoreValue["setBookingStatus"]>((id, status, note) => {
    setState((prev) => ({
      ...prev,
      bookings: prev.bookings.map((b) => (b.bookingId === id ? { ...b, status, adminNote: note ?? b.adminNote } : b)),
    }));
    void fetch(`/api/bookings/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ status, adminNote: note ?? "" }),
    }).catch(() => undefined);
  }, []);

  const patchEquipment = useCallback<StoreValue["patchEquipment"]>((id, patch) => {
    setState((prev) => ({ ...prev, overrides: { ...prev.overrides, [id]: { ...prev.overrides[id], ...patch } } }));
    void fetch(`/api/equipment/${id}`, {
      method: "PATCH",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(patch),
    }).catch(() => undefined);
  }, []);

  const addEquipment = useCallback<StoreValue["addEquipment"]>((eq) => {
    setState((prev) => ({
      ...prev,
      equipment: [eq, ...prev.equipment.filter((e) => e.id !== eq.id)],
      deleted: prev.deleted.filter((d) => d !== eq.id),
    }));
    void fetch("/api/equipment", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify(eq),
    }).catch(() => undefined);
  }, []);

  const removeEquipment = useCallback<StoreValue["removeEquipment"]>((id) => {
    setState((prev) => ({
      ...prev,
      deleted: [...new Set([...prev.deleted, id])],
      equipment: prev.equipment.filter((e) => e.id !== id),
    }));
    void fetch(`/api/equipment/${id}`, { method: "DELETE" }).catch(() => undefined);
  }, []);

  const toggleFavorite = useCallback((id: string) => {
    setState((prev) => ({
      ...prev,
      favorites: prev.favorites.includes(id) ? prev.favorites.filter((f) => f !== id) : [id, ...prev.favorites],
    }));
  }, []);

  const toggleCompare = useCallback((id: string) => {
    setState((prev) => {
      const has = prev.compare.includes(id);
      const next = has ? prev.compare.filter((c) => c !== id) : [...prev.compare, id].slice(-4);
      return { ...prev, compare: next };
    });
  }, []);

  const viewEquipment = useCallback((id: string) => {
    setState((prev) => ({ ...prev, recent: [id, ...prev.recent.filter((r) => r !== id)].slice(0, 8) }));
  }, []);

  const login = useCallback((s: Session) => setState((prev) => ({ ...prev, session: s })), []);
  const logout = useCallback(() => setState((prev) => ({ ...prev, session: null })), []);

  const addLab = useCallback<StoreValue["addLab"]>((lab) => {
    setState((prev) => ({ ...prev, customLabs: [...prev.customLabs.filter((l) => l.slug !== lab.slug), lab] }));
  }, []);

  const resetDemo = useCallback(() => {
    try {
      localStorage.removeItem(KEY);
    } catch {
      /* ignore */
    }
    setState({ ...initial, equipment: SEED_EQUIPMENT, bookings: demoBookings(SEED_EQUIPMENT) });
  }, []);

  const pushToServer = useCallback(async () => {
    try {
      const res = await fetch("/api/seed", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({ equipment, overrides: state.overrides, bookings: state.bookings }),
      });
      const data = (await res.json()) as { ok?: boolean; equipment?: number; bookings?: number; error?: string };
      setDbStatus(res.ok ? "online" : "offline");
      return { ok: !!data.ok, count: data.equipment, error: data.error };
    } catch (e) {
      setDbStatus("offline");
      return { ok: false, error: e instanceof Error ? e.message : "network error" };
    }
  }, [equipment, state.overrides, state.bookings]);

  const pullFromServer = useCallback(async () => {
    try {
      const res = await fetch("/api/bookings", { cache: "no-store" });
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const rows = (await res.json()) as Booking[];
      setDbStatus("online");
      if (Array.isArray(rows)) {
        setState((prev) => {
          const local = new Map(prev.bookings.map((b) => [b.bookingId, b]));
          for (const r of rows) if (!local.has(r.bookingId)) local.set(r.bookingId, r);
          return { ...prev, bookings: [...local.values()] };
        });
      }
      return { ok: true, count: Array.isArray(rows) ? rows.length : 0 };
    } catch (e) {
      setDbStatus("offline");
      return { ok: false, error: e instanceof Error ? e.message : "network error" };
    }
  }, []);

  const value: StoreValue = {
    ...state,
    equipment,
    ready,
    dbStatus,
    items,
    byId,
    photoFor,
    book,
    cancelBooking,
    setBookingStatus,
    patchEquipment,
    addEquipment,
    removeEquipment,
    toggleFavorite,
    toggleCompare,
    viewEquipment,
    login,
    logout,
    addLab,
    resetDemo,
    pushToServer,
    pullFromServer,
  };

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useLabbook() {
  const ctx = useContext(Ctx);
  if (!ctx) throw new Error("useLabbook must be used inside <LabbookProvider>");
  return ctx;
}
