/**
 * LABBOOK — departments & laboratory subjects
 * Department → Subject/Laboratory → Equipment is the primary navigation model.
 */

export type DeptKey = "cse" | "ece" | "eee" | "me" | "ce" | "chem" | "phy" | "other";

export interface Department {
  key: DeptKey;
  name: string;
  short: string;
  tagline: string;
  description: string;
  hod: string;
  building: string;
  floor: string;
  contact: string;
  /** accent hue used for the department band (HSL degrees) */
  hue: number;
  /** inline SVG path (24x24 viewBox) rendered as the department mark */
  icon: string;
}

export interface Subject {
  slug: string;
  dept: DeptKey;
  name: string;
  code: string;
  semester: string;
  room: string;
  /** Optional extra prose; a description is derived from the department when omitted. */
  description?: string;
  labHours: string;
  supervisor: string;
  safety: string;
  outcomes: string[];
}

export const DEPARTMENTS: Department[] = [
  {
    key: "cse",
    name: "Computer Science & Engineering",
    short: "CSE",
    tagline: "Programming, data, networks & systems laboratories",
    description:
      "The Computer Science & Engineering department runs five teaching laboratories supporting the B.Tech, M.Tech and project programmes. Labs are equipped with networked desktop workstations, single-board computers, configurable network gear and Linux training servers. Equipment is issued against a lab slot and must be returned to the same workstation number.",
    hod: "Dr. A. Rajendran, Professor & Head",
    building: "Main Academic Block – B2",
    floor: "2nd & 3rd floor",
    contact: "cse.lab@labbook.edu.in · Ext. 2201",
    hue: 212,
    icon: "M7 8h10M7 12h4m9 4a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v14Z",
  },
  {
    key: "ece",
    name: "Electronics & Communication Engineering",
    short: "ECE",
    tagline: "Signals, systems, communication & VLSI laboratories",
    description:
      "ECE laboratories cover analog and digital electronics, communication systems, microprocessors and VLSI design. Students book bench instruments (oscilloscopes, function generators, logic analysers) and development kits. High-value instruments such as spectrum analysers are issued only after the supervisor's sign-off.",
    hod: "Dr. S. Kavitha, Professor & Head",
    building: "Electronics Block – E1",
    floor: "1st floor",
    contact: "ece.lab@labbook.edu.in · Ext. 1450",
    hue: 168,
    icon: "M4 6h16M4 6v12m16-12v12M4 18h16M8 10h.01M12 10h.01M16 10h.01M8 14h8",
  },
  {
    key: "eee",
    name: "Electrical & Electronics Engineering",
    short: "EEE",
    tagline: "Machines, power systems, measurements & control labs",
    description:
      "The EEE department operates the electrical machines hall, power systems simulation laboratory, precision measurements lab and control systems bench. Rotating machines and high-current benches are operated only under staff supervision; the booking system reserves the machine, the safety kit and the attendant slot together.",
    hod: "Dr. M. Nagarajan, Professor & Head",
    building: "Power Systems Block – P3",
    floor: "Ground floor",
    contact: "eee.lab@labbook.edu.in · Ext. 3120",
    hue: 38,
    icon: "M13 2 4.5 13.5H11l-1 8.5L18.5 10H12l1-8Z",
  },
  {
    key: "me",
    name: "Mechanical Engineering",
    short: "ME",
    tagline: "Manufacturing, CAD/CAM, thermal & fluid laboratories",
    description:
      "Mechanical Engineering includes the central workshop, CAD/CAM laboratory, thermal engineering hall and fluid mechanics laboratory. Machine tools require a completed safety induction; bookings for lathes, milling and drilling machines include a mandatory 15-minute setup and shutdown window.",
    hod: "Dr. P. Selvam, Professor & Head",
    building: "Workshop Complex – W1",
    floor: "Ground & first floor",
    contact: "me.lab@labbook.edu.in · Ext. 4007",
    hue: 8,
    icon: "M14.7 6.3a4 4 0 1 0-5.4 5.4L4 17v3h3l5.3-5.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4 2.5-2.5Z",
  },
  {
    key: "ce",
    name: "Civil Engineering",
    short: "CE",
    tagline: "Surveying, concrete, soil & environmental laboratories",
    description:
      "Civil Engineering laboratories handle field instruments (total stations, theodolites, levels) as well as materials testing machines. Field equipment is issued in kits, collected from the store counter at 08:40 and returned by 16:50 with the log card signed by the instructor.",
    hod: "Dr. V. Latha, Professor & Head",
    building: "Civil Block – C4",
    floor: "Ground & 2nd floor",
    contact: "ce.lab@labbook.edu.in · Ext. 5310",
    hue: 96,
    icon: "M12 3 3 8v13h6v-6h6v6h6V8l-9-5Z",
  },
  {
    key: "chem",
    name: "Chemistry",
    short: "CHEM",
    tagline: "Engineering & applied chemistry laboratories",
    description:
      "The Chemistry department supports first-year engineering chemistry, environmental and materials chemistry practicals. Glassware, balances and analysers are booked per bench. Chemicals are never issued through this system — they are drawn from the chemical store against the same booking ID.",
    hod: "Dr. R. Anitha, Professor & Head",
    building: "Science Block – S2",
    floor: "1st floor",
    contact: "chem.lab@labbook.edu.in · Ext. 6118",
    hue: 268,
    icon: "M9 3h6M10 3v6L5 19a2 2 0 0 0 1.8 3h10.4A2 2 0 0 0 19 19l-5-10V3",
  },
  {
    key: "phy",
    name: "Physics",
    short: "PHY",
    tagline: "Engineering physics, optics & laser laboratories",
    description:
      "Physics laboratories run optics, laser, electronics and modern-physics experiments. Optical benches and lasers are sensitive: bookings include a light-proof room allotment, and Class 3B lasers may only be handled by students who completed the laser safety note.",
    hod: "Dr. K. Sundaresan, Professor & Head",
    building: "Science Block – S1",
    floor: "Ground floor",
    contact: "phy.lab@labbook.edu.in · Ext. 6002",
    hue: 300,
    icon: "M12 4a8 8 0 1 0 0 16 8 8 0 0 0 0-16Zm0 5.5A2.5 2.5 0 1 0 12 14.5 2.5 2.5 0 0 0 12 9.5Z",
  },
  {
    key: "other",
    name: "Other Departments & Central Facilities",
    short: "OTHER",
    tagline: "Innovation hub, AI/Data Science lab and central research facilities",
    description:
      "Interdisciplinary facilities shared by all branches — the central innovation hub, AI & data science laboratory, and instrument research centre. Booking eligibility is extended to every department, and approvals are granted by the central facility in-charge.",
    hod: "Dr. N. Farhan, Dean – Research & Innovation",
    building: "Central Innovation Hub – I0",
    floor: "1st floor",
    contact: "innovation@labbook.edu.in · Ext. 7000",
    hue: 190,
    icon: "M12 3v3m0 12v3M4.2 7.5l2.6 1.5m10.4 6 2.6 1.5M4.2 16.5l2.6-1.5m10.4-6 2.6-1.5M12 8.5A3.5 3.5 0 1 0 12 15.5 3.5 3.5 0 0 0 12 8.5Z",
  },
];

export const SUBJECTS: Subject[] = [
  // ------------------------------- CSE -----------------------------------
  { slug: "data-structures-lab", dept: "cse", name: "Data Structures Lab", code: "CSE-102", semester: "II B.Tech / Sem 3", room: "B2-201", labHours: "Mon & Wed · 09:00–12:00", supervisor: "Mr. V. Karthik, Lab Engineer", safety: "Use approved log-in credentials. Do not install software without lab engineer approval.", outcomes: ["Implement linear & non-linear data structures", "Analyse time/space complexity on real workstations", "Version control and build hygiene"] },
  { slug: "dbms-lab", dept: "cse", name: "DBMS Lab", code: "CSE-204", semester: "III B.Tech / Sem 5", room: "B2-204", labHours: "Tue & Thu · 14:00–17:00", supervisor: "Mrs. R. Sangeetha, Asst. Professor", safety: "Restore the training database to the semester snapshot before logging out.", outcomes: ["Design normalised schemas", "Write & tune SQL queries and procedures", "Perform backup / recovery drills"] },
  { slug: "computer-networks-lab", dept: "cse", name: "Computer Networks Lab", code: "CSE-206", semester: "III B.Tech / Sem 6", room: "B2-207", labHours: "Fri · 09:00–12:00", supervisor: "Mr. J. Bala Subramanian, Lab Engineer", safety: "Never connect rack equipment to mains while patching. Power-down first.", outcomes: ["Configure switching & routing protocols", "Analyse traffic with a LAN tester", "Build and certify structured cabling"] },
  { slug: "operating-systems-lab", dept: "cse", name: "Operating Systems Lab", code: "CSE-302", semester: "IV B.Tech / Sem 7", room: "B2-209", labHours: "Mon & Wed · 14:00–17:00", supervisor: "Dr. P. Priya, Asst. Professor", safety: "Sudo activity is logged. Do not modify cluster boot configuration.", outcomes: ["Kernel modules & scheduling experiments", "Virtualisation and container setup", "Shell scripting & system administration"] },
  { slug: "programming-lab", dept: "cse", name: "Programming Lab", code: "CSE-101", semester: "I B.Tech / Sem 1", room: "B2-211", labHours: "Daily · 08:00–16:00", supervisor: "Ms. T. Divya, Programmer", safety: "Keep food and drinks away from the workstations and kits.", outcomes: ["Structured programming in C / Python", "Embedded programming basics", "Debugging with an IDE and version control"] },

  // ------------------------------- ECE -----------------------------------
  { slug: "digital-electronics-lab", dept: "ece", name: "Digital Electronics Lab", code: "ECE-103", semester: "II B.Tech / Sem 3", room: "E1-104", labHours: "Tue & Thu · 09:00–12:00", supervisor: "Mr. S. Prakash, Lab Engineer", safety: "Verify supply polarity before powering a breadboard circuit.", outcomes: ["Verify combinational & sequential logic", "Probe digital waveforms on a DSO", "Design counters and state machines"] },
  { slug: "analog-electronics-lab", dept: "ece", name: "Analog Electronics Lab", code: "ECE-203", semester: "III B.Tech / Sem 5", room: "E1-108", labHours: "Mon & Wed · 14:00–17:00", supervisor: "Dr. L. Aruna, Asst. Professor", safety: "Discharge capacitors before rearranging the breadboard.", outcomes: ["Bias and characterise amplifiers", "Measure frequency response", "Build regulated power supplies"] },
  { slug: "communication-systems-lab", dept: "ece", name: "Communication Systems Lab", code: "ECE-305", semester: "IV B.Tech / Sem 7", room: "E1-112", labHours: "Fri · 14:00–17:00", supervisor: "Mr. D. Ramesh, Lab Engineer", safety: "RF output must be terminated in 50 Ω before enabling the generator.", outcomes: ["Generate & demodulate AM/FM carriers", "Measure spectrum occupancy", "Study digital modulation constellations"] },
  { slug: "microprocessors-lab", dept: "ece", name: "Microprocessors & Microcontrollers Lab", code: "ECE-207", semester: "III B.Tech / Sem 5", room: "E1-115", labHours: "Tue & Thu · 14:00–17:00", supervisor: "Mrs. K. Meena, Asst. Professor", safety: "Use the anti-static mat and wrist strap while handling trainer cards.", outcomes: ["Write and debug assembly programs", "Interface peripherals & interrupts", "Prototype on embedded C development boards"] },
  { slug: "vlsi-lab", dept: "ece", name: "VLSI Design Lab", code: "ECE-402", semester: "V B.Tech / Sem 9", room: "E1-118", labHours: "Wed · 09:00–12:00", supervisor: "Dr. V. Gokul, Associate Professor", safety: "Do not connect FPGA boards to USB hubs without the current limiter.", outcomes: ["RTL design in Verilog", "Functional & timing simulation", "Synthesis and implementation on FPGA"] },

  // ------------------------------- EEE -----------------------------------
  { slug: "electrical-machines-lab", dept: "eee", name: "Electrical Machines Lab", code: "EEE-204", semester: "III B.Tech / Sem 5", room: "P3-G01", labHours: "Mon & Wed · 09:00–12:30", supervisor: "Mr. A. Siva, Workshop Superintendent", safety: "Two-person rule for any machine above 3 kW. Guard covers must stay closed.", outcomes: ["Load & efficiency tests on DC/AC machines", "Open & short circuit tests on transformers", "Determine parameters from block rotor tests"] },
  { slug: "power-systems-lab", dept: "eee", name: "Power Systems Lab", code: "EEE-303", semester: "IV B.Tech / Sem 7", room: "P3-G04", labHours: "Tue & Thu · 09:00–12:00", supervisor: "Dr. R. Vijayalakshmi, Professor", safety: "Simulator only — no live HT connection. Keep the earth switch closed while wiring.", outcomes: ["Load flow & fault analysis on a simulator", "Relay coordination study", "Energy metering and losses estimation"] },
  { slug: "electrical-measurements-lab", dept: "eee", name: "Electrical Measurements Lab", code: "EEE-105", semester: "II B.Tech / Sem 4", room: "P3-102", labHours: "Fri · 09:00–12:00", supervisor: "Ms. N. Bhavani, Lab Engineer", safety: "Select the correct range before applying supply; use the fused test leads.", outcomes: ["Measure power, energy and resistance", "Calibrate indicating instruments", "Evaluate measurement uncertainty"] },
  { slug: "control-systems-lab", dept: "eee", name: "Control Systems Lab", code: "EEE-305", semester: "IV B.Tech / Sem 7", room: "P3-105", labHours: "Tue & Thu · 14:00–17:00", supervisor: "Mr. S. Thirumurugan, Asst. Professor", safety: "Keep hands clear of the rotating pendulum arm; use the emergency stop first.", outcomes: ["Time & frequency response of systems", "Design PID controllers on PLC/trainer", "Stability analysis from Bode plots"] },

  // -------------------------------- ME -------------------------------------
  { slug: "mechanical-workshop", dept: "me", name: "Mechanical Workshop", code: "ME-106", semester: "II B.Tech (Common)", room: "W1-Hall A", labHours: "Daily · 09:00–16:00", supervisor: "Mr. B. Gopinath, Foreman", safety: "Safety shoes, goggles and close-fitting clothing are compulsory. No gloves near rotating spindles.", outcomes: ["Turn, drill and mill basic components", "Read workshop drawings & tolerances", "Practice machine safety and housekeeping"] },
  { slug: "cad-cam-lab", dept: "me", name: "CAD / CAM Lab", code: "ME-302", semester: "IV B.Tech / Sem 7", room: "W1-203", labHours: "Mon & Wed · 14:00–17:00", supervisor: "Dr. S. Kalaivani, Associate Professor", safety: "The CNC machine door must remain closed during a run; use single-block for the first pass.", outcomes: ["Parametric modelling & assemblies", "Generate and post-process CNC tool paths", "Additive manufacturing of designed parts"] },
  { slug: "thermal-engineering-lab", dept: "me", name: "Thermal Engineering Lab", code: "ME-205", semester: "III B.Tech / Sem 5", room: "W1-Hall B", labHours: "Tue & Thu · 09:00–12:30", supervisor: "Mr. P. Murugan, Lab Engineer", safety: "Hot surfaces and fuel handling — keep the fire blanket and extinguisher accessible.", outcomes: ["Performance tests on IC engines", "Boiler & heat exchanger experiments", "Calorific value determination"] },
  { slug: "fluid-mechanics-lab", dept: "me", name: "Fluid Mechanics & Hydraulics Lab", code: "ME-203", semester: "III B.Tech / Sem 5", room: "W1-106", labHours: "Fri · 09:00–12:30", supervisor: "Mrs. D. Priyadharshini, Asst. Professor", safety: "Wipe spillages immediately; never exceed the press rated load.", outcomes: ["Flow measurement through meters & weirs", "Turbine and pump characteristic curves", "Hydraulic press & accumulator demonstration"] },

  // -------------------------------- CE -------------------------------------
  { slug: "surveying-lab", dept: "ce", name: "Surveying Lab", code: "CE-201", semester: "III B.Tech / Sem 5", room: "C4-Store / Field", labHours: "Mon–Fri · 06:30–17:00 (field)", supervisor: "Mr. G. Pandiyan, Field Instructor", safety: "Wear the hi-vis vest on site; carry the instrument in its case, never on the tripod.", outcomes: ["Angular & linear measurement with instruments", "Levelling, traversing and contouring", "GPS/GNSS survey data processing"] },
  { slug: "concrete-technology-lab", dept: "ce", name: "Concrete Technology Lab", code: "CE-303", semester: "IV B.Tech / Sem 7", room: "C4-G02", labHours: "Tue & Thu · 09:00–12:00", supervisor: "Dr. M. Karthikeyan, Professor", safety: "Cement is caustic — gloves and goggles mandatory inside the mixing area.", outcomes: ["Workability, strength and durability tests", "Mix design as per IS 10262", "Aggregate grading and shape studies"] },
  { slug: "soil-mechanics-lab", dept: "ce", name: "Soil Mechanics Lab", code: "CE-305", semester: "IV B.Tech / Sem 7", room: "C4-104", labHours: "Mon & Wed · 09:00–12:00", supervisor: "Ms. R. Jansi, Lab Engineer", safety: "Use the extraction hood for oven-dried samples and organic solvents.", outcomes: ["Index property determination", "Compaction, permeability & consolidation tests", "Shear strength interpretation"] },
  { slug: "environmental-engineering-lab", dept: "ce", name: "Environmental Engineering Lab", code: "CE-402", semester: "V B.Tech / Sem 9", room: "C4-108", labHours: "Fri · 14:00–17:00", supervisor: "Dr. S. Revathi, Associate Professor", safety: "Waste water samples are biohazards — disinfect benches after use.", outcomes: ["Water & wastewater quality analysis", "Jar test coagulation optimisation", "Air quality and noise monitoring"] },

  // ------------------------------ Chemistry --------------------------------
  { slug: "chemistry-lab", dept: "chem", name: "Chemistry Lab", code: "CH-201", semester: "Advanced Practical Course", room: "S2-110", labHours: "Tue & Thu · 09:00–12:00", supervisor: "Mr. S. Elangovan, Lab Assistant", safety: "Fume hood for volatile reagents; neutralise spills before wiping.", outcomes: ["Volumetric & gravimetric analysis", "Instrumental estimation using analysers", "Safe handling and waste segregation"] },
  { slug: "engineering-chemistry-lab", dept: "chem", name: "Engineering Chemistry Lab", code: "CH-101", semester: "I B.Tech (Common)", room: "S2-112", labHours: "Mon & Wed · 09:00–11:00", supervisor: "Mrs. P. Lakshmi, Asst. Professor", safety: "No open flames near the solvent cabinet; read the SDS before each experiment.", outcomes: ["Water quality and hardness analysis", "Electrochemistry & corrosion studies", "Fuel and energy materials experiments"] },

  // ------------------------------ Physics ---------------------------------
  { slug: "engineering-physics-lab", dept: "phy", name: "Engineering Physics Lab", code: "PH-101", semester: "I B.Tech (Common)", room: "S1-G03", labHours: "Mon & Wed · 11:00–13:00", supervisor: "Mr. K. Arul, Lab Assistant", safety: "Do not look directly into the laser aperture; remove rings and watches near the sonometer.", outcomes: ["Optics and acoustics experiments", "Electrical & magnetic measurements", "Data reduction and error analysis"] },
  { slug: "optics-lab", dept: "phy", name: "Optics & Laser Lab", code: "PH-305", semester: "III B.Tech / Sem 5", room: "S1-G06 (dark room)", labHours: "Thu · 14:00–17:00", supervisor: "Dr. S. Thenmozhi, Associate Professor", safety: "Class 3B laser: interlock on, beam below eye level, laser goggles for the set wavelength.", outcomes: ["Wavelength determination with a spectrometer", "Interference & diffraction measurements", "Laser beam profiling and safety practice"] },

  // ------------------------------- Other ----------------------------------
  { slug: "ai-data-science-lab", dept: "other", name: "AI & Data Science Lab", code: "IDS-401", semester: "Open electives / VII Sem", room: "I0-201", labHours: "Mon–Fri · 08:00–20:00", supervisor: "Mr. H. Imran, Research Engineer", safety: "GPU node jobs must be submitted through the scheduler, not run on desktops.", outcomes: ["Train models on shared GPU compute", "Build reproducible data pipelines", "Deploy a demo inference service"] },
  { slug: "robotics-innovation-lab", dept: "other", name: "Robotics & Innovation Lab", code: "IDS-403", semester: "All branches — club & projects", room: "I0-204", labHours: "Daily · 15:00–21:00", supervisor: "Ms. C. Swetha, Innovation Coordinator", safety: "Robot cells must be fenced and the E-stop tested before each run.", outcomes: ["Prototype multidisciplinary projects", "Integrate sensors, actuators and controllers", "Prepare project documentation for expos"] },
  { slug: "central-instrument-facility", dept: "other", name: "Central Instrument Research Facility", code: "IDS-500", semester: "Research scholars & faculty", room: "I0-Basement", labHours: "By appointment · 09:00–18:00", supervisor: "Dr. N. Farhan (in-charge)", safety: "Training and empanelment are mandatory before independent operation.", outcomes: ["Advanced materials characterisation", "Faculty & M.Tech research measurements", "Shared instrumentation for funded projects"] },
];

export const deptBy = (key: string) => DEPARTMENTS.find((d) => d.key === key);
export const subjectsOf = (key: string) => SUBJECTS.filter((s) => s.dept === key);
export const subjectBy = (key: string, slug: string) =>
  SUBJECTS.find((s) => s.dept === key && s.slug === slug);
