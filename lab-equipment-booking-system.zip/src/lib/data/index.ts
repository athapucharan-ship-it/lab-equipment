import { DEPARTMENTS, SUBJECTS, deptBy, subjectBy, subjectsOf, type DeptKey, type Department, type Subject } from "./departments";
import { EQUIPMENTS_CSE_ECE } from "./equipment-cse-ece";
import { EQUIPMENTS_EEE_ME } from "./equipment-eee-me";
import { EQUIPMENTS_CE_CHEM } from "./equipment-ce-chem";
import { EQUIPMENTS_PHY_OTHER } from "./equipment-phy-other";
import type { Availability, Booking, BookingStatus, Equipment } from "./types";

export * from "./types";
export type { DeptKey, Department, Subject };
export { DEPARTMENTS, SUBJECTS, deptBy, subjectBy, subjectsOf };

/** Full seed catalogue (before any admin/localStorage edits). */
export const SEED_EQUIPMENT: Equipment[] = [
  ...EQUIPMENTS_CSE_ECE,
  ...EQUIPMENTS_EEE_ME,
  ...EQUIPMENTS_CE_CHEM,
  ...EQUIPMENTS_PHY_OTHER,
];

/** Only bookings that currently hold equipment. */
export const HOLDING_STATUSES: BookingStatus[] = ["Pending", "Approved", "Active"];

export const isHolding = (b: Booking) => HOLDING_STATUSES.includes(b.status);

/** Quantity of an asset held by a set of bookings on a given date (all dates when date is empty). */
export function bookedQty(bookings: Booking[], equipmentId: string, date?: string) {
  return bookings
    .filter(
      (b) =>
        b.equipmentId === equipmentId &&
        isHolding(b) &&
        (!date || !b.date || b.date === date),
    )
    .reduce((sum, b) => sum + (Number(b.quantity) || 0), 0);
}

export interface Derived extends Equipment {
  total: number;
  reserved: number;
  available: number;
  availability: Availability;
  subjectName: string;
  deptName: string;
  deptShort: string;
}

export function derive(
  eq: Equipment,
  bookings: Booking[],
  opts: { date?: string; adminStatus?: Availability | null } = {},
): Derived {
  const subject = subjectBy(eq.dept, eq.subject);
  const dept = deptBy(eq.dept);
  const reserved = bookedQty(bookings, eq.id, opts.date);
  const total = Math.max(0, Number(eq.quantity) || 0);
  const available = Math.max(0, total - reserved);
  let availability: Availability = available === 0 ? "booked" : available < total ? "partial" : "available";
  if (eq.maintenance || eq.retired) availability = "maintenance";
  if (opts.adminStatus) availability = opts.adminStatus;
  return {
    ...eq,
    total,
    reserved,
    available,
    availability,
    subjectName: subject?.name ?? eq.subject,
    deptName: dept?.name ?? eq.dept,
    deptShort: dept?.short ?? eq.dept.toUpperCase(),
  };
}

export function deriveAll(
  equipment: Equipment[],
  bookings: Booking[],
  opts: { date?: string; statusOverrides?: Record<string, Availability>; maintenance?: string[] } = {},
): Derived[] {
  return equipment.map((eq) => {
    const forced = opts.maintenance?.includes(eq.id) ? "maintenance" : undefined;
    const adminStatus = forced ?? opts.statusOverrides?.[eq.id] ?? undefined;
    return derive(eq, bookings, { date: opts.date, adminStatus: adminStatus ?? undefined });
  });
}

/** Aggregate dashboard statistics. */
export function statsFor(items: Derived[]) {
  const total = items.length;
  const units = items.reduce((s, e) => s + e.total, 0);
  const availableUnits = items.reduce((s, e) => s + e.available, 0);
  const by = (k: Availability) => items.filter((e) => e.availability === k).length;
  return {
    equipment: total,
    units,
    availableUnits,
    available: by("available"),
    partial: by("partial"),
    booked: by("booked"),
    maintenance: by("maintenance"),
    reserved: units - availableUnits,
    departments: DEPARTMENTS.length,
    labs: SUBJECTS.length,
  };
}

/* ------------------------------ search & filters ----------------------------- */

export interface CatalogFilter {
  query?: string;
  dept?: string;
  subject?: string;
  category?: string;
  availability?: "all" | "available" | "maintenance";
  sort?: "az" | "availability" | "recent";
}

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]+/g, " ").trim();

export function searchEquipment(items: Derived[], f: CatalogFilter) {
  let out = [...items];
  const q = norm(f.query ?? "");
  if (q) {
    const terms = q.split(" ").filter(Boolean);
    out = out.filter((e) => {
      const hay = norm(
        [e.name, e.id, e.manufacturer, e.model, e.deptName, e.deptShort, e.subjectName, e.subject, e.category, e.short, ...(e.uses ?? [])].join(" "),
      );
      return terms.every((t) => hay.includes(t));
    });
  }
  if (f.dept && f.dept !== "all") out = out.filter((e) => e.dept === f.dept);
  if (f.subject && f.subject !== "all") out = out.filter((e) => e.subject === f.subject);
  if (f.category && f.category !== "all") out = out.filter((e) => e.category === f.category);
  if (f.availability === "available") out = out.filter((e) => e.availability === "available" || e.availability === "partial");
  if (f.availability === "maintenance") out = out.filter((e) => e.availability === "maintenance");

  const rank: Record<Availability, number> = { available: 0, partial: 1, booked: 2, maintenance: 3 };
  if (f.sort === "az") out.sort((a, b) => a.name.localeCompare(b.name));
  else if (f.sort === "availability") out.sort((a, b) => rank[a.availability] - rank[b.availability] || a.name.localeCompare(b.name));
  else if (f.sort === "recent") out.sort((a, b) => (b.addedOn || "").localeCompare(a.addedOn || ""));
  return out;
}

export function equipmentCounts(deptKey?: DeptKey | string, subjectSlug?: string) {
  return SEED_EQUIPMENT.filter((e) => (!deptKey || e.dept === deptKey) && (!subjectSlug || e.subject === subjectSlug)).length;
}

/** Deterministic per-lab totals derived from the seed catalogue. */
export function labStats(items: Derived[], dept: DeptKey, subject: string) {
  const scoped = items.filter((e) => e.dept === dept && e.subject === subject);
  return {
    total: scoped.length,
    available: scoped.filter((e) => e.availability === "available").length,
    units: scoped.reduce((s, e) => s + e.total, 0),
    availableUnits: scoped.reduce((s, e) => s + e.available, 0),
    maintenance: scoped.filter((e) => e.availability === "maintenance").length,
  };
}

/* --------------------------------- ids --------------------------------- */

export function makeBookingId(date = new Date()) {
  const ymd = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, "0")}${String(date.getDate()).padStart(2, "0")}`;
  const rand = Math.random().toString(36).slice(2, 6).toUpperCase();
  return `LB-${ymd}-${rand}`;
}

export const todayISO = () => new Date().toISOString().slice(0, 10);

export function formatDate(iso?: string) {
  if (!iso) return "—";
  const d = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}

export function formatDateTime(iso?: string) {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleString("en-IN", { day: "2-digit", month: "short", year: "numeric", hour: "2-digit", minute: "2-digit" });
}

export const timeToMinutes = (t: string) => {
  const [h, m] = (t || "0:0").split(":").map(Number);
  return (h || 0) * 60 + (m || 0);
};

/** Overlap check used to prevent conflicting bookings of the same asset on the same day. */
export function overlaps(a: Booking, b: Booking) {
  if (a.date !== b.date || a.equipmentId !== b.equipmentId) return false;
  return timeToMinutes(a.startTime) < timeToMinutes(b.endTime) && timeToMinutes(b.startTime) < timeToMinutes(a.endTime);
}

export const LAB_NAME = "LABBOOK";
export const COLLEGE_NAME = "Sri Venkateswara College of Engineering & Technology";
export const COLLEGE_SHORT = "SVCOET";
export const COLLEGE_ADDRESS = "Tech Park Main Road, Tirumalagiri, Hyderabad 500079, Telangana";
