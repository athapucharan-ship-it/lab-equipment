import type { DeptKey } from "./departments";
import type { PhotoKey } from "../images";

/** Equipment categories used by the filter panel and admin dashboard. */
export const CATEGORIES = [
  "Test & Measurement",
  "Computing",
  "Networking",
  "Embedded & Development",
  "Electrical Machines",
  "Power & Control",
  "Manufacturing",
  "Thermal & Fluid",
  "Survey & Geospatial",
  "Materials Testing",
  "Chemical Analysis",
  "Optics & Laser",
  "Research Facility",
] as const;

export type Category = (typeof CATEGORIES)[number];

/** Availability states derived from quantity + live bookings (or admin override). */
export type Availability = "available" | "partial" | "booked" | "maintenance";

export interface Equipment {
  /** Asset / equipment id, e.g. ECE-DEL-001 */
  id: string;
  name: string;
  dept: DeptKey;
  /** Subject (laboratory) slug */
  subject: string;
  category: Category;
  manufacturer: string;
  model: string;
  photo: PhotoKey;
  gallery?: PhotoKey[];
  /** one line summary shown on the card */
  short: string;
  /** purpose / longer description shown on the details page */
  purpose: string;
  /** physical size + weight + bench requirement */
  size: { footprint: string; weight: string; bench?: string; power?: string };
  quantity: number;
  /** admin flag — equipment kept out of issue for servicing */
  maintenance?: boolean;
  retired?: boolean;
  specs: [string, string][];
  /** what the equipment is used for */
  uses: string[];
  /** usage instructions (student-facing SOP) */
  instructions: string[];
  safety?: string;
  location?: string;
  calibrationDue?: string;
  /** ISO date — used by the "Recently added" sort */
  addedOn: string;
}

export type UserRole = "student" | "faculty" | "admin";

export interface Session {
  name: string;
  uid: string;
  role: UserRole;
  dept: DeptKey | "all";
  email: string;
  phone: string;
}

export type BookingStatus = "Pending" | "Approved" | "Active" | "Completed" | "Cancelled" | "Rejected";

export interface Booking {
  /** LB-YYYYMMDD-XXXX */
  bookingId: string;
  createdAt: string;
  userName: string;
  uid: string;
  role: UserRole;
  dept: DeptKey;
  subject: string;
  equipmentId: string;
  equipmentName: string;
  quantity: number;
  date: string;
  startTime: string;
  endTime: string;
  purpose: string;
  returnDate: string;
  returnTime: string;
  phone: string;
  email: string;
  notes?: string;
  status: BookingStatus;
  adminNote?: string;
}

export const AVAILABILITY_META: Record<
  Availability,
  { label: string; icon: string; chip: string; dot: string; text: string }
> = {
  available: {
    label: "Available",
    icon: "M20 6 9 17l-5-5",
    chip: "bg-emerald-50 ring-emerald-200 dark:bg-emerald-500/10 dark:ring-emerald-500/30",
    dot: "bg-emerald-500",
    text: "text-emerald-700 dark:text-emerald-300",
  },
  partial: {
    label: "Partially Available",
    icon: "M12 8v4l2.5 2.5M21 12a9 9 0 1 1-18 0 9 9 0 0 1 18 0Z",
    chip: "bg-amber-50 ring-amber-200 dark:bg-amber-500/10 dark:ring-amber-500/30",
    dot: "bg-amber-500",
    text: "text-amber-700 dark:text-amber-300",
  },
  booked: {
    label: "Fully Booked",
    icon: "M18 6 6 18M6 6l12 12",
    chip: "bg-rose-50 ring-rose-200 dark:bg-rose-500/10 dark:ring-rose-500/30",
    dot: "bg-rose-500",
    text: "text-rose-700 dark:text-rose-300",
  },
  maintenance: {
    label: "Under Maintenance",
    icon: "M14.7 6.3a4 4 0 1 0-5.4 5.4L4 17v3h3l5.3-5.3a4 4 0 0 0 5.4-5.4l-2.5 2.5-2.4-.6-.6-2.4 2.5-2.5Z",
    chip: "bg-sky-50 ring-sky-200 dark:bg-sky-500/10 dark:ring-sky-500/30",
    dot: "bg-sky-500",
    text: "text-sky-700 dark:text-sky-300",
  },
};
