/**
 * LABBOOK image bank
 * ---------------------------------------------------------------------------
 * All equipment photographs are real-life photographs served from the Pexels
 * CDN and used under the Pexels License (free for commercial & non-commercial
 * use, attribution not required but given here as good practice).
 *
 * If you want to swap any image for a photograph owned by your own college,
 * drop the file into `public/assets/images/` and change the `src` below to
 * `/assets/images/your-file.jpg` — nothing else needs to change.
 */

export interface Photo {
  /** Pexels photo id (also used to build the CDN url) */
  pid: number;
  /** Human readable description used for alt text */
  alt: string;
  /** Photographer name */
  credit: string;
  /** Photographer profile url */
  creditUrl: string;
  /** Original photo page (licence info) */
  page: string;
  /** Optional custom source (for locally hosted replacements) */
  src?: string;
}

const p = (
  pid: number,
  alt: string,
  credit: string,
  creditUrl: string,
  slug: string,
): Photo => ({ pid, alt, credit, creditUrl, page: `https://www.pexels.com/photo/${slug}-${pid}/` });

/** Master photo bank — keyed by a semantic slug used from the equipment data. */
export const PHOTOS = {
  // ---- Electronics / instrumentation -------------------------------------
  oscilloscope: p(7858289, "Oscilloscope being calibrated on a lab bench", "cottonbro studio", "https://www.pexels.com/@cottonbro", "a-person-holding-a-electronic-device"),
  dso: p(18471567, "Digital storage oscilloscope on a laboratory table", "Ludovic Delot", "https://www.pexels.com/@delot", "a-digital-oscilloscope-on-a-table-with-a-keyboard"),
  scopeVintage: p(7858287, "Engineer operating an analog oscilloscope", "cottonbro studio", "https://www.pexels.com/@cottonbro", "a-person-holding-white-and-gray-digital-device"),
  benchMeters: p(132700, "Technician using bench top electronic test equipment", "Alexander Dummer", "https://www.pexels.com/@alexander-dummer-37646", "person-using-appliance"),
  scopeWave: p(7858292, "CRO screen showing a waveform during an experiment", "cottonbro studio", "https://www.pexels.com/@cottonbro", "man-in-overall-sitting-on-table-while-holding-oscillograph"),
  labInstruments: p(18471414, "Group of precision measuring instruments on a lab bench", "Ludovic Delot", "https://www.pexels.com/@delot", "a-group-of-electronic-equipment-sitting-on-a-table"),
  electronicsBench: p(19895784, "Electronics workshop bench with components and tools", "ThisIsEngineering", "https://www.pexels.com/@thisisengineering", "computer-components-on-table"),
  multimeter: p(38292956, "Digital multimeter with test leads on a workbench", "Sphinxx69", "https://www.pexels.com/@sphinxx69-2162007289", "close-up-of-multimeter-and-tools-on-table"),
  soldering: p(7285977, "Soldering a prototype circuit on a bench", "Karola Giersz / Kaboompics", "https://www.pexels.com/@karola-g", "man-doing-art-and-craft-at-table-at-home"),
  solderStation: p(7286029, "Soldering station with rework tools and components", "Karola Giersz / Kaboompics", "https://www.pexels.com/@karola-g", "repair-tools-on-a-desk-top"),
  breadboard: p(5265337, "Hand wiring a solderless breadboard prototype", "Jeswin Thomas", "https://www.pexels.com/@jeswin", "hands-of-a-person-holding-wires-on-a-breadboard"),

  // ---- Computing / networking -------------------------------------------
  switchPorts: p(2881224, "24 port ethernet switch with patch cables", "Brett Sayles", "https://www.pexels.com/@brett-sayles", "ethernet-cables-plugged-in-network-switch"),
  routerCables: p(13963756, "Router and cabling in a network rack", "Vladimir Srajber", "https://www.pexels.com/@vladimirsrajber", "close-up-of-a-bunch-of-cables-plugged-into-a-device"),
  switchPanel: p(6466143, "Patch panel and switch in a data centre rack", "Sergei Starostin", "https://www.pexels.com/@sejio402", "close-up-photo-of-ethernet-cables-on-network-switch"),
  networkEngineer: p(19226352, "Engineer servicing core network equipment", "panumas nikhomkhai", "https://www.pexels.com/@cookiecutter", "engineer-fixing-core-swith-in-data-center-room"),
  switchCloseup: p(2881227, "Managed switch with LED link indicators", "Brett Sayles", "https://www.pexels.com/@brett-sayles", "close-up-photo-of-network-switch"),
  microcontroller: p(7180749, "Wiring a microcontroller development board", "Thirdman", "https://www.pexels.com/@thirdman", "a-person-holding-a-micro-chip"),
  devBoard: p(35652419, "Single board computer with USB connectivity", "Tanha Tamanna Syed", "https://www.pexels.com/@tanhatamannasyed", "close-up-of-electronic-circuit-board-with-usb-port"),
  circuitBoard: p(35652420, "Microcontroller board and components on a table", "Tanha Tamanna Syed", "https://www.pexels.com/@tanhatamannasyed", "close-up-of-electronic-circuitry-with-components"),
  raspberryPi: p(57007, "Raspberry Pi single board computer top view", "Craig Dennis", "https://www.pexels.com/@craigmdennis", "green-and-grey-circuit-board"),
  sbcCluster: p(10635975, "Single board computer cluster node", "Mathias Wouters", "https://www.pexels.com/@mathias-wouters-115341282", "close-up-shot-of-a-computer-motherboard"),
  computerLab: p(10638070, "Computer laboratory workstations in use", "Ron Lach", "https://www.pexels.com/@ron-lach", "students-sitting-in-the-classroom"),
  codingClass: p(5530484, "Students programming on lab desktop machines", "Thành Đỗ", "https://www.pexels.com/@dothanhyb", "people-sitting-on-chairs-while-using-computers"),
  labBenches: p(5530437, "Rows of desktop workstations in a computing lab", "Thành Đỗ", "https://www.pexels.com/@dothanhyb", "group-of-people-sitting-on-chair-in-front-of-computers-in-the-class"),
  studentDesktop: p(9158772, "Student working at a desktop computer", "Mikhail Nilov", "https://www.pexels.com/@mikhail-nilov", "a-male-student-using-a-computer"),

  // ---- Mechanical / manufacturing ---------------------------------------
  lathe: p(11951233, "Precision metal lathe turning a work piece", "alex", "https://www.pexels.com/@alex-197677521", "a-water-washing-a-round-steel-machine"),
  workshop: p(18569750, "Mechanical workshop with several machine tools", "J E", "https://www.pexels.com/@j-e-22471780", "a-large-machine-shop-with-many-machines-and-tools"),
  latheDetail: p(5846176, "Lathe machine carriage and lead screw", "Tima Miroshnichenko", "https://www.pexels.com/@tima-miroshnichenko", "grayscale-photo-of-a-lathe-machine"),
  latheOperator: p(5846269, "Operator working on an engine lathe", "Tima Miroshnichenko", "https://www.pexels.com/@tima-miroshnichenko", "a-man-in-gray-jacket-using-an-industrial-equipment"),
  latheChuck: p(28752150, "Spinning lathe chuck during machining", "Connor Lucock", "https://www.pexels.com/@connor-lucock-259838", "industrial-lathe-machine-in-action"),
  printer3d: p(22491107, "FDM 3D printer carriage and heated bed", "FOX", "https://www.pexels.com/@fox-58267", "selective-focus-of-device"),
  printerNozzle: p(12698670, "3D printer extruder nozzle in action", "Erik Mclean", "https://www.pexels.com/@introspectivedsgn", "close-up-of-modern-3d-printer-part"),
  printerPrint: p(13513543, "3D printer building a layer of a part", "Jonathan Cooper", "https://www.pexels.com/@theshuttervision", "a-close-up-shot-of-a-3d-printer"),
  engineerPrinter: p(32213229, "Engineer with additive manufacturing machine", "Yusuf Çelik", "https://www.pexels.com/@zandatsu", "young-female-engineer-with-3d-printer"),
  printerDark: p(15584332, "CNC / additive manufacturing machine in low light", "Tibor Szabo", "https://www.pexels.com/@tibszabo", "3d-printer-in-dark"),

  // ---- Civil / surveying -------------------------------------------------
  totalStation: p(36930873, "Total station set up for geodetic surveying", "Khoiru Ummah Kendari", "https://www.pexels.com/@khoiru-ummah-kendari-24-2160704929", "high-precision-construction-surveying-equipment-outdoors"),
  theodolite: p(30379884, "Surveyor reading a theodolite on site", "Mukhtar Shuaib Mukhtar", "https://www.pexels.com/@akoonie", "construction-surveyor-using-theodolite-on-site"),
  levelSetup: p(5802822, "Operator using a dumpy/auto level at a site", "Nelson Axigoth", "https://www.pexels.com/@themightynelson", "a-man-surveying-the-area"),
  surveyTripod: p(30379883, "Levelling instrument mounted on a tripod", "Mukhtar Shuaib Mukhtar", "https://www.pexels.com/@akoonie", "construction-worker-using-survey-equipment-outdoors"),
  surveyRanging: p(5802821, "Survey crew with ranging equipment", "Nelson Axigoth", "https://www.pexels.com/@themightynelson", "a-man-in-orange-and-yellow-vest"),
  concreteTemp: p(31945566, "Digital probe measuring concrete temperature", "SGM Concrete", "https://www.pexels.com/@betongsmcsg", "handheld-device-measuring-concrete-temperature"),
  concreteBlocks: p(33894661, "Cast concrete test cubes / blocks", "sirmudi_photography", "https://www.pexels.com/@sirmudi_photography-2155088036", "stack-of-patterned-concrete-blocks-outdoors"),
  universalTester: p(16442863, "Servo hydraulic universal testing machine", "Sternsteiger Stahlwaren", "https://www.pexels.com/@sternsteiger-stahlwaren-526336403", "achilles-series-by-testing"),
  materialsLab: p(8442027, "Materials testing laboratory instruments", "Pavel Danilyuk", "https://www.pexels.com/@pavel-danilyuk", "medical-equipment-in-laboratory"),
  siteEquipment: p(4170184, "Construction site equipment and aggregates", "Engin Akyurt", "https://www.pexels.com/@enginakyurt", "yellow-and-black-heavy-equipment-on-snow-covered-ground"),

  // ---- Chemistry ---------------------------------------------------------
  stirrer: p(9629679, "Magnetic stirrer with dosing pipette and flask", "Ivan S", "https://www.pexels.com/@ivan-s", "dropper-over-a-clear-glass-jar"),
  glassware: p(9629683, "Volumetric flask and beakers on a bench", "Ivan S", "https://www.pexels.com/@ivan-s", "a-florence-flask-with-water-beside-empty-beaker"),
  chemistryGlass: p(8325948, "Colourful solutions in laboratory glassware", "Kindel Media", "https://www.pexels.com/@kindelmedia", "close-up-view-of-laboratory-glasswares-and-colorful-chemicals"),
  measuringGlass: p(1366942, "Graduated cylinders and measuring glassware", "Rodolfo Clix", "https://www.pexels.com/@rodolfoclix", "photo-of-clear-glass-measuring-cup-lot"),
  titration: p(8325702, "Titration glassware with reagent bottles", "Kindel Media", "https://www.pexels.com/@kindelmedia", "colorful-liquids-in-laboratory-glasswares"),
  centrifuge: p(6629397, "Benchtop laboratory centrifuge rotor", "Karola Giersz / Kaboompics", "https://www.pexels.com/@karola-g", "laboratory-centrifuge-in-hospital"),
  centrifugeUse: p(6627667, "Operator loading a centrifuge", "Karola Giersz / Kaboompics", "https://www.pexels.com/@karola-g", "doctor-using-a-centrifuge-machine"),
  sampleRack: p(6627697, "Sample tubes racked beside an analyser", "Karola Giersz / Kaboompics", "https://www.pexels.com/@karola-g", "2-vacutainer-with-blood-samples"),
  analyser: p(6627661, "Analysing samples with benchtop instrument", "Karola Giersz / Kaboompics", "https://www.pexels.com/@karola-g", "close-up-of-doctor-hands-with-blood-samples"),
  spectrophotometer: p(6627687, "Laboratory analyst operating a spectrophotometer", "Karola Giersz / Kaboompics", "https://www.pexels.com/@karola-g", "laboratory-worker-using-modern-hospital-equipment"),

  // ---- Physics -----------------------------------------------------------
  microscope: p(11899950, "Binocular compound microscope", "Jeff Burkholder", "https://www.pexels.com/@jeff-burkholder-219258325", "gray-microscope-in-close-up-shot"),
  microscopeLab: p(8326143, "Microscope with prepared samples nearby", "Kindel Media", "https://www.pexels.com/@kindelmedia", "shallow-focus-photo-of-a-microscope"),
  travellingMicroscope: p(18952655, "Precision optical microscope stage", "indra projects", "https://www.pexels.com/@indraprojectsofficial", "close-up-of-microscope"),
  physicsLab: p(6208707, "Students working with physics demonstration apparatus", "cottonbro studio", "https://www.pexels.com/@cottonbro", "student-with-pink-hair-inside-a-science-laboratory"),
  opticsBench: p(6208725, "Optics experiment bench in a university lab", "cottonbro studio", "https://www.pexels.com/@cottonbro", "beautiful-woman-wearing-a-blue-sweater"),

  // ---- Electrical --------------------------------------------------------
  dcMachine: p(38303960, "Rotating electrical machine / engine assembly", "princess", "https://www.pexels.com/@princess-2150885580", "vintage-industrial-engine-in-black-and-white"),
  controlPanel: p(34526423, "Technician working on an electrical control panel", "mickael ange konan", "https://www.pexels.com/@mickael-ange-konan-2156070331", "female-technician-working-on-electrical-control-panel"),
  transformer: p(28912010, "Power transformer and overhead line hardware", "Michael Pointner", "https://www.pexels.com/@michael-pointner-134459625", "high-voltage-power-lines-at-sunset"),
  substation: p(9889066, "Indoor substation switchgear yard", "Kindel Media", "https://www.pexels.com/@kindelmedia", "power-plant-during-dusk"),
  generatorYard: p(9889054, "Generating plant machinery behind a fence", "Kindel Media", "https://www.pexels.com/@kindelmedia", "power-plant"),

  // ---- Metrology ---------------------------------------------------------
  caliperMachine: p(16630111, "Caliper being used beside machine tool", "FFD Restorations", "https://www.pexels.com/@ffd-restorations-400571257", "close-up-of-workshop-tools"),
  metrologySet: p(5290119, "Precision measuring tool set on a bench", "Carlos Yanez", "https://www.pexels.com/@carlos-yanez-3536634", "measuring-instruments-on-a-black-surface"),
  vernier: p(28231807, "Vernier caliper on a machined surface", "Ahmet Çiftçi", "https://www.pexels.com/@ahmet-ciftci-1413580052", "a-caliper-is-placed-on-a-metal-surface"),
  micrometer: p(7166998, "Measuring a shaft with a vernier / micrometer", "Antoni Shkraba", "https://www.pexels.com/@shkrabaanthony", "high-angle-shot-of-person-measuring-an-object"),
  dialIndicator: p(38291710, "Dial test indicator used for alignment", "Adinhath Gilande", "https://www.pexels.com/@adinath-gilande-617966960", "close-up-of-mitutoyo-dial-indicator-in-workshop"),
} satisfies Record<string, Photo>;

export type PhotoKey = keyof typeof PHOTOS;

/** All photograph keys — used by the admin image picker. */
export const PhotoKeyList = Object.keys(PHOTOS) as PhotoKey[];

/** CDN url builder (Pexels image CDN, resized + compressed). */
export function photoSrc(key: PhotoKey, w = 1200, h = 800): string {
  const photo = PHOTOS[key];
  if (photo.src) return photo.src;
  return `https://images.pexels.com/photos/${photo.pid}/pexels-photo-${photo.pid}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`;
}

/** Small thumbnail used inside equipment cards. */
export const photoThumb = (key: PhotoKey) => photoSrc(key, 640, 420);

/** Full credit descriptor rendered on the equipment detail page. */
export function photoCredit(key: PhotoKey) {
  const photo = PHOTOS[key];
  return {
    label: `Photo: ${photo.credit} — Pexels (Pexels License, free to use)`,
    authorUrl: photo.creditUrl,
    photoUrl: photo.page,
    alt: photo.alt,
  };
}

export const LICENSE_NOTE =
  "Equipment photographs are real-life images licensed under the Pexels License. Click the credit line under any photo to open the original page.";
